import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig, Plugin } from 'vite';
import { processLogoAndGenerateIcons } from './scripts/update-app-icons.js';
import {
  generateOffersWithGemini,
  generateInstantTelecomOffers,
  generateChatReplyWithGemini,
} from './src/server/aiOfferService';

function serverApiPlugin(): Plugin {
  return {
    name: 'server-api-plugin',
    configureServer(server) {
      server.middlewares.use('/api/save-logo', async (req, res) => {
        if (req.method !== 'POST') {
          res.statusCode = 405;
          res.end(JSON.stringify({ error: 'Method not allowed' }));
          return;
        }

        let body = '';
        req.on('data', (chunk: any) => {
          body += chunk;
        });

        req.on('end', async () => {
          try {
            const data = JSON.parse(body);
            if (!data.imageBase64) {
              res.statusCode = 400;
              res.end(JSON.stringify({ error: 'Missing imageBase64' }));
              return;
            }

            await processLogoAndGenerateIcons(data.imageBase64);
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ success: true, url: '/app-logo.png?v=' + Date.now() }));
          } catch (err: any) {
            console.error('Error saving logo:', err);
            res.statusCode = 500;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ error: err?.message || 'Internal error' }));
          }
        });
      });

      // Dedicated High-Speed AI Drive Offer Generator API (Never Hangs / Instant Fallback)
      server.middlewares.use('/api/ai-offers', async (req, res) => {
        if (req.method !== 'POST') {
          res.statusCode = 405;
          res.end(JSON.stringify({ error: 'Method not allowed' }));
          return;
        }

        let body = '';
        req.on('data', (chunk: any) => {
          body += chunk;
        });

        req.on('end', async () => {
          let parsedData: any = {};
          try {
            parsedData = body ? JSON.parse(body) : {};
          } catch {}

          const prompt = parsedData.prompt || 'সকল অপারেটরের সেরা ড্রাইভ অফারসমূহ';
          const operator = parsedData.operator || 'all';

          try {
            const offers = await generateOffersWithGemini(prompt, operator);
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ success: true, offers }));
          } catch (err: any) {
            console.error('Error generating AI offers, using instant fallback:', err);
            const fallback = generateInstantTelecomOffers(prompt, operator);
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ success: true, offers: fallback }));
          }
        });
      });

      // AI Chat Assistance API
      server.middlewares.use('/api/ai-chat', async (req, res) => {
        if (req.method !== 'POST') {
          res.statusCode = 405;
          res.end(JSON.stringify({ error: 'Method not allowed' }));
          return;
        }

        let body = '';
        req.on('data', (chunk: any) => {
          body += chunk;
        });

        req.on('end', async () => {
          let parsedData: any = {};
          try {
            parsedData = body ? JSON.parse(body) : {};
          } catch {}

          const query = parsedData.query || '';
          try {
            const reply = await generateChatReplyWithGemini(query);
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ success: true, reply }));
          } catch (err: any) {
            console.error('Error in AI chat:', err);
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ success: true, reply: 'ধন্যবাদ, আপনার অনুরোধটি প্রক্রিয়া করা হয়েছে।' }));
          }
        });
      });

      // Mobile SMS Auto-Forwarder / MacroDroid Webhook Handler
      server.middlewares.use('/api/sms-webhook', async (req, res) => {
        if (req.method !== 'POST') {
          res.statusCode = 405;
          res.end(JSON.stringify({ error: 'Method not allowed' }));
          return;
        }

        let body = '';
        req.on('data', (chunk: any) => {
          body += chunk;
        });

        req.on('end', async () => {
          try {
            const data = body ? JSON.parse(body) : {};
            const rawMessage = data.message || data.text || data.body || data.sms || '';
            const sender = data.sender || data.from || '';

            // Use regex parsing for telecom SMS
            const textToParse = rawMessage || (typeof data === 'string' ? data : JSON.stringify(data));
            
            // Regex extraction
            const lower = textToParse.toLowerCase();
            let gateway = 'bKash';
            if (lower.includes('nagad') || lower.includes('নগদ')) gateway = 'Nagad';
            else if (lower.includes('rocket') || lower.includes('dbbl') || lower.includes('রকেট')) gateway = 'Rocket';
            else if (lower.includes('upay') || lower.includes('উপায়')) gateway = 'Upay';

            // TrxID match
            const trxMatch =
              textToParse.match(/(?:TrxID|TxnID|Txn\s*ID|Transaction\s*ID|TransID|ID)\s*(?:is|:|\s)\s*([A-Za-z0-9]{5,20})/i) ||
              textToParse.match(/(?:TrxID|TxnID)\s+([A-Za-z0-9]{5,20})/i) ||
              textToParse.match(/\b([0-9A-Z]{8,12})\b/);

            // Amount match
            const amtMatch =
              textToParse.match(/(?:Tk\.?|৳|BDT|amount(?:\s+is)?(?:\s*:)?)\s*([0-9,]+(?:\.[0-9]{1,2})?)/i) ||
              textToParse.match(/([0-9,]+(?:\.[0-9]{1,2})?)\s*(?:Tk|৳|Taka|টাকা)/i) ||
              textToParse.match(/received\s+(?:Tk\.?|৳)?\s*([0-9,]+(?:\.[0-9]{1,2})?)/i);

            const trxId = trxMatch ? trxMatch[1].trim().toUpperCase() : (data.trxId || '').toUpperCase();
            const amount = amtMatch ? parseFloat(amtMatch[1].replace(/,/g, '')) : (parseFloat(data.amount) || 0);

            if (!trxId || amount <= 0) {
              res.statusCode = 400;
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ success: false, error: 'Could not extract valid TrxID or amount from message' }));
              return;
            }

            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({
              success: true,
              message: 'SMS successfully parsed',
              parsed: {
                gateway,
                trxId,
                amount,
                sender,
              },
            }));
          } catch (err: any) {
            console.error('Error in sms webhook:', err);
            res.statusCode = 500;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ success: false, error: err?.message || 'Server error' }));
          }
        });
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), serverApiPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
