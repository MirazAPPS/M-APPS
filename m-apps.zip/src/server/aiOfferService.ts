import { GoogleGenAI } from '@google/genai';

export interface GeneratedOfferPayload {
  id?: string;
  operator: 'gp' | 'robi' | 'banglalink' | 'airtel' | 'teletalk' | 'skitto';
  operatorName: string;
  packageName: string;
  minutes: number;
  internetGB: number;
  validityDays: number;
  priceTK: number;
  regularPriceTK: number;
  cashbackTK: number;
  division: string;
  title: string;
}

const OP_NAMES: Record<string, string> = {
  gp: 'Grameenphone',
  robi: 'Robi',
  banglalink: 'Banglalink',
  airtel: 'Airtel',
  teletalk: 'Teletalk',
  skitto: 'Skitto',
};

// Rich, realistic fallback catalog tailored to Bangladesh market
export function generateInstantTelecomOffers(
  prompt: string,
  targetOperator: string = 'all'
): GeneratedOfferPayload[] {
  const ts = Date.now();
  const lower = prompt.toLowerCase();
  const ops: Array<'gp' | 'robi' | 'banglalink' | 'airtel' | 'teletalk'> =
    targetOperator === 'all'
      ? ['gp', 'robi', 'banglalink', 'airtel']
      : [targetOperator as any];

  // Detect query intent: minutes, data, or combo
  const isDataHeavy = lower.includes('ডাটা') || lower.includes('ইন্টারনেট') || lower.includes('gb') || lower.includes('data');
  const isMinuteHeavy = lower.includes('মিনিট') || lower.includes('min') || lower.includes('কল');

  // Detect budget hints (e.g. 400, 500, 300)
  const budgetMatch = prompt.match(/\b([2-9][0-9]{2})\b/);
  const targetBudget = budgetMatch ? parseInt(budgetMatch[1], 10) : 0;

  const catalogByOp: Record<string, Array<{ gb: number; min: number; price: number; reg: number; cash: number; pkg: string }>> = {
    gp: [
      { gb: 50, min: 800, price: 549, reg: 749, cash: 200, pkg: 'সুপার ধামাকা কম্বো' },
      { gb: 35, min: 750, price: 498, reg: 649, cash: 151, pkg: 'মেগা বান্ডেল প্যাক' },
      { gb: 60, min: 0, price: 420, reg: 550, cash: 130, pkg: 'পাওয়ার ডাটা প্যাক' },
      { gb: 0, min: 1000, price: 480, reg: 650, cash: 170, pkg: 'মিনিট স্পেশাল অফার' },
      { gb: 25, min: 450, price: 349, reg: 460, cash: 111, pkg: 'স্টুডেন্ট বাজেট প্যাক' },
    ],
    robi: [
      { gb: 45, min: 800, price: 539, reg: 699, cash: 160, pkg: 'ধামাকা বান্ডেল' },
      { gb: 60, min: 900, price: 629, reg: 799, cash: 170, pkg: 'ভিআইপি মেগা কম্বো' },
      { gb: 50, min: 0, price: 399, reg: 520, cash: 121, pkg: 'সুপার ডাটা অফার' },
      { gb: 0, min: 750, price: 398, reg: 520, cash: 122, pkg: 'ভয়েস মিনিট প্যাক' },
      { gb: 30, min: 500, price: 360, reg: 480, cash: 120, pkg: 'ফ্যামিলি কম্বো' },
    ],
    banglalink: [
      { gb: 50, min: 0, price: 399, reg: 499, cash: 100, pkg: 'ইন্টারনেট প্লাস' },
      { gb: 40, min: 750, price: 479, reg: 620, cash: 141, pkg: 'কম্বো ধামাকা' },
      { gb: 80, min: 0, price: 580, reg: 750, cash: 170, pkg: 'মেগা ডাটা প্যাক' },
      { gb: 0, min: 1000, price: 460, reg: 600, cash: 140, pkg: 'ভয়েস স্পেশাল' },
      { gb: 25, min: 400, price: 320, reg: 430, cash: 110, pkg: 'বাজেট ধামাকা' },
    ],
    airtel: [
      { gb: 30, min: 600, price: 388, reg: 498, cash: 110, pkg: 'স্টুডেন্ট স্পেশাল' },
      { gb: 45, min: 750, price: 489, reg: 630, cash: 141, pkg: 'আনলিমিটেড কম্বো' },
      { gb: 55, min: 0, price: 430, reg: 560, cash: 130, pkg: 'হাই-স্পিড ডাটা' },
      { gb: 0, min: 800, price: 390, reg: 510, cash: 120, pkg: 'ভয়েস সুপার প্যাক' },
      { gb: 20, min: 350, price: 290, reg: 390, cash: 100, pkg: 'ইকোনমি কম্বো' },
    ],
    teletalk: [
      { gb: 35, min: 500, price: 340, reg: 450, cash: 110, pkg: 'বর্ণমালা স্পেশাল' },
      { gb: 50, min: 0, price: 380, reg: 500, cash: 120, pkg: 'ডিজিটাল ডাটা প্যাক' },
      { gb: 0, min: 700, price: 320, reg: 420, cash: 100, pkg: 'মিনিট প্যাক' },
    ],
  };

  const results: GeneratedOfferPayload[] = [];

  ops.forEach((opKey, index) => {
    const list = catalogByOp[opKey] || catalogByOp.gp;
    let chosen = list[0];

    if (isDataHeavy) {
      chosen = list.find((item) => item.gb > 0 && item.min === 0) || list[0];
    } else if (isMinuteHeavy) {
      chosen = list.find((item) => item.min > 0 && item.gb === 0) || list[0];
    } else if (targetBudget > 0) {
      // Find closest within budget
      chosen = [...list].sort((a, b) => Math.abs(a.price - targetBudget) - Math.abs(b.price - targetBudget))[0];
    } else {
      chosen = list[index % list.length];
    }

    const opName = OP_NAMES[opKey] || opKey;
    const titleParts = [];
    if (chosen.gb > 0) titleParts.push(`${chosen.gb}GB`);
    if (chosen.min > 0) titleParts.push(`${chosen.min} Min`);
    const title = `${opName} ${titleParts.join(' + ')} ${chosen.pkg}`;

    results.push({
      id: `ai-gen-${opKey}-${ts}-${index}`,
      operator: opKey,
      operatorName: opName,
      packageName: chosen.pkg,
      minutes: chosen.min,
      internetGB: chosen.gb,
      validityDays: 30,
      priceTK: chosen.price,
      regularPriceTK: chosen.reg,
      cashbackTK: chosen.cash,
      division: 'অল বিডি (All BD)',
      title,
    });
  });

  return results;
}

export async function generateOffersWithGemini(
  prompt: string,
  targetOperator: string = 'all'
): Promise<GeneratedOfferPayload[]> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return generateInstantTelecomOffers(prompt, targetOperator);
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    const targetOpLabel = targetOperator === 'all' ? 'GP, Robi, Banglalink, Airtel' : targetOperator;

    const systemPrompt = `You are a high-speed Bangladeshi telecom drive offer generator.
Generate 4 realistic mobile drive packages for Bangladesh (${targetOpLabel}) responding to: "${prompt}".
Respond with ONLY a raw JSON array matching:
[{"operator":"gp"|"robi"|"banglalink"|"airtel"|"teletalk","operatorName":"string","packageName":"string","minutes":number,"internetGB":number,"validityDays":30,"priceTK":number,"regularPriceTK":number,"cashbackTK":number,"division":"অল বিডি (All BD)","title":"string"}]
Keep JSON strictly valid, realistic Bangladeshi pricing & cashback (৳70-৳250).`;

    const apiCallPromise = ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: systemPrompt,
      config: {
        responseMimeType: 'application/json',
        maxOutputTokens: 600,
      },
    });

    // 2.8 second strict timeout to guarantee fast responsiveness and zero app hanging
    const timeoutPromise = new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error('AI response timeout (safety fallback)')), 2800)
    );

    const response = await Promise.race([apiCallPromise, timeoutPromise]);
    const text = response.text || '';
    const jsonMatch = text.match(/\[[\s\S]*\]/);

    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map((item: any, idx: number) => ({
          id: `ai-live-${Date.now()}-${idx}`,
          operator: (['gp', 'robi', 'banglalink', 'airtel', 'teletalk', 'skitto'].includes(item.operator)
            ? item.operator
            : 'gp') as any,
          operatorName: item.operatorName || OP_NAMES[item.operator] || 'Grameenphone',
          packageName: item.packageName || 'কম্বো প্যাক',
          minutes: Number(item.minutes) || 0,
          internetGB: Number(item.internetGB) || 0,
          validityDays: Number(item.validityDays) || 30,
          priceTK: Number(item.priceTK) || 450,
          regularPriceTK: Number(item.regularPriceTK) || Number(item.priceTK) + 120,
          cashbackTK: Number(item.cashbackTK) || 100,
          division: item.division || 'অল বিডি (All BD)',
          title: item.title || `${item.operatorName || 'অপারেটর'} ${item.internetGB || 0}GB + ${item.minutes || 0}Min`,
        }));
      }
    }

    return generateInstantTelecomOffers(prompt, targetOperator);
  } catch (err: any) {
    // If Gemini fails, is throttled (503), or times out, immediately return instant fallback
    return generateInstantTelecomOffers(prompt, targetOperator);
  }
}

export async function generateChatReplyWithGemini(query: string): Promise<string> {
  const apiKey = process.env.GEMINI_API_KEY;
  const lower = query.toLowerCase();

  // Instant built-in telecom responses for common queries (0ms latency!)
  if (lower.includes('gp') || lower.includes('গ্রামীন') || lower.includes('grameenphone')) {
    return `📱 **গ্রামীণফোন (GP) কুইক সার্ভিস কোড ও অফার:**\n• মেইন ব্যালেন্স: *566#\n• মিনিট ব্যালেন্স: *121*1*2#\n• ইন্টারনেট চেক: *121*1*4#\n• আজকের হট অফার: ৫০ জিবি + ৮০০ মিনিট (৳৫৪৯, ক্যাশব্যাক ৳২০০)।`;
  }
  if (lower.includes('robi') || lower.includes('রবি')) {
    return `📱 **রবি (Robi) কুইক সার্ভিস কোড ও অফার:**\n• ব্যালেন্স চেক: *222#\n• ডাটা ও মিনিট: *3#\n• আজকের ধামাকা: ৪৫ জিবি + ৮০০ মিনিট (৳৫৩৯, ক্যাশব্যাক ৳১৬০)।`;
  }
  if (lower.includes('banglalink') || lower.includes('বাংলালিংক')) {
    return `📱 **বাংলালিংক (Banglalink) কুইক সার্ভিস কোড:**\n• ব্যালেন্স চেক: *124#\n• ডাটা চেক: *5000*500#\n• আজকের অফার: ৫০ জিবি ইন্টারনেট মাত্র ৳৩৯৯ তে ক্যাশব্যাক সহ।`;
  }
  if (lower.includes('airtel') || lower.includes('এয়ারটেল')) {
    return `📱 **এয়ারটেল (Airtel) কুইক সার্ভিস কোড:**\n• ব্যালেন্স চেক: *778#\n• ডাটা চেক: *3#\n• স্টুডেন্ট অফার: ৩০ জিবি + ৬০০ মিনিট মাত্র ৳৩৮৮ তে ক্যাশব্যাক সহ।`;
  }
  if (lower.includes('ক্যাশব্যাক') || lower.includes('লাভ') || lower.includes('হিসাব')) {
    return `💰 **ড্রাইভ অফার লাভ ও ক্যাশব্যাক গাইড:**\nড্রাইভ অফার বিক্রি করে প্রতি সিমে গড়ে ৳৮০ থেকে ৳২০০ পর্যন্ত ক্যাশব্যাক পাওয়া যায়। টালি খাতায় বাকি ও জমা সঠিকভাবে এন্ট্রি রাখলে ব্যবসার হিসাব ১০০% নিখুঁত থাকে।`;
  }

  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return `ধন্যবাদ আপনার প্রশ্নের জন্য! "${query}" সংক্রান্ত যেকোনো তথ্যে আপনি অফার জেনারেটর ব্যবহার করে দ্রুত ড্রাইভ অফার তৈরি করতে পারেন অথবা সরাসরি WhatsApp সাপোর্টে যোগাযোগ করতে পারেন।`;
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    const apiPromise = ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `You are an expert Bangladeshi Telecom AI assistant. The user asks: "${query}". Provide a short, direct, polite response in Bengali (maximum 3 bullet points or 3 sentences) focusing on mobile recharge, drive offers, or USSD codes.`,
      config: {
        maxOutputTokens: 250,
      },
    });

    const timeoutPromise = new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error('Chat timeout')), 2200)
    );

    const res = await Promise.race([apiPromise, timeoutPromise]);
    return res.text || `আপনার প্রশ্নের উত্তর প্রক্রিয়াধীন। অনুগ্রহ করে পুনরায় চেষ্টা করুন।`;
  } catch {
    return `ধন্যবাদ আপনার প্রশ্নের জন্য! "${query}" বিষয়ে ড্রাইভ ফোল্ডার থেকে উপযুক্ত অফার নির্বাচন করতে পারেন অথবা অ্যাডমিন প্যানেল থেকে অফার পরিচালনা করতে পারেন।`;
  }
}
