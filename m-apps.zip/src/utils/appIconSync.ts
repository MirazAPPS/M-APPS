/**
 * Dynamic App Icon & PWA Manifest Synchronizer
 * Ensures the user's uploaded PNG logo is immediately set as the
 * Android App Icon, PWA install icon, Apple Touch Icon, and Favicon.
 */

export interface GeneratedIcons {
  icon192: string;
  icon512: string;
  maskable512: string;
  appleIcon: string;
}

/**
 * Resizes an image source using an in-memory Canvas to target dimensions and returns Data URL.
 */
export async function generateResizedImageDataUrl(
  imageSrc: string,
  width: number,
  height: number,
  isMaskable: boolean = false
): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(imageSrc);
          return;
        }

        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';

        if (isMaskable) {
          // Android maskable icons require a solid background and ~15% safe padding
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, width, height);

          const safePadding = Math.round(width * 0.125);
          const drawW = width - safePadding * 2;
          const drawH = height - safePadding * 2;

          // Preserve aspect ratio
          const scale = Math.min(drawW / img.width, drawH / img.height);
          const targetW = img.width * scale;
          const targetH = img.height * scale;
          const x = (width - targetW) / 2;
          const y = (height - targetH) / 2;

          ctx.drawImage(img, x, y, targetW, targetH);
        } else {
          // Transparent background, centered contain
          ctx.clearRect(0, 0, width, height);
          const scale = Math.min(width / img.width, height / img.height);
          const targetW = img.width * scale;
          const targetH = img.height * scale;
          const x = (width - targetW) / 2;
          const y = (height - targetH) / 2;

          ctx.drawImage(img, x, y, targetW, targetH);
        }

        resolve(canvas.toDataURL('image/png'));
      } catch (err) {
        console.error('Error in canvas resize:', err);
        resolve(imageSrc);
      }
    };
    img.onerror = () => {
      resolve(imageSrc);
    };
    img.src = imageSrc;
  });
}

/**
 * Updates DOM icon tags and generates a dynamic Web App Manifest blob
 * so Android Phone "Install App" uses the uploaded PNG logo as the home screen icon.
 */
let currentManifestBlobUrl: string | null = null;

export async function syncAppIconAndManifest(
  logoUrl: string,
  appName: string = 'M APPS',
  tagline: string = 'মোবাইল রিচার্জ অ্যাপ'
) {
  if (typeof window === 'undefined' || !logoUrl) return;

  try {
    // 1. Generate multi-resolution icons
    const [icon192, icon512, maskable512, appleIcon] = await Promise.all([
      generateResizedImageDataUrl(logoUrl, 192, 192, false),
      generateResizedImageDataUrl(logoUrl, 512, 512, false),
      generateResizedImageDataUrl(logoUrl, 512, 512, true),
      generateResizedImageDataUrl(logoUrl, 180, 180, false),
    ]);

    // 2. Update favicon & Apple touch icons in DOM
    const updateLinkTag = (selector: string, href: string, attributes?: Record<string, string>) => {
      let link = document.querySelector(selector) as HTMLLinkElement | null;
      if (!link) {
        link = document.createElement('link');
        document.head.appendChild(link);
      }
      link.href = href;
      if (attributes) {
        Object.entries(attributes).forEach(([k, v]) => link!.setAttribute(k, v));
      }
    };

    updateLinkTag('link[rel="apple-touch-icon"]', appleIcon, { rel: 'apple-touch-icon' });
    updateLinkTag('link[rel="icon"][sizes="192x192"]', icon192, { rel: 'icon', type: 'image/png', sizes: '192x192' });
    updateLinkTag('link[rel="icon"]:not([sizes])', icon192, { rel: 'icon', type: 'image/png' });

    // 3. Create dynamic Web App Manifest
    const dynamicManifest = {
      id: '/',
      name: `${appName} - ${tagline}`,
      short_name: appName.slice(0, 12),
      description: `${appName} - সকল মোবাইল অপারেটরের রিচার্জ ও হিসাব খাতা টেলিকম অ্যাপ্লিকেশন।`,
      start_url: '/',
      scope: '/',
      display: 'standalone',
      display_override: ['standalone', 'fullscreen', 'window-controls-overlay'],
      orientation: 'portrait',
      background_color: '#ffffff',
      theme_color: '#1d4ed8',
      categories: ['finance', 'utilities', 'business'],
      icons: [
        {
          src: icon192,
          sizes: '192x192',
          type: 'image/png',
          purpose: 'any',
        },
        {
          src: icon512,
          sizes: '512x512',
          type: 'image/png',
          purpose: 'any',
        },
        {
          src: maskable512,
          sizes: '512x512',
          type: 'image/png',
          purpose: 'maskable',
        },
      ],
    };

    const manifestBlob = new Blob([JSON.stringify(dynamicManifest)], { type: 'application/json' });
    if (currentManifestBlobUrl) {
      URL.revokeObjectURL(currentManifestBlobUrl);
    }
    currentManifestBlobUrl = URL.createObjectURL(manifestBlob);

    updateLinkTag('link[rel="manifest"]', currentManifestBlobUrl, { rel: 'manifest' });

    // 4. Send to server backend to sync public/ and android/ mipmaps if available
    if (logoUrl.startsWith('data:image')) {
      fetch('/api/save-logo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: logoUrl }),
      }).catch((err) => {
        // Non-blocking background sync note
        console.warn('Backend icon sync note:', err);
      });
    }

    return { icon192, icon512, maskable512, appleIcon };
  } catch (err) {
    console.error('Failed to sync app icon and manifest:', err);
  }
}
