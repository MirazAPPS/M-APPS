import React from 'react';
import { Volume2 } from 'lucide-react';
import { speakText } from '../utils';

interface NoticeBannerProps {
  notice: string;
  title?: string;
  enabled?: boolean;
  isTop?: boolean;
}

export const NoticeBanner: React.FC<NoticeBannerProps> = ({
  notice,
  title = 'নোটিফিকেশন',
  enabled = true,
  isTop = true,
}) => {
  if (!notice || enabled === false) return null;

  return (
    <div
      className="w-full bg-white text-slate-800 border-b border-slate-200/90 px-2.5 sm:px-3 py-1.5 flex items-center gap-2 overflow-hidden shadow-2xs z-30 select-none"
      style={
        isTop
          ? {
              paddingTop: 'max(5px, calc(env(safe-area-inset-top, 0px) + 3px))',
            }
          : undefined
      }
    >
      <button
        type="button"
        onClick={() => speakText(`${title ? `${title}: ` : ''}${notice}`, 'bn')}
        title="নোটিফিকেশন শুনুন"
        className="shrink-0 text-blue-600 bg-blue-50 hover:bg-blue-100 active:scale-90 p-1.5 rounded-lg cursor-pointer transition-transform border border-blue-200/70 shadow-2xs"
      >
        <Volume2 className="w-3.5 h-3.5 text-blue-600 animate-pulse" />
      </button>
      {title && (
        <span className="shrink-0 text-[10px] sm:text-[11px] font-black bg-blue-600 text-white px-2 py-0.5 rounded-md shadow-2xs tracking-tight">
          {title}
        </span>
      )}
      <div className="overflow-hidden relative flex-1">
        <div className="whitespace-nowrap inline-block animate-marquee text-[11.5px] sm:text-xs font-bold text-slate-800 tracking-tight">
          {notice}
        </div>
      </div>
    </div>
  );
};
