import React, { useState } from 'react';
import {
  Smartphone,
  Copy,
  Check,
  CheckCircle2,
  AlertCircle,
  Zap,
  Globe,
  Radio,
  FileCode,
  ArrowRight,
  RefreshCw,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import { BKashLogo, NagadLogo, RocketLogo, UpayLogo } from './OperatorLogos';
import { parseTelecomSmsNotification, ParsedSmsPayment } from '../utils';
import { IncomingPaymentRecord } from '../types';

interface AutoSmsSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAutoAddIncomingPayment: (record: IncomingPaymentRecord) => Promise<void> | void;
  onShowToast: (msg: string) => void;
}

export const AutoSmsSyncModal: React.FC<AutoSmsSyncModalProps> = ({
  isOpen,
  onClose,
  onAutoAddIncomingPayment,
  onShowToast,
}) => {
  const [activeTab, setActiveTab] = useState<'app_guide' | 'simulator' | 'webhook_api'>('simulator');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // SMS Simulator State
  const [sampleSms, setSampleSms] = useState(
    'You have received Tk 500.00 from 01712345678. Fee Tk 0.00. Balance Tk 1,520.50. TrxID BK992288 at 02/10/2026 14:30'
  );
  const [parsedResult, setParsedResult] = useState<ParsedSmsPayment | null>(() =>
    parseTelecomSmsNotification(
      'You have received Tk 500.00 from 01712345678. Fee Tk 0.00. Balance Tk 1,520.50. TrxID BK992288 at 02/10/2026 14:30'
    )
  );
  const [isProcessing, setIsProcessing] = useState(false);
  const [syncedHistory, setSyncedHistory] = useState<IncomingPaymentRecord[]>([]);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    onShowToast('ক্লিপবোর্ডে কপি হয়েছে!');
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleTextChange = (text: string) => {
    setSampleSms(text);
    const parsed = parseTelecomSmsNotification(text);
    setParsedResult(parsed);
  };

  const handleQuickSample = (type: 'bkash' | 'nagad' | 'rocket') => {
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    let sample = '';
    if (type === 'bkash') {
      sample = `You have received Tk 500.00 from 0171122${randomSuffix}. Fee Tk 0.00. Balance Tk 4,200.00. TrxID BK${randomSuffix}77 at 02/10/2026 15:45`;
    } else if (type === 'nagad') {
      sample = `Money Received. Amount: Tk 1,000.00, Sender: 0183344${randomSuffix}, TxnID: NG${randomSuffix}88, Date: 02/10/2026 15:46, Balance: Tk 12,500.00.`;
    } else {
      sample = `Cash In received Tk 300.00 from 0192233${randomSuffix}. TxnId: RK${randomSuffix}99 at 02/10/2026 15:47. Balance: Tk 3,120.00`;
    }
    setSampleSms(sample);
    const parsed = parseTelecomSmsNotification(sample);
    setParsedResult(parsed);
  };

  const handleSyncToFirestore = async () => {
    if (!parsedResult) {
      onShowToast('⚠️ কোনো ট্রানজেকশন আইডি বা অ্যামাউন্ট পাওয়া যায়নি');
      return;
    }

    setIsProcessing(true);
    const newRecord: IncomingPaymentRecord = {
      id: `INC-SMS-${Date.now()}`,
      gateway: parsedResult.gateway,
      trxId: parsedResult.trxId,
      amount: parsedResult.amount,
      senderNumber: parsedResult.senderNumber,
      walletNumber: '',
      isUsed: false,
      createdAt: new Date().toISOString(),
      note: `SMS অটো সিঙ্ক (${parsedResult.gateway}): ${parsedResult.senderNumber ? 'প্রেরক ' + parsedResult.senderNumber : 'অটো ডিটেক্ট'}`,
    };

    try {
      await onAutoAddIncomingPayment(newRecord);
      setSyncedHistory((prev) => [newRecord, ...prev]);
      onShowToast(`✓ ফায়ারবেসে সফলভাবে TrxID (${parsedResult.trxId}) ও ৳${parsedResult.amount} সংরক্ষিত হয়েছে!`);
    } catch {
      onShowToast('ফায়ারবেসে সংরক্ষণ করতে সমস্যা হয়েছে');
    } finally {
      setIsProcessing(false);
    }
  };

  // Webhook JSON snippet for MacroDroid / Tasker / SMS Forwarder
  const webhookUrl = `${window.location.origin}/api/sms-webhook`;
  const webhookBodySample = JSON.stringify(
    {
      secret_key: 'YOUR_SECRET_KEY',
      sender: '{sms_sender}',
      message: '{sms_body}',
      timestamp: '{sms_time}',
    },
    null,
    2
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-100 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 px-5 py-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center backdrop-blur-sm shadow-xs">
              <Radio className="w-5 h-5 text-white animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-extrabold text-white">অটো এসএমএস সিঙ্ক ও ফায়ারবেস ইন্টিগ্রেশন</h3>
                <span className="px-2 py-0.5 bg-emerald-400 text-emerald-950 font-black text-[10px] rounded-full">
                  LIVE
                </span>
              </div>
              <p className="text-xs text-emerald-100">
                বিকাশ/নগদ সিমে টাকা আসার এসএমএস রিড করে সাথে সাথে ফায়ারবেসে TrxID যোগ করার সিস্টেম
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center border-b border-slate-200 bg-slate-50 px-4 pt-2 shrink-0 gap-1 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('simulator')}
            className={`px-4 py-2.5 text-xs font-black rounded-t-xl transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'simulator'
                ? 'bg-white text-emerald-700 border-t-2 border-emerald-600 shadow-2xs font-extrabold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-amber-500" />
            <span>লাইভ এসএমএস সিমুলেটর ও টেস্ট</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('app_guide')}
            className={`px-4 py-2.5 text-xs font-black rounded-t-xl transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'app_guide'
                ? 'bg-white text-emerald-700 border-t-2 border-emerald-600 shadow-2xs font-extrabold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 text-blue-500" />
            <span>মোবাইল অটো এসএমএস রিডার সেটআপ গাইড</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('webhook_api')}
            className={`px-4 py-2.5 text-xs font-black rounded-t-xl transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'webhook_api'
                ? 'bg-white text-emerald-700 border-t-2 border-emerald-600 shadow-2xs font-extrabold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileCode className="w-3.5 h-3.5 text-purple-500" />
            <span>ফায়ারবেস ওয়েবহুক কোড (API)</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {/* TAB 1: SIMULATOR */}
          {activeTab === 'simulator' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-3.5 text-xs text-emerald-950 space-y-1.5">
                <div className="flex items-center gap-2 font-black text-emerald-900">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <span>স্মার্ট এসএমএস পার্সার ইঞ্জিন (AI/Regex Parser)</span>
                </div>
                <p className="text-[11px] text-emerald-800 leading-relaxed font-medium">
                  আপনার বিকাশ বা নগদ সিমের ফোনে যে এসএমএস আসে, তা হুবহু নিচে পেস্ট করুন বা দ্রুত ডেমো বাটনে ক্লিক করুন। ইঞ্জিন স্বয়ংক্রিয়ভাবে TrxID, অ্যামাউন্ট ও গেটওয়ে ফিল্টার করে সরাসরি ফায়ারবেসে স্টোর করবে।
                </p>
              </div>

              {/* Quick Sample Buttons */}
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[11px] font-bold text-slate-500">টেস্ট এসএমএস লোড করুন:</span>
                <button
                  type="button"
                  onClick={() => handleQuickSample('bkash')}
                  className="px-2.5 py-1 bg-pink-50 hover:bg-pink-100 text-pink-700 border border-pink-200 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1"
                >
                  <BKashLogo className="w-3.5 h-3.5" />
                  <span>বিকাশ ডেমো (৳৫০০)</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickSample('nagad')}
                  className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1"
                >
                  <NagadLogo className="w-3.5 h-3.5" />
                  <span>নগদ ডেমো (৳১০০০)</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickSample('rocket')}
                  className="px-2.5 py-1 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1"
                >
                  <RocketLogo className="w-3.5 h-3.5" />
                  <span>রকেট ডেমো (৳৩০০)</span>
                </button>
              </div>

              {/* SMS Text Area */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  সিমে প্রাপ্ত এসএমএস বা নোটিফিকেশনের লেখা পেস্ট করুন:
                </label>
                <textarea
                  rows={3}
                  value={sampleSms}
                  onChange={(e) => handleTextChange(e.target.value)}
                  placeholder="বিকাশ বা নগদ থেকে আসা এসএমএস এখানে দিন..."
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-mono font-medium text-slate-900 outline-none focus:border-emerald-600 focus:bg-white transition-all shadow-2xs"
                />
              </div>

              {/* Parser Output Box */}
              {parsedResult ? (
                <div className="bg-white border-2 border-emerald-500 rounded-2xl p-4 shadow-xs space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                    <span className="text-xs font-black text-emerald-800 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>এসএমএস সফলভাবে রিড করা হয়েছে!</span>
                    </span>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                      ভ্যালিড পেমেন্ট
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                    <div className="p-2.5 bg-slate-50 rounded-xl">
                      <span className="text-[10px] text-slate-500 block">গেটওয়ে</span>
                      <span className="font-extrabold text-slate-900">{parsedResult.gateway}</span>
                    </div>
                    <div className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-200">
                      <span className="text-[10px] text-emerald-700 block font-bold">TrxID</span>
                      <span className="font-mono font-black text-sm text-emerald-900 tracking-wider">
                        {parsedResult.trxId}
                      </span>
                    </div>
                    <div className="p-2.5 bg-slate-50 rounded-xl">
                      <span className="text-[10px] text-slate-500 block">টাকার পরিমাণ</span>
                      <span className="font-mono font-black text-sm text-slate-900">৳{parsedResult.amount}</span>
                    </div>
                    <div className="p-2.5 bg-slate-50 rounded-xl">
                      <span className="text-[10px] text-slate-500 block">প্রেরক নম্বর</span>
                      <span className="font-mono font-bold text-slate-800">
                        {parsedResult.senderNumber || 'অটো রিসিভড'}
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleSyncToFirestore}
                    disabled={isProcessing}
                    className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold text-xs rounded-xl shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-98"
                  >
                    {isProcessing ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <>
                        <Zap className="w-4 h-4 text-amber-300" />
                        <span>ফায়ারবেস ডেটাবেজে সরাসরি TrxID যুক্ত করুন</span>
                      </>
                    )}
                  </button>
                </div>
              ) : (
                <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-700 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>উপরে দেওয়া টেক্সট থেকে সঠিক TrxID বা অ্যামাউন্ট পাওয়া যায়নি। বিকাশ/নগদের আসল এসএমএস প্রদান করুন।</span>
                </div>
              )}

              {/* Synced List in this session */}
              {syncedHistory.length > 0 && (
                <div className="border-t border-slate-100 pt-3 space-y-2">
                  <span className="text-xs font-black text-slate-800">
                    এই সেশনে ফায়ারবেসে যুক্ত হওয়া TrxID ({syncedHistory.length}টি):
                  </span>
                  <div className="space-y-1.5">
                    {syncedHistory.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-slate-900 bg-white px-2 py-0.5 rounded border border-slate-200">
                            {item.trxId}
                          </span>
                          <span className="font-extrabold text-emerald-700">৳{item.amount}</span>
                        </div>
                        <span className="text-[10px] text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full font-bold">
                          ✓ ফায়ারবেসে সংরক্ষিত
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: MOBILE AUTO SMS READER GUIDE */}
          {activeTab === 'app_guide' && (
            <div className="space-y-4 animate-fadeIn text-xs">
              <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 text-blue-950 space-y-2">
                <div className="flex items-center gap-2 font-black text-blue-900">
                  <Smartphone className="w-4 h-4 text-blue-600" />
                  <span>মোবাইল সিমে টাকা আসার সাথে সাথে ফায়ারবেসে যাওয়ার ৩টি সহজ উপায়:</span>
                </div>
                <p className="text-[11px] text-blue-800 leading-relaxed font-medium">
                  টেলিকম ও অটো-রিচার্জ ব্যবসায়ীদের জন্য বিকাশ/নগদ সিমের ফোনে একটি লাইটওয়েট অ্যাপ চালু রাখা হয়। টাকা আসলেই সেটি নোটিফিকেশন/এসএমএস রিড করে ১ সেকেন্ডে ফায়ারবেসে TrxID পুশ করে দেয়।
                </p>
              </div>

              {/* Option 1: MacroDroid / SMS Forwarder (No-code, 100% Free) */}
              <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-2.5 shadow-2xs">
                <div className="flex items-center justify-between">
                  <span className="font-black text-slate-900 text-sm flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-mono font-bold text-xs">
                      ১
                    </span>
                    <span>MacroDroid / SMS Forwarder (সবচেয়ে জনপ্রিয় ও ফ্রি)</span>
                  </span>
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full font-black text-[10px]">
                    রিকমেন্ডেড
                  </span>
                </div>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  গুগল প্লে-স্টোর থেকে <strong>MacroDroid</strong> বা <strong>SMS Forwarder</strong> অ্যাপ নামিয়ে আপনার বিকাশ/নগদ সিমের ফোনে ইনস্টল করুন।
                </p>
                <div className="bg-slate-50 rounded-xl p-3 space-y-1 font-mono text-[11px] text-slate-800 border border-slate-200">
                  <div className="font-sans font-bold text-slate-900 text-xs mb-1">সেটআপ কনফিগারেশন:</div>
                  <div>• <strong>Trigger:</strong> SMS Received from: bKash, 16247, Nagad, 16167</div>
                  <div>• <strong>Action:</strong> HTTP Request (POST) to Webhook</div>
                  <div>• <strong>URL:</strong> <span className="text-emerald-700">{webhookUrl}</span></div>
                </div>
              </div>

              {/* Option 2: Dedicated Android Foreground Gateway */}
              <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-2.5 shadow-2xs">
                <span className="font-black text-slate-900 text-sm flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-mono font-bold text-xs">
                    ২
                  </span>
                  <span>এন্ড্রয়েড ব্যাকগ্রাউন্ড ব্রডকাস্ট রিসিভার (Firebase Cloud Firestore)</span>
                </span>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  আপনার ফোনের <code className="bg-slate-100 px-1 rounded">SmsReceiver</code> ক্লাস <code className="bg-slate-100 px-1 rounded">android.provider.Telephony.SMS_RECEIVED</code> ব্রডকাস্ট থেকে টেক্সট ধরে সরাসরি ফায়ারবেসের <code className="bg-slate-100 px-1 rounded">incoming_payments</code> কালেকশনে সেভ করে দেয়।
                </p>
              </div>

              {/* Option 3: Android Notification Listener Service */}
              <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-2.5 shadow-2xs">
                <span className="font-black text-slate-900 text-sm flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-purple-100 text-purple-700 flex items-center justify-center font-mono font-bold text-xs">
                    ৩
                  </span>
                  <span>NotificationListenerService (বিকাশ/নগদ অ্যাপ নোটিফিকেশন থেকে)</span>
                </span>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  সিম ছাড়াও যদি আপনার ফোনে বিকাশ বা নগদ মার্চেন্ট অ্যাপ থাকে, অ্যাপের পুশ নোটিফিকেশন থেকে সরাসরি TrxID পড়ে ফায়ারবেসে সেভ হয়ে যাবে।
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: WEBHOOK API CODE */}
          {activeTab === 'webhook_api' && (
            <div className="space-y-4 animate-fadeIn text-xs">
              <div>
                <h4 className="font-black text-slate-900 text-sm mb-1">
                  অটোমেটেড এসএমএস ওয়েবহুক এনপয়েন্ট
                </h4>
                <p className="text-slate-500 text-[11px]">
                  আপনার ফোনের যেকোনো অটোমেশন অ্যাপ (যেমন MacroDroid, Tasker বা কাস্টম এন্ড্রয়েড অ্যাপ) থেকে এই এনপয়েন্টে POST কল করলে ফায়ারবেসে সাথে সাথে TrxID সেভ হয়ে যাবে।
                </p>
              </div>

              {/* Endpoint Box */}
              <div className="bg-slate-900 text-slate-100 rounded-2xl p-3.5 space-y-2">
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>POST URL (Webhook):</span>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(webhookUrl, 'url')}
                    className="text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1 cursor-pointer"
                  >
                    {copiedKey === 'url' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedKey === 'url' ? 'কপি হয়েছে' : 'URL কপি'}</span>
                  </button>
                </div>
                <div className="font-mono text-emerald-400 font-bold break-all text-xs bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
                  {webhookUrl}
                </div>
              </div>

              {/* Payload Box */}
              <div className="bg-slate-900 text-slate-100 rounded-2xl p-3.5 space-y-2">
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>JSON Payload Sample:</span>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(webhookBodySample, 'payload')}
                    className="text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1 cursor-pointer"
                  >
                    {copiedKey === 'payload' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedKey === 'payload' ? 'কপি হয়েছে' : 'JSON কপি'}</span>
                  </button>
                </div>
                <pre className="font-mono text-[11px] text-slate-200 bg-slate-800/80 p-2.5 rounded-xl border border-slate-700 overflow-x-auto">
                  {webhookBodySample}
                </pre>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 border-t border-slate-100 px-5 py-3 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
            <Radio className="w-3.5 h-3.5 text-emerald-600" />
            <span>ফায়ারবেস রিয়েল-টাইম লিসেনার সক্রিয়</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl shadow-xs cursor-pointer transition-all"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
