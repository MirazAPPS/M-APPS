import React from 'react';

export interface TakaSignProps {
  className?: string;
  color?: string; // Optional custom text color class for ৳
}

/**
 * Standard Bangladeshi Currency Symbol Component (৳)
 * Displays ৳ with a refined, stylish accent color (default: warm amber/golden)
 * that is slightly distinct from the number text color.
 *
 * Example usage:
 *   500 <TakaSign />               => renders 500 ৳ with amber colored ৳
 *   500 <TakaSign color="text-amber-300" /> => on dark/red/green cards
 */
export const TakaSign: React.FC<TakaSignProps> = ({
  className = '',
  color = 'text-amber-500 dark:text-amber-400',
}) => {
  return (
    <span
      className={`inline-block font-bold ml-1 select-none ${color} ${className}`}
      aria-label="টাকা"
    >
      ৳
    </span>
  );
};

export default TakaSign;
