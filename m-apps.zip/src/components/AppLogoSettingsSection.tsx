import React, { useState, useRef, useEffect } from 'react';
import {
  Upload,
  CheckCircle,
  RefreshCw,
  Trash2,
  Sliders,
  Palette,
  Sparkles,
  Check,
  ImageIcon,
  Link as LinkIcon,
  Eye,
  Smartphone,
} from 'lucide-react';
import { AppSettings } from '../types';
import { syncAppIconAndManifest } from '../utils/appIconSync';
import { updateAppSettingsInFirestore } from '../lib/firebase';
import { MAppsLogo } from './MAppsLogo';

interface AppLogoSettingsSectionProps {
  settings: AppSettings;
  onUpdateSettings: (updated: AppSettings) => void;
  onShowToast?: (msg: string) => void;
}

/**
 * Optimize uploaded image to a clean PNG/JPEG base64 (Max dimension 512px)
 */
const optimizeLogoImage = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = (e) => {
      const img = new Image();
      img.onerror = reject;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDim = 512;
        let width = img.naturalWidth || img.width;
        let height = img.naturalHeight || img.height;

        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }

        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, width, height);

        const isPng = file.type === 'image/png' || file.name.toLowerCase().endsWith('.png');
        const mimeType = isPng ? 'image/png' : 'image/jpeg';
        const quality = isPng ? undefined : 0.9;
        const compressedBase64 = canvas.toDataURL(mimeType, quality);
        resolve(compressedBase64);
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  });
};

// Built-in Premium Telecom Logo Presets (High-res SVG / vector data URLs)
const LOGO_PRESETS = [
  {
    id: 'preset_bolt',
    name: 'টেলিকম সুপার বোল্ট (নীল)',
    url: '/app-logo.png',
  },
  {
    id: 'preset_emerald',
    name: 'মডার্ন পে (সবুজ)',
    url: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><defs><linearGradient id="emg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="%23059669"/><stop offset="100%" stop-color="%23047857"/></linearGradient></defs><rect width="512" height="512" rx="128" fill="url(%23emg)"/><path d="M256 120 L370 200 L370 330 L256 400 L142 330 L142 200 Z" fill="none" stroke="%23ffffff" stroke-width="24" stroke-linejoin="round"/><path d="M256 160 L320 280 L260 280 L270 360 L200 250 L250 250 Z" fill="%23facc15"/></svg>',
  },
  {
    id: 'preset_gold',
    name: 'রয়্যাল রিচার্জ (গোল্ডেন)',
    url: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><defs><linearGradient id="gdg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="%23d97706"/><stop offset="100%" stop-color="%23b45309"/></linearGradient></defs><rect width="512" height="512" rx="128" fill="url(%23gdg)"/><circle cx="256" cy="256" r="160" fill="none" stroke="%23ffffff" stroke-width="20"/><path d="M256 150 L280 230 L360 230 L295 280 L320 360 L256 310 L192 360 L217 280 L152 230 L232 230 Z" fill="%23ffffff"/></svg>',
  },
  {
    id: 'preset_purple',
    name: 'স্মার্ট ফাস্টপে (পার্পল)',
    url: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><defs><linearGradient id="prp" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="%237c3aed"/><stop offset="100%" stop-color="%234c1d95"/></linearGradient></defs><rect width="512" height="512" rx="128" fill="url(%23prp)"/><path d="M170 340 L170 170 L260 170 C310 170 340 195 340 235 C340 275 310 300 260 300 L215 300 L215 340 Z" fill="%23ffffff"/><circle cx="250" cy="235" r="28" fill="%237c3aed"/></svg>',
  },
];

export const AppLogoSettingsSection: React.FC<AppLogoSettingsSectionProps> = ({
  settings,
  onUpdateSettings,
  onShowToast,
}) => {
  // Local Form States
  const [appName, setAppName] = useState(settings?.appName || 'M APPS');
  const [appTagline, setAppTagline] = useState(settings?.appTagline || 'মোবাইল রিচার্জ অ্যাপ');
  const [appLogoUrl, setAppLogoUrl] = useState(settings?.appLogoUrl || '/app-logo.png');
  const [urlInput, setUrlInput] = useState('');
  const [logoFileName, setLogoFileName] = useState<string>('');
  const [isUploading, setIsUploading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isSavedRecently, setIsSavedRecently] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync state if settings prop changes from parent
  useEffect(() => {
    if (settings?.appLogoUrl) setAppLogoUrl(settings.appLogoUrl);
    if (settings?.appName) setAppName(settings.appName);
    if (settings?.appTagline) setAppTagline(settings.appTagline);
  }, [settings?.appLogoUrl, settings?.appName, settings?.appTagline]);

  /**
   * Core function to persist settings across:
   * 1. App State (`onUpdateSettings`)
   * 2. LocalStorage (`telecom_app_settings`)
   * 3. Broadcast Event (`mapps-logo-updated`) for instant UI re-rendering
   * 4. Firebase Firestore (`app_settings/global`)
   * 5. PWA Manifest & App Icons
   */
  const persistLogoSettings = async (newLogoUrl: string, newName?: string, newTagline?: string) => {
    const cleanLogo = newLogoUrl.trim() || '/app-logo.png';
    const cleanName = (newName !== undefined ? newName : appName).trim() || 'M APPS';
    const cleanTagline = (newTagline !== undefined ? newTagline : appTagline).trim() || 'মোবাইল রিচার্জ অ্যাপ';

    const updated: AppSettings = {
      ...settings,
      appName: cleanName,
      appTagline: cleanTagline,
      appLogoUrl: cleanLogo,
      logoPreset: 'custom',
    };

    // 1. Update React parent state
    onUpdateSettings(updated);

    // 2. Save to localStorage
    try {
      localStorage.setItem('telecom_app_settings', JSON.stringify(updated));
      window.dispatchEvent(new Event('storage'));
      window.dispatchEvent(new Event('mapps-logo-updated'));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }

    // 3. Save to Firebase Firestore
    try {
      await updateAppSettingsInFirestore({
        settings: updated,
      });
    } catch (err) {
      console.warn('[Firestore] Error saving app logo settings:', err);
    }

    // 4. Update browser tab favicon & manifest
    try {
      await syncAppIconAndManifest(cleanLogo, cleanName, cleanTagline);
    } catch {}

    setIsSavedRecently(true);
    if (onShowToast) {
      onShowToast('✓ অ্যাপের লোগো ও নাম সফলভাবে সেভ হয়েছে!');
    }
    setTimeout(() => setIsSavedRecently(false), 3500);
  };

  /**
   * Handle File Upload from device
   */
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      if (onShowToast) onShowToast('অনুগ্রহ করে একটি ছবি বা PNG/JPG ফাইল আপলোড করুন');
      return;
    }

    setIsUploading(true);
    setLogoFileName(file.name);

    try {
      if (onShowToast) onShowToast('লোগো প্রসেস ও আপলোড হচ্ছে...');

      // Optimize image in memory
      const optimizedBase64 = await optimizeLogoImage(file);
      setAppLogoUrl(optimizedBase64);

      // Save to server backend `/api/save-logo` if available
      let serverSavedUrl = '';
      try {
        const resp = await fetch('/api/save-logo', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ imageBase64: optimizedBase64 }),
        });
        if (resp.ok) {
          const resJson = await resp.json();
          if (resJson && resJson.success && resJson.url) {
            serverSavedUrl = resJson.url;
          }
        }
      } catch (err) {
        console.warn('Server save-logo fallback to optimized base64:', err);
      }

      const finalLogoUrl = serverSavedUrl || optimizedBase64;
      setAppLogoUrl(finalLogoUrl);

      // Persist everywhere immediately!
      await persistLogoSettings(finalLogoUrl);
    } catch (err) {
      console.error('Logo upload error:', err);
      if (onShowToast) onShowToast('লোগো আপলোডে সমস্যা হয়েছে, অনুগ্রহ করে আবার চেষ্টা করুন');
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  /**
   * Handle direct image URL input
   */
  const handleApplyUrl = async () => {
    if (!urlInput.trim()) {
      if (onShowToast) onShowToast('অনুগ্রহ করে একটি ইমেজ লিংক পেস্ট করুন');
      return;
    }
    const cleanUrl = urlInput.trim();
    setAppLogoUrl(cleanUrl);
    await persistLogoSettings(cleanUrl);
    setUrlInput('');
  };

  /**
   * Select Built-in Preset Logo
   */
  const handleSelectPreset = async (presetUrl: string) => {
    setAppLogoUrl(presetUrl);
    await persistLogoSettings(presetUrl);
  };

  /**
   * Save Button (Save Name, Tagline & Logo)
   */
  const handleSave = async () => {
    setIsSaving(true);
    try {
      await persistLogoSettings(appLogoUrl, appName, appTagline);
    } finally {
      setIsSaving(false);
    }
  };

  /**
   * Reset to Original Default Logo
   */
  const handleResetToDefault = async () => {
    const defaultLogo = '/app-logo.png?v=' + Date.now();
    setAppName('M APPS');
    setAppTagline('মোবাইল রিচার্জ অ্যাপ');
    setAppLogoUrl(defaultLogo);
    setLogoFileName('');
    await persistLogoSettings(defaultLogo, 'M APPS', 'মোবাইল রিচার্জ অ্যাপ');
    if (onShowToast) onShowToast('✓ ডিফল্ট লোগো রিস্টোর করা হয়েছে!');
  };

  return (
    <div className="space-y-4 animate-fadeIn pb-8">
      {/* 1. DIRECT LIVE LOGO DISPLAY & PREVIEW CARD */}
      <section className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-5 text-white shadow-xl border border-indigo-800/40 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-4">
          {/* Header Title & Reset */}
          <div className="flex items-center justify-between pb-3 border-b border-white/10 flex-wrap gap-2">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30 shadow-xs">
                <Palette className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-black text-sm text-white">অ্যাপ লোগো ও ব্র্যান্ডিং কন্ট্রোল</h3>
                <p className="text-[11px] text-slate-300">
                  লোগো পরিবর্তন করুন—লগইন স্ক্রিন ও পুরো অ্যাপে সাথে সাথে স্বয়ংক্রিয়ভাবে আপডেট হবে
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleResetToDefault}
              className="text-[11px] font-bold text-slate-300 hover:text-white bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 border border-white/10 cursor-pointer"
              title="ডিফল্ট লোগোতে ফিরে যান"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>ডিফল্ট রিসেট</span>
            </button>
          </div>

          {/* Dual Preview: Live Logo Display + Login Screen Preview */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Live Logo Display */}
            <div className="bg-slate-950/70 rounded-2xl p-4 border border-white/10 flex flex-col items-center justify-center text-center">
              <span className="text-[10px] font-black text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 px-3 py-0.5 rounded-full mb-3 inline-flex items-center gap-1">
                <Check className="w-3 h-3 text-emerald-400" />
                <span>বর্তমানে সক্রিয় লোগো (Live Logo)</span>
              </span>

              {/* Logo Frame */}
              <div className="h-28 sm:h-32 w-36 sm:w-44 px-3 py-2 bg-white rounded-3xl shadow-2xl border-2 border-white/40 flex items-center justify-center transition-transform hover:scale-105 duration-200">
                <img
                  src={appLogoUrl || '/app-logo.png'}
                  alt="App Logo"
                  className="w-full h-full object-contain"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/app-logo.png';
                  }}
                />
              </div>

              <h4 className="text-base font-black text-white mt-3 tracking-wide">
                {appName}
              </h4>
              <p className="text-xs text-indigo-200/80 font-medium mt-0.5">
                {appTagline}
              </p>
            </div>

            {/* Login Screen Frame Preview (সরাসরি লগইন স্ক্রিনের রূপ) */}
            <div className="bg-slate-950/70 rounded-2xl p-4 border border-white/10 flex flex-col items-center justify-center text-center">
              <span className="text-[10px] font-black text-blue-400 bg-blue-500/15 border border-blue-500/30 px-3 py-0.5 rounded-full mb-3 inline-flex items-center gap-1">
                <Smartphone className="w-3 h-3 text-blue-400" />
                <span>লগইন স্ক্রিন প্রিভিউ (Login Screen Fit)</span>
              </span>

              <div className="w-full max-w-[220px] bg-gradient-to-b from-slate-50 to-blue-50/70 p-3 rounded-2xl border border-slate-200 text-slate-900 shadow-lg">
                <div className="h-24 w-32 mx-auto bg-white rounded-2xl shadow-md border-2 border-slate-100 flex items-center justify-center p-1.5 overflow-hidden">
                  <img
                    src={appLogoUrl || '/app-logo.png'}
                    alt="Login Preview"
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="text-center mt-1.5">
                  <span className="text-xs font-black text-slate-900 block leading-tight">{appName}</span>
                  <span className="text-[9px] text-slate-500 font-bold block">{appTagline}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. LOGO UPLOAD & IMAGE URL CONTROLS */}
      <section className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2.5 pb-2.5 border-b border-slate-100">
          <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Upload className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-black text-slate-900 text-sm">নতুন লোগো যুক্ত করার অপশন</h3>
            <p className="text-[11px] text-slate-500 font-medium">
              আপনার ফোন থেকে ছবি আপলোড করুন অথবা যেকোনো ইমেজ লিংক দিয়ে সেট করুন
            </p>
          </div>
        </div>

        {/* Hidden File Input */}
        <input
          type="file"
          ref={fileInputRef}
          accept="image/*"
          onChange={handleFileUpload}
          className="hidden"
        />

        {/* Method 1: Upload from Device */}
        <div
          onClick={() => fileInputRef.current?.click()}
          className="p-5 sm:p-6 bg-slate-50 hover:bg-indigo-50/50 border-2 border-dashed border-indigo-300 hover:border-indigo-500 rounded-2xl transition-all text-center flex flex-col items-center justify-center cursor-pointer group"
        >
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center mb-2.5 shadow-md shadow-indigo-600/30 group-hover:scale-110 transition-transform">
            {isUploading ? (
              <RefreshCw className="w-6 h-6 animate-spin" />
            ) : (
              <Upload className="w-6 h-6" />
            )}
          </div>

          <h4 className="font-black text-sm text-slate-900 mb-1">
            {isUploading ? 'লোগো আপলোড হচ্ছে...' : 'ডিভাইস থেকে ছবি আপলোড করুন'}
          </h4>
          <p className="text-xs text-slate-500 max-w-sm mb-3">
            PNG, JPG বা যেকোনো স্বচ্ছ ব্যাকগ্রাউন্ডের ছবি সিলেক্ট করুন। সাথে সাথে ফিট হয়ে সেভ হবে।
          </p>

          <button
            type="button"
            disabled={isUploading}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white font-black text-xs rounded-xl shadow-md shadow-indigo-600/20 transition-all cursor-pointer flex items-center gap-2"
          >
            <ImageIcon className="w-4 h-4" />
            <span>গ্যালারি / ফাইল থেকে লোগো বাছুন</span>
          </button>
        </div>

        {/* Method 2: Direct Image URL */}
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
          <label className="block text-slate-800 text-xs font-bold">
            অথবা সরাসরি ইমেজ লিংক (Image URL) দিন:
          </label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <LinkIcon className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="url"
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                placeholder="যেমন: https://i.ibb.co/example/logo.png"
                className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-mono text-slate-900 outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-200"
              />
            </div>
            <button
              type="button"
              onClick={handleApplyUrl}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl cursor-pointer transition-all active:scale-95"
            >
              প্রয়োগ করুন
            </button>
          </div>
        </div>

        {/* Method 3: Ready-made Presets */}
        <div className="space-y-2 pt-1">
          <label className="block text-slate-800 text-xs font-bold">
            রেডিমেড প্রফেশনাল টেলিকম লোগো প্রিসেট (ক্লিক করলেই সেট হবে):
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {LOGO_PRESETS.map((preset) => (
              <button
                key={preset.id}
                type="button"
                onClick={() => handleSelectPreset(preset.url)}
                className={`p-2.5 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                  appLogoUrl === preset.url
                    ? 'bg-emerald-50 border-emerald-500 ring-2 ring-emerald-200'
                    : 'bg-white border-slate-200 hover:border-indigo-300'
                }`}
              >
                <div className="w-12 h-12 rounded-xl bg-white p-1 border border-slate-200 flex items-center justify-center shadow-2xs">
                  <img src={preset.url} alt={preset.name} className="w-full h-full object-contain" />
                </div>
                <span className="text-[10px] font-extrabold text-slate-800 line-clamp-1">
                  {preset.name}
                </span>
                {appLogoUrl === preset.url && (
                  <span className="text-[9px] bg-emerald-600 text-white px-2 py-0.5 rounded-full font-bold">
                    সক্রিয়
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* 3. APP NAME & TAGLINE SETTINGS */}
      <section className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2.5 pb-2.5 border-b border-slate-100">
          <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-black text-slate-900 text-sm">অ্যাপের নাম ও সাবটাইটেল</h3>
            <p className="text-[11px] text-slate-500 font-medium">
              লোগোর নিচে প্রদর্শিত নাম ও ট্যাগলাইন পরিবর্তন করুন
            </p>
          </div>
        </div>

        <div className="space-y-3">
          {/* App Name Input */}
          <div>
            <label className="block text-slate-800 text-xs font-bold mb-1">
              অ্যাপের নাম (App Title) <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={appName}
              onChange={(e) => setAppName(e.target.value)}
              placeholder="যেমন: M APPS অথবা মেসার্স মিরাজ টেলিকম"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs font-bold focus:bg-white focus:border-indigo-600 focus:ring-2 focus:ring-indigo-100 outline-none"
            />
          </div>

          {/* App Tagline Input */}
          <div>
            <label className="block text-slate-800 text-xs font-bold mb-1">
              ট্যাগলাইন / সাব-টাইটেল (App Tagline)
            </label>
            <input
              type="text"
              value={appTagline}
              onChange={(e) => setAppTagline(e.target.value)}
              placeholder="যেমন: মোবাইল রিচার্জ অ্যাপ অথবা ২৪ ঘণ্টা অটো রিচার্জ"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs font-medium focus:bg-white focus:border-indigo-600 focus:ring-2 focus:ring-indigo-100 outline-none"
            />
          </div>
        </div>

        {/* Save Button */}
        <div className="pt-2">
          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving}
            className="w-full py-3 bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 hover:from-emerald-700 hover:to-indigo-700 active:scale-[0.99] text-white font-black text-xs rounded-xl shadow-md shadow-emerald-600/25 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
          >
            {isSaving ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <CheckCircle className="w-4 h-4" />
            )}
            <span>সংরক্ষণ করুন (Save Changes)</span>
          </button>
        </div>

        {isSavedRecently && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-center gap-2 text-emerald-800 text-xs font-bold animate-fadeIn">
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>✓ লোগো ও ব্র্যান্ডিং তথ্য সফলভাবে সংরক্ষিত হয়েছে!</span>
          </div>
        )}
      </section>
    </div>
  );
};
