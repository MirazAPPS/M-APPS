import React, { useState, useMemo } from 'react';
import {
  ArrowLeft,
  Calendar,
  Share2,
  TrendingUp,
  TrendingDown,
  Users,
  Wallet,
  Store,
  User,
  Phone,
  MessageCircle,
  FileText,
  Download,
  Printer,
  ChevronRight,
  Search,
  CheckCircle2,
  AlertCircle,
  Clock,
  Sparkles,
  Percent,
  X,
  CreditCard,
  ArrowUpRight,
  ArrowDownLeft,
  Cloud,
  FileSpreadsheet,
  ExternalLink,
} from 'lucide-react';
import { CustomerAccount, ShopTransaction, UserProfile } from '../types';

export interface CombinedSummaryViewProps {
  user?: UserProfile;
  shopTransactions: ShopTransaction[];
  customers: CustomerAccount[];
  onBack: () => void;
  onOpenShopLedger?: () => void;
  onOpenCustomerLedger?: () => void;
  onOpenPersonalLedger?: () => void;
  onSelectCustomer?: (customerId: string) => void;
  initialCategory?: 'shop' | 'customer' | 'personal';
}

// Convert English digits to Bengali digits
const toBengaliDigits = (num: number | string): string => {
  return String(num).replace(/\d/g, (d) => '০১২৩৪৫৬৭৮৯'[parseInt(d, 10)]);
};

// Convert Bengali digits to English string
const normalizeDigits = (val: unknown): string => {
  if (val == null) return '';
  const str = String(val).trim();
  const bn = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return str.replace(/[০-৯]/g, (d) => String(bn.indexOf(d)));
};

// Format currency
const formatTaka = (amount: number): string => {
  return toBengaliDigits(Math.round(amount).toLocaleString('en-IN'));
};

// Get today's date formatted
const getTodayDateFormatted = (): string => {
  const now = new Date();
  const d = String(now.getDate()).padStart(2, '0');
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const y = now.getFullYear();
  return `${d}-${m}-${y}`;
};

export const CombinedSummaryView: React.FC<CombinedSummaryViewProps> = ({
  user,
  shopTransactions = [],
  customers = [],
  onBack,
  onOpenShopLedger,
  onOpenCustomerLedger,
  onOpenPersonalLedger,
  onSelectCustomer,
}) => {
  // Time scope filter: 'today' | '7days' | '30days' | 'all'
  const [timeFilter, setTimeFilter] = useState<'today' | '7days' | '30days' | 'all'>('all');
  const [searchDueQuery, setSearchDueQuery] = useState('');
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isDownloadingPdf, setIsDownloadingPdf] = useState(false);
  const [cloudPromptType, setCloudPromptType] = useState<'drive' | 'sheet' | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((c) => (c === msg ? null : c));
    }, 3000);
  };

  // Helper to test if a date string/timestamp is within the selected time filter
  const isItemInTimeFilter = (dateStr?: string, timestamp?: number): boolean => {
    if (timeFilter === 'all') return true;

    const now = Date.now();
    let itemMs = timestamp || 0;

    if (!itemMs && dateStr) {
      const norm = normalizeDigits(dateStr);
      const parts = norm.split(/[-/]/);
      if (parts.length === 3) {
        let d = parseInt(parts[0], 10);
        let m = parseInt(parts[1], 10) - 1;
        let y = parseInt(parts[2], 10);
        if (d > 1000) {
          y = parseInt(parts[0], 10);
          m = parseInt(parts[1], 10) - 1;
          d = parseInt(parts[2], 10);
        } else if (y < 100) {
          y += 2000;
        }
        const dt = new Date(y, m, d, 23, 59, 59);
        itemMs = dt.getTime();
      }
    }

    if (timeFilter === 'today') {
      const today = getTodayDateFormatted();
      if (dateStr === today || dateStr === 'আজ') return true;
      if (itemMs) {
        const itemDate = new Date(itemMs);
        const curDate = new Date();
        return (
          itemDate.getDate() === curDate.getDate() &&
          itemDate.getMonth() === curDate.getMonth() &&
          itemDate.getFullYear() === curDate.getFullYear()
        );
      }
      return false;
    }

    if (!itemMs || isNaN(itemMs)) return true;
    const diff = now - itemMs;
    const maxDiff =
      timeFilter === '7days' ? 7 * 86400000 : 30 * 86400000;
    return diff >= -86400000 && diff <= maxDiff;
  };

  // =========================================================================
  // 1. SHOP ACCOUNT CALCULATIONS
  // =========================================================================
  const shopData = useMemo(() => {
    return shopTransactions.filter((t) => t.category !== 'ব্যক্তিগত');
  }, [shopTransactions]);

  const filteredShopData = useMemo(() => {
    return shopData.filter((t) => isItemInTimeFilter(t.date, t.createdAtMs));
  }, [shopData, timeFilter]);

  const shopSummary = useMemo(() => {
    let buy = 0; // Total purchases / Cost (দোকানের খরচ / মাল ক্রয়)
    let sell = 0; // Total sales / Income (দোকানের বিক্রি / আয়)
    let deposit = 0; // Cash collected at time of sale
    let due = 0; // Credit sales / Due
    let profit = 0;

    filteredShopData.forEach((t) => {
      const b = Number(t.buyPrice) || 0;
      const s = Number(t.sellPrice) || 0;
      const d = Number(t.depositAmount) || 0;
      const du =
        Number(t.dueAmount) !== undefined && !isNaN(Number(t.dueAmount))
          ? Number(t.dueAmount)
          : Math.max(0, s - d);
      const pr = Number(t.profit) || Math.max(0, s - b);

      buy += b;
      sell += s;
      deposit += d;
      due += du;
      profit += pr;
    });

    return { buy, sell, deposit, due, profit, count: filteredShopData.length };
  }, [filteredShopData]);

  // =========================================================================
  // 2. PERSONAL ACCOUNT CALCULATIONS
  // =========================================================================
  const personalData = useMemo(() => {
    return shopTransactions.filter((t) => t.category === 'ব্যক্তিগত');
  }, [shopTransactions]);

  const filteredPersonalData = useMemo(() => {
    return personalData.filter((t) => isItemInTimeFilter(t.date, t.createdAtMs));
  }, [personalData, timeFilter]);

  const personalSummary = useMemo(() => {
    let expense = 0; // Personal Expense (ব্যক্তিগত খরচ/ব্যয়)
    let deposit = 0; // Personal Income / Cash In (ব্যক্তিগত নগদ জমা/আয়)
    let due = 0; // Personal Dues (ব্যক্তিগত বাকি/দেনা)

    filteredPersonalData.forEach((t) => {
      const exp = Number(t.buyPrice) || 0;
      const dep = Number(t.depositAmount) || 0;
      const du =
        Number(t.dueAmount) !== undefined && !isNaN(Number(t.dueAmount))
          ? Number(t.dueAmount)
          : Math.max(0, exp - dep);

      expense += exp;
      deposit += dep;
      due += du;
    });

    const netRemaining = Math.max(0, deposit - expense);
    return {
      expense,
      deposit,
      due,
      netRemaining,
      count: filteredPersonalData.length,
    };
  }, [filteredPersonalData]);

  // =========================================================================
  // 3. CUSTOMER ACCOUNT & OUTSTANDING DUES ("কার কাছে কত টাকা পাবো")
  // =========================================================================
  const customerSummary = useMemo(() => {
    let totalCustomers = customers.length;
    let totalSell = 0; // মোট বাকি বা বিক্রয় বাবদ পাওনা
    let totalDeposit = 0; // মোট নগদ জমা গ্রহণ
    let totalDue = 0; // আমি মোট কত টাকা কাস্টমারদের কাছে পাবো
    let customersWithDueCount = 0;

    const duesList: Array<{
      customerId: string;
      customerName: string;
      customerPhone: string;
      totalSell: number;
      totalDeposit: number;
      dueAmount: number;
      lastDate: string;
      transactionCount: number;
    }> = [];

    customers.forEach((cust) => {
      const allTx = cust.transactions || [];
      const filteredTx =
        timeFilter === 'all'
          ? allTx
          : allTx.filter((t) => isItemInTimeFilter(t.date, t.createdAtMs));

      let cSell = 0;
      let cDeposit = 0;
      let lastDate = '';

      filteredTx.forEach((tx) => {
        cSell += Number(tx.sellPrice) || 0;
        cDeposit += Number(tx.depositAmount) || 0;
        if (tx.date) lastDate = tx.date;
      });

      const custDue = Math.max(0, cSell - cDeposit);
      totalSell += cSell;
      totalDeposit += cDeposit;
      totalDue += custDue;

      if (custDue > 0) {
        customersWithDueCount++;
      }

      duesList.push({
        customerId: cust.id,
        customerName: cust.name || 'নামবিহীন কাস্টমার',
        customerPhone: cust.phone || '01XXXXXXXXX',
        totalSell: cSell,
        totalDeposit: cDeposit,
        dueAmount: custDue,
        lastDate: lastDate || getTodayDateFormatted(),
        transactionCount: filteredTx.length,
      });
    });

    // Sort by due amount descending (highest due first)
    duesList.sort((a, b) => b.dueAmount - a.dueAmount);

    return {
      totalCustomers,
      totalSell,
      totalDeposit,
      totalDue,
      customersWithDueCount,
      duesList,
    };
  }, [customers, timeFilter]);

  // Filter dues list by search query
  const filteredDuesList = useMemo(() => {
    if (!searchDueQuery.trim()) {
      return customerSummary.duesList.filter((c) => c.dueAmount > 0);
    }
    const q = searchDueQuery.toLowerCase();
    return customerSummary.duesList
      .filter((c) => c.dueAmount > 0)
      .filter(
        (c) =>
          c.customerName.toLowerCase().includes(q) ||
          c.customerPhone.includes(q)
      );
  }, [customerSummary.duesList, searchDueQuery]);

  // =========================================================================
  // 4. GRAND CONSOLIDATED FINANCIAL METRICS (তিন হিসাবের সমন্বিত সর্বমোট)
  // =========================================================================
  // কত টাকা আয় হয়েছে (Total Income / Cash In)
  // = দোকানের মোট বিক্রি + ব্যক্তিগত মোট জমা/উপার্জন + কাস্টমারদের থেকে নগদ জমা গ্রহণ
  const totalIncome = useMemo(() => {
    return shopSummary.sell + personalSummary.deposit;
  }, [shopSummary.sell, personalSummary.deposit]);

  // কত টাকা ব্যয় হয়েছে (Total Expense / Cash Out)
  // = দোকানের মোট মালামাল ক্রয় ও খরচ + ব্যক্তিগত খরচ
  const totalExpense = useMemo(() => {
    return shopSummary.buy + personalSummary.expense;
  }, [shopSummary.buy, personalSummary.expense]);

  // আমি কত টাকা কাস্টমারের কাছে পাবো (Total Customer Due / Receivables)
  const totalCustomerReceivable = customerSummary.totalDue;

  // নিট লাভ / নগদ স্থিতি
  const netBalance = totalIncome - totalExpense;

  // Profit Margin percentage
  const profitMargin =
    totalIncome > 0 ? Math.round((netBalance / totalIncome) * 100) : 0;

  // =========================================================================
  // PDF EXPORT & SHARING
  // =========================================================================
  const handleDownloadPdf = async () => {
    if (isDownloadingPdf) return;
    setIsDownloadingPdf(true);
    showToast('পূর্ণাঙ্গ PDF রিপোর্ট তৈরি হচ্ছে, অনুগ্রহ করে অপেক্ষা করুন...');

    let clone: HTMLElement | null = null;
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const html2pdfModule: any = await import('html2pdf.js');
      const html2pdf = html2pdfModule.default || html2pdfModule;

      const printRoot = document.getElementById('combined-summary-pdf-root');
      if (!printRoot) throw new Error('PDF container not found');

      clone = printRoot.cloneNode(true) as HTMLElement;
      clone.classList.remove('hidden');
      clone.classList.add('block');
      clone.style.position = 'fixed';
      clone.style.left = '0px';
      clone.style.top = '0px';
      clone.style.width = '794px';
      clone.style.maxWidth = '794px';
      clone.style.background = '#ffffff';
      clone.style.color = '#0f172a';
      clone.style.zIndex = '-9999';
      clone.style.opacity = '1';
      clone.style.pointerEvents = 'none';
      document.body.appendChild(clone);

      // Clean CSS colors for html2canvas compatibility
      const allEls = [clone, ...Array.from(clone.querySelectorAll('*'))] as HTMLElement[];
      allEls.forEach((el) => {
        try {
          const comp = window.getComputedStyle(el);
          ['color', 'backgroundColor', 'borderColor'].forEach((prop) => {
            const val = comp[prop as any];
            if (val && (val.includes('oklch') || val.includes('lab'))) {
              if (prop === 'color') el.style.color = '#0f172a';
              else if (prop === 'backgroundColor') el.style.backgroundColor = '#ffffff';
              else if (prop === 'borderColor') el.style.borderColor = '#cbd5e1';
            }
          });
        } catch {}
      });

      const fileName = `তিন_হিসাবের_সার্বিক_রিপোর্ট_${timeFilter}.pdf`;
      const opt = {
        margin: [10, 8, 10, 8] as [number, number, number, number],
        filename: fileName,
        image: { type: 'jpeg' as const, quality: 0.98 },
        html2canvas: {
          scale: 2,
          useCORS: true,
          logging: false,
          backgroundColor: '#ffffff',
          windowWidth: 794,
        },
        jsPDF: { unit: 'mm' as const, format: 'a4' as const, orientation: 'portrait' as const },
      };

      await html2pdf().set(opt).from(clone).save();
      showToast('✓ PDF ফাইল সফলভাবে ডাউনলোড হয়েছে!');
    } catch (err) {
      console.error('PDF error:', err);
      try {
        const printRoot = document.getElementById('combined-summary-pdf-root');
        if (printRoot) {
          const content = printRoot.innerHTML;
          const htmlDoc = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>তিন হিসাবের সার্বিক বিবরণী</title><style>body{font-family:sans-serif;padding:24px;color:#0f172a;background:#fff;}table{width:100%;border-collapse:collapse;margin-top:16px;}th,td{border:1px solid #cbd5e1;padding:6px 8px;font-size:12px;}th{background:#0d2847;color:#fff;}</style></head><body>${content}</body></html>`;
          const blob = new Blob([htmlDoc], { type: 'text/html;charset=utf-8;' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `তিন_হিসাবের_সার্বিক_রিপোর্ট_${timeFilter}.html`;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
          showToast('✓ হিসাব রিপোর্ট ডাউনলোড সম্পন্ন হয়েছে!');
        }
      } catch {
        showToast('রিপোর্ট ডাউনলোড করতে সমস্যা হয়েছে');
      }
    } finally {
      if (clone && clone.parentNode) {
        clone.parentNode.removeChild(clone);
      }
      setIsDownloadingPdf(false);
    }
  };

  const handleSaveToGoogleDrive = async () => {
    if (isDownloadingPdf) return;
    setIsDownloadingPdf(true);
    showToast('গুগল ড্রাইভের জন্য PDF প্রস্তুত হচ্ছে...');

    let clone: HTMLElement | null = null;
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const html2pdfModule: any = await import('html2pdf.js');
      const html2pdf = html2pdfModule.default || html2pdfModule;

      const printRoot = document.getElementById('combined-summary-pdf-root');
      if (!printRoot) throw new Error('PDF container not found');

      clone = printRoot.cloneNode(true) as HTMLElement;
      clone.classList.remove('hidden');
      clone.classList.add('block');
      clone.style.position = 'fixed';
      clone.style.left = '0px';
      clone.style.top = '0px';
      clone.style.width = '794px';
      clone.style.maxWidth = '794px';
      clone.style.background = '#ffffff';
      clone.style.color = '#0f172a';
      clone.style.zIndex = '-9999';
      clone.style.opacity = '1';
      clone.style.pointerEvents = 'none';
      document.body.appendChild(clone);

      const fileName = `তিন_হিসাবের_সার্বিক_রিপোর্ট_গুগল_ড্রাইভ_${timeFilter}.pdf`;
      const opt = {
        margin: [10, 8, 10, 8] as [number, number, number, number],
        filename: fileName,
        image: { type: 'jpeg' as const, quality: 0.98 },
        html2canvas: {
          scale: 2,
          useCORS: true,
          logging: false,
          backgroundColor: '#ffffff',
          windowWidth: 794,
        },
        jsPDF: { unit: 'mm' as const, format: 'a4' as const, orientation: 'portrait' as const },
      };

      await html2pdf().set(opt).from(clone).save();
      setCloudPromptType('drive');
      showToast('✓ PDF ফাইল ডাউনলোড হয়েছে! গুগল ড্রাইভে সংরক্ষণ করতে নিচের লিংকে ক্লিক করুন।');
    } catch (err: any) {
      console.error('Google Drive export error:', err);
      showToast('গুগল ড্রাইভের ফাইল তৈরিতে সমস্যা হয়েছে');
    } finally {
      if (clone && clone.parentNode) {
        clone.parentNode.removeChild(clone);
      }
      setIsDownloadingPdf(false);
    }
  };

  const handleSaveToGoogleSheet = () => {
    try {
      showToast('গুগল শীট ফাইল তৈরি হচ্ছে...');
      const rows: string[][] = [];

      rows.push([user?.name || 'টালি খাতা']);
      rows.push(['তিন হিসাবের সার্বিক বিবরণী ও সারসংক্ষেপ রিপোর্ট']);
      rows.push([`সময়কাল: ${getTimeFilterLabel()}`, `তারিখ: ${getTodayDateFormatted()}`]);
      rows.push([]);

      // Summary
      rows.push(['মোট আয় (৳)', 'মোট ব্যয় (৳)', 'কাস্টমারদের কাছে মোট পাওনা (৳)', 'নিট স্থিতি (৳)']);
      rows.push([
        String(totalIncome),
        String(totalExpense),
        String(totalCustomerReceivable),
        String(netBalance),
      ]);
      rows.push([]);

      // Section summaries
      rows.push(['হিসাবের খাত', 'আয় / জমা (৳)', 'ব্যয় / ক্রয় (৳)', 'বাকি / পাওনা (৳)', 'স্থিতি / লাভ (৳)']);
      rows.push(['দোকানের হিসাব', String(shopSummary.sell), String(shopSummary.buy), String(shopSummary.due), String(shopSummary.profit)]);
      rows.push(['ব্যক্তিগত হিসাব', String(personalSummary.deposit), String(personalSummary.expense), String(personalSummary.due), String(personalSummary.netRemaining)]);
      rows.push(['কাস্টমার খাতা (গ্রাহকদের কাছে পাওনা)', String(customerSummary.totalDeposit), String(customerSummary.totalSell), String(totalCustomerReceivable), '—']);
      rows.push([]);

      // Customer Outstanding List
      rows.push(['কাস্টমারদের কাছে বাকি পাওনার তালিকা']);
      rows.push(['ক্রম', 'কাস্টমার নাম', 'মোবাইল নম্বর', 'বাকি পাওনা (৳)', 'সর্বশেষ লেনদেন তারিখ']);
      customerSummary.duesList.forEach((c, idx) => {
        rows.push([String(idx + 1), c.customerName, c.customerPhone, String(c.dueAmount), c.lastDate || '—']);
      });

      const csvContent = rows
        .map((row) =>
          row
            .map((cell) => {
              const str = (cell ?? '').toString().replace(/"/g, '""');
              return str.includes(',') || str.includes('\n') || str.includes('"') ? `"${str}"` : str;
            })
            .join(',')
        )
        .join('\r\n');

      const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
      const fileName = `তিন_হিসাবের_সার্বিক_রিপোর্ট_গুগল_শীট_${timeFilter}.csv`;

      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', fileName);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setCloudPromptType('sheet');
      showToast('✓ গুগল শীট ফাইল ডাউনলোড হয়েছে! গুগল শীটে খুলতে নিচের লিংকে ক্লিক করুন।');
    } catch (err) {
      console.error('Google Sheets error:', err);
      showToast('গুগল শীট তৈরিতে সমস্যা হয়েছে');
    }
  };

  const handleWhatsAppShare = () => {
    const timeLabel =
      timeFilter === 'today'
        ? 'আজকের'
        : timeFilter === '7days'
        ? 'বিগত ৭ দিনের'
        : timeFilter === '30days'
        ? 'বিগত ৩০ দিনের'
        : 'সর্বমোট';

    const text =
      `📊 *তিন হিসাবের সার্বিক বিবরণী (${timeLabel})*\n` +
      `👤 প্রতিষ্ঠান/ব্যবহারকারী: ${user?.name || 'টালি খাতা'}\n\n` +
      `🟢 *মোট আয়:* ৳${formatTaka(totalIncome)}\n` +
      `   • দোকান বিক্রি: ৳${formatTaka(shopSummary.sell)}\n` +
      `   • ব্যক্তিগত প্রাপ্তি: ৳${formatTaka(personalSummary.deposit)}\n\n` +
      `🔴 *মোট ব্যয়:* ৳${formatTaka(totalExpense)}\n` +
      `   • দোকান খরচ/ক্রয়: ৳${formatTaka(shopSummary.buy)}\n` +
      `   • ব্যক্তিগত খরচ: ৳${formatTaka(personalSummary.expense)}\n\n` +
      `🟡 *কাস্টমারদের কাছে মোট পাওনা:* ৳${formatTaka(totalCustomerReceivable)}\n` +
      `   • বাকি গ্রাহক সংখ্যা: ${toBengaliDigits(customerSummary.customersWithDueCount)} জন\n\n` +
      `🔵 *হাতে স্থিতি / নিট লাভ:* ৳${formatTaka(netBalance)}\n\n` +
      `📱 টালি খাতা অ্যাপের মাধ্যমে তৈরিকৃত।`;

    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  const getTimeFilterLabel = () => {
    switch (timeFilter) {
      case 'today':
        return 'আজকের হিসাব';
      case '7days':
        return 'বিগত ৭ দিনের হিসাব';
      case '30days':
        return 'বিগত ৩০ দিনের হিসাব';
      case 'all':
      default:
        return 'সকল সময়ের সর্বমোট হিসাব';
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 pb-20 select-none animate-fadeIn">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-slate-950 text-white px-4 py-2.5 rounded-xl text-xs font-black shadow-2xl flex items-center gap-2 border border-slate-700 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. TOP APP BAR & HEADER (ছোট, পরিষ্কার ও সুন্দর)                           */}
      {/* ========================================================================= */}
      <header
        className="bg-[#0b1e36] text-white px-3 py-2.5 shadow-md sticky top-0 z-30"
        style={{
          paddingTop: 'max(10px, calc(env(safe-area-inset-top, 0px) + 8px))',
        }}
      >
        <div className="max-w-lg mx-auto flex items-center justify-between gap-2">
          {/* Back Button */}
          <button
            type="button"
            id="combined-summary-back-btn"
            onClick={onBack}
            className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer shrink-0"
            title="টালি খাতায় ফিরুন"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>

          {/* Title and Subtitle */}
          <div className="flex-1 text-center min-w-0">
            <h1 className="text-sm font-black text-white tracking-tight flex items-center justify-center gap-1.5 truncate">
              <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>তিন হিসাবের সার্বিক বিবরণী</span>
            </h1>
            <p className="text-[10px] text-slate-300 font-medium truncate">
              দোকান, ব্যক্তিগত ও কাস্টমার হিসাব পর্যালোচনা
            </p>
          </div>

          {/* Share/PDF Button */}
          <button
            type="button"
            id="combined-summary-share-btn"
            onClick={() => setIsShareModalOpen(true)}
            className="h-8 px-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs flex items-center gap-1 shadow-xs transition-transform active:scale-95 cursor-pointer shrink-0"
            title="PDF ডাউনলোড ও শেয়ার করুন"
          >
            <Share2 className="w-3.5 h-3.5 stroke-[2.5]" />
            <span className="hidden sm:inline">রিপোর্ট</span>
          </button>
        </div>
      </header>

      {/* ========================================================================= */}
      {/* 2. TIME FILTER TABS (আজ | ৭ দিন | ৩০ দিন | সব সময়)                         */}
      {/* ========================================================================= */}
      <div className="max-w-lg mx-auto px-3 pt-2.5">
        <div className="bg-white p-1 rounded-xl shadow-2xs border border-slate-200/80 flex items-center justify-between gap-1">
          <button
            type="button"
            id="time-filter-today"
            onClick={() => setTimeFilter('today')}
            className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-black transition-all cursor-pointer text-center ${
              timeFilter === 'today'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            আজ
          </button>
          <button
            type="button"
            id="time-filter-7days"
            onClick={() => setTimeFilter('7days')}
            className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-black transition-all cursor-pointer text-center ${
              timeFilter === '7days'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            ৭ দিন
          </button>
          <button
            type="button"
            id="time-filter-30days"
            onClick={() => setTimeFilter('30days')}
            className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-black transition-all cursor-pointer text-center ${
              timeFilter === '30days'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            ৩০ দিন
          </button>
          <button
            type="button"
            id="time-filter-all"
            onClick={() => setTimeFilter('all')}
            className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-black transition-all cursor-pointer text-center ${
              timeFilter === 'all'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            সব সময়
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <main className="max-w-lg mx-auto px-3 py-2.5 space-y-3">
        {/* ========================================================================= */}
        {/* 3. HERO SPOTLIGHT CARDS (ব্যবহারকারীর ৩টি মূল প্রশ্নের বড় ও স্পষ্ট উত্তর)  */}
        {/* ========================================================================= */}
        <div className="space-y-2">
          {/* Card 1: কত টাকা আয় হয়েছে (Total Income) */}
          <div className="bg-gradient-to-br from-emerald-600 via-emerald-700 to-teal-800 text-white rounded-2xl p-3.5 shadow-md border border-emerald-500/40 relative overflow-hidden">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-bold text-emerald-100 uppercase tracking-wider block">
                  ১. মোট আয় হয়েছে (ইনকাম)
                </span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-2xl sm:text-3xl font-black font-mono tracking-tight">
                    ৳ {formatTaka(totalIncome)}
                  </span>
                </div>
              </div>
              <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white shrink-0 backdrop-blur-xs">
                <TrendingUp className="w-5 h-5 stroke-[2.5]" />
              </div>
            </div>

            {/* Income Breakdown Chips */}
            <div className="mt-2.5 pt-2 border-t border-white/20 flex flex-wrap items-center gap-1.5 text-[11px]">
              <span className="bg-black/20 px-2 py-0.5 rounded-md font-medium text-emerald-50">
                🏪 দোকান বিক্রি: ৳{formatTaka(shopSummary.sell)}
              </span>
              <span className="bg-black/20 px-2 py-0.5 rounded-md font-medium text-emerald-50">
                👤 ব্যক্তিগত প্রাপ্তি: ৳{formatTaka(personalSummary.deposit)}
              </span>
              <span className="bg-black/20 px-2 py-0.5 rounded-md font-medium text-emerald-50">
                👥 কাস্টমার জমা: ৳{formatTaka(customerSummary.totalDeposit)}
              </span>
            </div>
          </div>

          {/* Card 2: কত টাকা ব্যয় হয়েছে (Total Expense) */}
          <div className="bg-gradient-to-br from-rose-600 via-rose-700 to-red-800 text-white rounded-2xl p-3.5 shadow-md border border-rose-500/40 relative overflow-hidden">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-bold text-rose-100 uppercase tracking-wider block">
                  ২. মোট ব্যয় হয়েছে (খরচ)
                </span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-2xl sm:text-3xl font-black font-mono tracking-tight">
                    ৳ {formatTaka(totalExpense)}
                  </span>
                </div>
              </div>
              <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white shrink-0 backdrop-blur-xs">
                <TrendingDown className="w-5 h-5 stroke-[2.5]" />
              </div>
            </div>

            {/* Expense Breakdown Chips */}
            <div className="mt-2.5 pt-2 border-t border-white/20 flex flex-wrap items-center gap-1.5 text-[11px]">
              <span className="bg-black/20 px-2 py-0.5 rounded-md font-medium text-rose-50">
                🏪 দোকান মালামাল ক্রয়/খরচ: ৳{formatTaka(shopSummary.buy)}
              </span>
              <span className="bg-black/20 px-2 py-0.5 rounded-md font-medium text-rose-50">
                👤 ব্যক্তিগত সংসার/ব্যয়: ৳{formatTaka(personalSummary.expense)}
              </span>
            </div>
          </div>

          {/* Card 3: আমি কত টাকা কাস্টমারের কাছে পাবো (Total Customer Receivables) */}
          <div className="bg-gradient-to-br from-amber-500 via-amber-600 to-orange-700 text-white rounded-2xl p-3.5 shadow-md border border-amber-400/40 relative overflow-hidden">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-bold text-amber-100 uppercase tracking-wider block">
                    ৩. আমি কাস্টমারের কাছে পাবো (মোট বাকি)
                  </span>
                  <span className="bg-white/20 text-white text-[10px] font-black px-1.5 py-0.5 rounded-full">
                    {toBengaliDigits(customerSummary.customersWithDueCount)} জন বাকি
                  </span>
                </div>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-2xl sm:text-3xl font-black font-mono tracking-tight">
                    ৳ {formatTaka(totalCustomerReceivable)}
                  </span>
                </div>
              </div>
              <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white shrink-0 backdrop-blur-xs">
                <Users className="w-5 h-5 stroke-[2.5]" />
              </div>
            </div>

            {/* Sub-action link */}
            <div className="mt-2.5 pt-2 border-t border-white/20 flex items-center justify-between text-[11px]">
              <span className="text-amber-100">
                কাস্টমারদের কাছে বকেয়া পাওনা টাকা
              </span>
              <a
                href="#customer-dues-section"
                className="font-black underline flex items-center gap-1 hover:text-white"
              >
                <span>বাকিদের তালিকা দেখুন</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Card 4: নিট স্থিতি / লাভ ও ক্যাশ ব্যালেন্স */}
          <div className="bg-white rounded-2xl p-3 shadow-2xs border border-slate-200/90 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  netBalance >= 0
                    ? 'bg-blue-100 text-blue-700'
                    : 'bg-rose-100 text-rose-700'
                }`}
              >
                <Wallet className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                  নিট লাভ / নগদ স্থিতি (আয় - ব্যয়)
                </span>
                <span
                  className={`text-lg font-black font-mono ${
                    netBalance >= 0 ? 'text-blue-700' : 'text-rose-600'
                  }`}
                >
                  ৳ {formatTaka(netBalance)}
                </span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-bold text-slate-400 block">
                লাভের অনুপাত
              </span>
              <span
                className={`text-xs font-black px-2 py-0.5 rounded-full ${
                  profitMargin >= 0
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-rose-100 text-rose-800'
                }`}
              >
                {toBengaliDigits(profitMargin)}%
              </span>
            </div>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* 4. THREE DISTINCT ACCOUNTS BREAKDOWN (৩টি হিসাবের বিশদ সারসংক্ষেপ)        */}
        {/* ========================================================================= */}
        <section className="space-y-2.5">
          <div className="flex items-center justify-between px-0.5">
            <h2 className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <span>তিন হিসাবের বিস্তারিত পর্যালোচনা</span>
            </h2>
            <span className="text-[10px] font-bold text-slate-500">
              {getTimeFilterLabel()}
            </span>
          </div>

          {/* A. 🏪 দোকানের হিসাব (Shop Account) */}
          <div className="bg-white rounded-2xl p-3 shadow-2xs border border-slate-200/90 space-y-2.5">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
                  <Store className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-black text-slate-900">
                    দোকানের হিসাব
                  </h3>
                  <span className="text-[10px] text-slate-500 font-medium">
                    মোট {toBengaliDigits(shopSummary.count)} টি লেনদেন
                  </span>
                </div>
              </div>
              {onOpenShopLedger && (
                <button
                  type="button"
                  onClick={onOpenShopLedger}
                  className="text-[11px] font-black text-emerald-700 hover:text-emerald-800 flex items-center gap-0.5 cursor-pointer bg-emerald-50 px-2 py-1 rounded-lg border border-emerald-200"
                >
                  <span>খাতা দেখুন</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
              <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                <span className="text-[10px] text-slate-500 block">মোট বিক্রি</span>
                <span className="text-xs font-black text-emerald-600 font-mono">
                  ৳{formatTaka(shopSummary.sell)}
                </span>
              </div>
              <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                <span className="text-[10px] text-slate-500 block">মোট ক্রয়</span>
                <span className="text-xs font-black text-rose-600 font-mono">
                  ৳{formatTaka(shopSummary.buy)}
                </span>
              </div>
              <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                <span className="text-[10px] text-slate-500 block">কাস্টমার বাকি</span>
                <span className="text-xs font-black text-amber-600 font-mono">
                  ৳{formatTaka(shopSummary.due)}
                </span>
              </div>
              <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                <span className="text-[10px] text-slate-500 block">দোকান লাভ</span>
                <span className="text-xs font-black text-blue-600 font-mono">
                  ৳{formatTaka(shopSummary.profit)}
                </span>
              </div>
            </div>
          </div>

          {/* B. 👤 ব্যক্তিগত হিসাব (Personal Account) */}
          <div className="bg-white rounded-2xl p-3 shadow-2xs border border-slate-200/90 space-y-2.5">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-purple-100 text-purple-800 flex items-center justify-center shrink-0">
                  <User className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-black text-slate-900">
                    ব্যক্তিগত হিসাব
                  </h3>
                  <span className="text-[10px] text-slate-500 font-medium">
                    মোট {toBengaliDigits(personalSummary.count)} টি এন্ট্রি
                  </span>
                </div>
              </div>
              {onOpenPersonalLedger && (
                <button
                  type="button"
                  onClick={onOpenPersonalLedger}
                  className="text-[11px] font-black text-purple-700 hover:text-purple-800 flex items-center gap-0.5 cursor-pointer bg-purple-50 px-2 py-1 rounded-lg border border-purple-200"
                >
                  <span>খাতা দেখুন</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
              <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                <span className="text-[10px] text-slate-500 block">ব্যক্তিগত জমা</span>
                <span className="text-xs font-black text-emerald-600 font-mono">
                  ৳{formatTaka(personalSummary.deposit)}
                </span>
              </div>
              <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                <span className="text-[10px] text-slate-500 block">ব্যক্তিগত খরচ</span>
                <span className="text-xs font-black text-rose-600 font-mono">
                  ৳{formatTaka(personalSummary.expense)}
                </span>
              </div>
              <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                <span className="text-[10px] text-slate-500 block">ব্যক্তিগত দেনা</span>
                <span className="text-xs font-black text-amber-600 font-mono">
                  ৳{formatTaka(personalSummary.due)}
                </span>
              </div>
              <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                <span className="text-[10px] text-slate-500 block">হাতে অবশিষ্ট</span>
                <span className="text-xs font-black text-purple-600 font-mono">
                  ৳{formatTaka(personalSummary.netRemaining)}
                </span>
              </div>
            </div>
          </div>

          {/* C. 👥 কাস্টমার হিসাব (Customer Account) */}
          <div className="bg-white rounded-2xl p-3 shadow-2xs border border-slate-200/90 space-y-2.5">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-800 flex items-center justify-center shrink-0">
                  <Users className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-black text-slate-900">
                    কাস্টমার হিসাব
                  </h3>
                  <span className="text-[10px] text-slate-500 font-medium">
                    মোট {toBengaliDigits(customerSummary.totalCustomers)} জন কাস্টমার
                  </span>
                </div>
              </div>
              {onOpenCustomerLedger && (
                <button
                  type="button"
                  onClick={onOpenCustomerLedger}
                  className="text-[11px] font-black text-blue-700 hover:text-blue-800 flex items-center gap-0.5 cursor-pointer bg-blue-50 px-2 py-1 rounded-lg border border-blue-200"
                >
                  <span>খাতা দেখুন</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
              <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                <span className="text-[10px] text-slate-500 block">মোট কাস্টমার</span>
                <span className="text-xs font-black text-blue-600 font-mono">
                  {toBengaliDigits(customerSummary.totalCustomers)} জন
                </span>
              </div>
              <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                <span className="text-[10px] text-slate-500 block">মোট জমা আদায়</span>
                <span className="text-xs font-black text-emerald-600 font-mono">
                  ৳{formatTaka(customerSummary.totalDeposit)}
                </span>
              </div>
              <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                <span className="text-[10px] text-slate-500 block">মোট পাওনা বাকি</span>
                <span className="text-xs font-black text-amber-600 font-mono">
                  ৳{formatTaka(customerSummary.totalDue)}
                </span>
              </div>
              <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                <span className="text-[10px] text-slate-500 block">বাকিদার কাস্টমার</span>
                <span className="text-xs font-black text-rose-600 font-mono">
                  {toBengaliDigits(customerSummary.customersWithDueCount)} জন
                </span>
              </div>
            </div>
          </div>
        </section>

        {/* ========================================================================= */}
        {/* 5. "আমি কার কাছে কত টাকা পাবো" - কাস্টমারদের তালিকা                      */}
        {/* ========================================================================= */}
        <section id="customer-dues-section" className="space-y-2.5 pt-2">
          <div className="bg-white rounded-2xl p-3 shadow-2xs border border-amber-200 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>আমি কার কাছে কত টাকা পাবো (বাকি তালিকা)</span>
                </h3>
                <p className="text-[10px] text-slate-500 mt-0.5">
                  মোট {toBengaliDigits(customerSummary.customersWithDueCount)} জনের কাছে ৳{formatTaka(totalCustomerReceivable)} পাওনা রয়েছে
                </p>
              </div>
              <span className="bg-amber-100 text-amber-900 text-[10px] font-black px-2 py-0.5 rounded-full">
                পাওনা বাকি
              </span>
            </div>

            {/* Search Box */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchDueQuery}
                onChange={(e) => setSearchDueQuery(e.target.value)}
                placeholder="কাস্টমারের নাম বা মোবাইল দিয়ে খুঁজুন..."
                className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-blue-500"
              />
              {searchDueQuery && (
                <button
                  type="button"
                  onClick={() => setSearchDueQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* List of Customers with Dues */}
            {filteredDuesList.length === 0 ? (
              <div className="text-center py-6 px-3 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-1.5" />
                <p className="text-xs font-black text-slate-700">
                  {searchDueQuery ? 'কোনো কাস্টমার পাওয়া যায়নি' : 'দারুণ! কারো কাছে কোনো বাকি নেই'}
                </p>
                <p className="text-[10px] text-slate-500 mt-0.5">
                  {searchDueQuery
                    ? 'সঠিক নাম বা নম্বর দিয়ে পুনরায় খুঁজুন'
                    : 'সকল কাস্টমারদের পাওনা শতভাগ পরিশোধিত রয়েছে'}
                </p>
              </div>
            ) : (
              <div className="space-y-1.5 max-h-80 overflow-y-auto pr-0.5">
                {filteredDuesList.map((cust) => {
                  return (
                    <div
                      key={cust.customerId}
                      className="bg-slate-50 hover:bg-slate-100 p-2.5 rounded-xl border border-slate-200/80 flex items-center justify-between gap-2 transition-colors"
                    >
                      {/* Left: Avatar & Name */}
                      <div className="flex items-center gap-2 min-w-0 flex-1">
                        <div className="w-8 h-8 rounded-full bg-blue-600 text-white font-black text-xs flex items-center justify-center shrink-0">
                          {cust.customerName.charAt(0) || 'ক'}
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-xs font-black text-slate-900 truncate">
                            {cust.customerName}
                          </h4>
                          <span className="text-[10px] text-slate-500 font-mono block">
                            {cust.customerPhone}
                          </span>
                        </div>
                      </div>

                      {/* Right: Due Amount & Actions */}
                      <div className="flex items-center gap-2 shrink-0">
                        <div className="text-right">
                          <span className="text-[10px] font-bold text-rose-500 block">
                            পাওনা বাকি
                          </span>
                          <span className="text-xs font-black text-rose-600 font-mono">
                            ৳ {formatTaka(cust.dueAmount)}
                          </span>
                        </div>

                        {/* Call action */}
                        {cust.customerPhone && cust.customerPhone !== '01XXXXXXXXX' && (
                          <a
                            href={`tel:${cust.customerPhone}`}
                            className="w-7 h-7 rounded-lg bg-emerald-100 hover:bg-emerald-200 text-emerald-800 flex items-center justify-center transition-colors"
                            title="সরাসরি কল দিন"
                          >
                            <Phone className="w-3.5 h-3.5" />
                          </a>
                        )}

                        {/* WhatsApp / SMS Reminder */}
                        {cust.customerPhone && cust.customerPhone !== '01XXXXXXXXX' && (
                          <a
                            href={`https://wa.me/88${cust.customerPhone.replace(/\D/g, '')}?text=${encodeURIComponent(
                              `সম্মানিত ${cust.customerName}, আপনার কাছে আমাদের দোকানের মোট বকেয়া বাকি রয়েছে ৳${formatTaka(
                                cust.dueAmount
                              )}। দ্রুত পরিশোধের বিনীত অনুরোধ জানাচ্ছি। ধন্যবাদ।`
                            )}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="w-7 h-7 rounded-lg bg-green-100 hover:bg-green-200 text-green-800 flex items-center justify-center transition-colors"
                            title="হোয়াটসঅ্যাপে তাগাদা পাঠান"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                          </a>
                        )}

                        {/* View Customer Details */}
                        {onSelectCustomer && (
                          <button
                            type="button"
                            onClick={() => onSelectCustomer(cust.customerId)}
                            className="w-7 h-7 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
                            title="কাস্টমারের হিসাবের খাতা দেখুন"
                          >
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </section>
      </main>

      {/* ========================================================================= */}
      {/* 6. SHARE / PDF EXPORT MODAL                                               */}
      {/* ========================================================================= */}
      {isShareModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-3 animate-fadeIn">
          <div className="bg-white w-full max-w-sm rounded-2xl p-4 shadow-2xl space-y-4 animate-slideUp">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
                  <Share2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">
                    সার্বিক হিসাব রিপোর্ট শেয়ার
                  </h3>
                  <p className="text-[10px] text-slate-500">
                    {getTimeFilterLabel()}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsShareModalOpen(false)}
                className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Summary Preview */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/80 space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-600">মোট আয়:</span>
                <span className="font-black text-emerald-600 font-mono">
                  ৳ {formatTaka(totalIncome)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">মোট ব্যয়:</span>
                <span className="font-black text-rose-600 font-mono">
                  ৳ {formatTaka(totalExpense)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">কাস্টমার বাকি পাওনা:</span>
                <span className="font-black text-amber-600 font-mono">
                  ৳ {formatTaka(totalCustomerReceivable)}
                </span>
              </div>
              <div className="flex justify-between pt-1 border-t border-slate-200">
                <span className="font-bold text-slate-800">নিট স্থিতি:</span>
                <span className="font-black text-blue-700 font-mono">
                  ৳ {formatTaka(netBalance)}
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-2">
              <button
                type="button"
                onClick={handleDownloadPdf}
                disabled={isDownloadingPdf}
                className="w-full py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-98 text-white font-black text-xs flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer disabled:opacity-50"
              >
                <Download className="w-4 h-4" />
                <span>{isDownloadingPdf ? 'PDF তৈরি হচ্ছে...' : 'PDF ফাইল হিসেবে ডাউনলোড করুন'}</span>
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  disabled={isDownloadingPdf}
                  onClick={handleSaveToGoogleDrive}
                  className="py-2.5 px-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 transition-all active:scale-98 cursor-pointer disabled:opacity-50"
                  title="গুগল ড্রাইভে হিসাব সংরক্ষণ করুন"
                >
                  <Cloud className="w-4 h-4 text-amber-300" />
                  <span>গুগল ড্রাইভ</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveToGoogleSheet}
                  className="py-2.5 px-2 bg-gradient-to-r from-emerald-700 to-teal-700 hover:from-emerald-800 hover:to-teal-800 text-white font-black text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 transition-all active:scale-98 cursor-pointer"
                  title="গুগল শীটে হিসাব সংগ্রহ করুন"
                >
                  <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
                  <span>গুগল শীট</span>
                </button>
              </div>

              {/* Cloud Prompt Banner */}
              {cloudPromptType === 'drive' && (
                <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-xl text-xs space-y-1.5 animate-fadeIn">
                  <div className="flex items-center gap-1.5 text-blue-950 font-bold">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                    <span>গুগল ড্রাইভ ব্যাকআপ PDF ডাউনলোড হয়েছে!</span>
                  </div>
                  <p className="text-[11px] text-blue-700">
                    ফাইলটি ডাউনলোড ফোল্ডারে সেভ হয়েছে। গুগল ড্রাইভে আপলোড করতে নিচের লিংকে যান:
                  </p>
                  <a
                    href="https://drive.google.com/drive/u/0/my-drive"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-xs shadow-2xs"
                  >
                    <Cloud className="w-3.5 h-3.5 text-amber-300" />
                    <span>গুগল ড্রাইভ খুলুন</span>
                    <ExternalLink className="w-3 h-3 ml-0.5" />
                  </a>
                </div>
              )}

              {cloudPromptType === 'sheet' && (
                <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs space-y-1.5 animate-fadeIn">
                  <div className="flex items-center gap-1.5 text-emerald-950 font-bold">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>গুগল শীট স্প্রেডশীট (.csv) ফাইল ডাউনলোড হয়েছে!</span>
                  </div>
                  <p className="text-[11px] text-emerald-700">
                    ফাইলটি প্রস্তুত হয়েছে। গুগল শীট ওয়েব পেজে ওপেন করতে নিচের লিংকে যান:
                  </p>
                  <a
                    href="https://docs.google.com/spreadsheets/u/0/create"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-bold text-xs shadow-2xs"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-200" />
                    <span>গুগল শীট খুলুন</span>
                    <ExternalLink className="w-3 h-3 ml-0.5" />
                  </a>
                </div>
              )}

              <button
                type="button"
                onClick={handleWhatsAppShare}
                className="w-full py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-black text-xs flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
              >
                <MessageCircle className="w-4 h-4" />
                <span>হোয়াটসঅ্যাপে পূর্ণ বিবরণী পাঠান</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 7. HIDDEN PDF RENDER CONTAINER (FOR html2pdf)                              */}
      {/* ========================================================================= */}
      <div id="combined-summary-pdf-root" className="hidden p-6 bg-white text-slate-900 font-sans">
        <div className="text-center pb-4 border-b border-slate-300">
          <h1 className="text-xl font-bold text-slate-900">
            {user?.name || 'টালি খাতা'}
          </h1>
          <p className="text-xs text-slate-600 mt-0.5">
            তিন হিসাবের সার্বিক বিবরণী ও সারসংক্ষেপ রিপোর্ট
          </p>
          <p className="text-[10px] text-slate-500 mt-1">
            সময়কাল: {getTimeFilterLabel()} | তারিখ: {getTodayDateFormatted()}
          </p>
        </div>

        {/* 4 Big Totals in PDF */}
        <div className="grid grid-cols-4 gap-2 my-4 text-center">
          <div className="p-2.5 bg-emerald-50 rounded-lg border border-emerald-200">
            <span className="text-[10px] text-slate-600 block">মোট আয়</span>
            <span className="text-sm font-bold text-emerald-700">
              ৳ {formatTaka(totalIncome)}
            </span>
          </div>
          <div className="p-2.5 bg-rose-50 rounded-lg border border-rose-200">
            <span className="text-[10px] text-slate-600 block">মোট ব্যয়</span>
            <span className="text-sm font-bold text-rose-700">
              ৳ {formatTaka(totalExpense)}
            </span>
          </div>
          <div className="p-2.5 bg-amber-50 rounded-lg border border-amber-200">
            <span className="text-[10px] text-slate-600 block">কাস্টমার বাকি পাওনা</span>
            <span className="text-sm font-bold text-amber-700">
              ৳ {formatTaka(totalCustomerReceivable)}
            </span>
          </div>
          <div className="p-2.5 bg-blue-50 rounded-lg border border-blue-200">
            <span className="text-[10px] text-slate-600 block">নিট স্থিতি</span>
            <span className="text-sm font-bold text-blue-700">
              ৳ {formatTaka(netBalance)}
            </span>
          </div>
        </div>

        {/* Account Details Table */}
        <div className="my-4">
          <h3 className="text-xs font-bold text-slate-800 mb-2">
            ১. হিসাবভিত্তিক পর্যালোচনা
          </h3>
          <table className="w-full text-[11px] border border-slate-300">
            <thead>
              <tr className="bg-slate-100 text-slate-700">
                <th className="p-1.5 border border-slate-300 text-left">হিসাবের ধরণ</th>
                <th className="p-1.5 border border-slate-300 text-right">বিক্রি / জমা</th>
                <th className="p-1.5 border border-slate-300 text-right">ক্রয় / খরচ</th>
                <th className="p-1.5 border border-slate-300 text-right">বাকি</th>
                <th className="p-1.5 border border-slate-300 text-right">লাভ / স্থিতি</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="p-1.5 border border-slate-300 font-bold">দোকানের হিসাব</td>
                <td className="p-1.5 border border-slate-300 text-right">৳{formatTaka(shopSummary.sell)}</td>
                <td className="p-1.5 border border-slate-300 text-right">৳{formatTaka(shopSummary.buy)}</td>
                <td className="p-1.5 border border-slate-300 text-right">৳{formatTaka(shopSummary.due)}</td>
                <td className="p-1.5 border border-slate-300 text-right">৳{formatTaka(shopSummary.profit)}</td>
              </tr>
              <tr>
                <td className="p-1.5 border border-slate-300 font-bold">ব্যক্তিগত হিসাব</td>
                <td className="p-1.5 border border-slate-300 text-right">৳{formatTaka(personalSummary.deposit)}</td>
                <td className="p-1.5 border border-slate-300 text-right">৳{formatTaka(personalSummary.expense)}</td>
                <td className="p-1.5 border border-slate-300 text-right">৳{formatTaka(personalSummary.due)}</td>
                <td className="p-1.5 border border-slate-300 text-right">৳{formatTaka(personalSummary.netRemaining)}</td>
              </tr>
              <tr>
                <td className="p-1.5 border border-slate-300 font-bold">কাস্টমার হিসাব</td>
                <td className="p-1.5 border border-slate-300 text-right">৳{formatTaka(customerSummary.totalDeposit)}</td>
                <td className="p-1.5 border border-slate-300 text-right">-</td>
                <td className="p-1.5 border border-slate-300 text-right font-bold text-rose-700">৳{formatTaka(customerSummary.totalDue)}</td>
                <td className="p-1.5 border border-slate-300 text-right">-</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Customer Dues in PDF */}
        <div className="my-4">
          <h3 className="text-xs font-bold text-slate-800 mb-2">
            ২. কার কাছে কত টাকা পাওনা (কাস্টমার বাকি তালিকা)
          </h3>
          <table className="w-full text-[10px] border border-slate-300">
            <thead>
              <tr className="bg-slate-100 text-slate-700">
                <th className="p-1.5 border border-slate-300 text-left">ক্রমিক</th>
                <th className="p-1.5 border border-slate-300 text-left">কাস্টমারের নাম</th>
                <th className="p-1.5 border border-slate-300 text-left">মোবাইল</th>
                <th className="p-1.5 border border-slate-300 text-right">মোট বিক্রি</th>
                <th className="p-1.5 border border-slate-300 text-right">মোট জমা</th>
                <th className="p-1.5 border border-slate-300 text-right">পাওনা বাকি</th>
              </tr>
            </thead>
            <tbody>
              {filteredDuesList.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-2 text-center text-slate-500">
                    কোনো কাস্টমারের কাছে বাকি নেই
                  </td>
                </tr>
              ) : (
                filteredDuesList.map((cust, idx) => (
                  <tr key={cust.customerId}>
                    <td className="p-1.5 border border-slate-300 text-center">{toBengaliDigits(idx + 1)}</td>
                    <td className="p-1.5 border border-slate-300 font-bold">{cust.customerName}</td>
                    <td className="p-1.5 border border-slate-300">{cust.customerPhone}</td>
                    <td className="p-1.5 border border-slate-300 text-right">৳{formatTaka(cust.totalSell)}</td>
                    <td className="p-1.5 border border-slate-300 text-right">৳{formatTaka(cust.totalDeposit)}</td>
                    <td className="p-1.5 border border-slate-300 text-right font-bold text-rose-700">
                      ৳{formatTaka(cust.dueAmount)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="mt-8 pt-3 border-t border-slate-300 text-center text-[9px] text-slate-500">
          রিপোর্ট প্রস্তুতের সময়: {new Date().toLocaleString('bn-BD')} | টালি খাতা মোবাইল অ্যাপ
        </div>
      </div>
    </div>
  );
};
