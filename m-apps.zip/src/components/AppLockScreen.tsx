import React, { useState, useEffect, useRef } from 'react';
import { Lock, Fingerprint, Delete, Shield, AlertCircle, LogOut } from 'lucide-react';
import { UserProfile, AppSettings } from '../types';
import { isBiometricSupported, hasBiometricEnrolled, authenticateBiometrics } from '../utils/biometrics';
import { speakText, playNotificationTone } from '../utils';

interface AppLockScreenProps {
  user: UserProfile;
  settings: AppSettings;
  lockedTimestamp: number;
  lockReason?: string;
  onUnlock: () => void;
  onLogout: () => void;
}

export const AppLockScreen: React.FC<AppLockScreenProps> = ({
  user,
  settings,
  lockedTimestamp,
  lockReason,
  onUnlock,
  onLogout,
}) => {
  const [pinDigits, setPinDigits] = useState<string[]>(['', '', '', '']);
  const [errorMessage, setErrorMessage] = useState('');
  const [isShaking, setIsShaking] = useState(false);
  const [bioAvailable, setBioAvailable] = useState(false);
  const [isAuthenticatingBio, setIsAuthenticatingBio] = useState(false);

  // Active Logo with reactive synchronization to settings prop and localStorage
  const getActiveLogo = () => {
    if (settings?.appLogoUrl && settings.appLogoUrl.trim()) {
      return settings.appLogoUrl;
    }
    try {
      const saved = localStorage.getItem('telecom_app_settings');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed?.appLogoUrl && parsed.appLogoUrl.trim()) {
          return parsed.appLogoUrl;
        }
      }
    } catch {}
    return '/app-logo.png';
  };

  const [activeLogo, setActiveLogo] = useState<string>(getActiveLogo);

  // Synchronize when settings change
  useEffect(() => {
    setActiveLogo(getActiveLogo());
  }, [settings?.appLogoUrl]);

  // Synchronize across tabs or local storage changes
  useEffect(() => {
    const handleStorageChange = () => {
      setActiveLogo(getActiveLogo());
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const inputRefs = [
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
  ];

  // Check biometric support & enrolled status
  useEffect(() => {
    let isMounted = true;
    (async () => {
      const supported = await isBiometricSupported();
      const enrolled = hasBiometricEnrolled(user.phone);
      if (isMounted) {
        setBioAvailable(supported && enrolled);
      }
    })();
    return () => {
      isMounted = false;
    };
  }, [user.phone]);

  // Auto focus first input on mount
  useEffect(() => {
    const timer = setTimeout(() => {
      inputRefs[0].current?.focus();
    }, 150);
    return () => clearTimeout(timer);
  }, []);

  // Format lock timestamp in Bengali
  const formatLockTime = (ts: number) => {
    const date = new Date(ts);
    try {
      const timeStr = date.toLocaleTimeString('bn-BD', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      });
      const dateStr = date.toLocaleDateString('bn-BD', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      });
      return { timeStr, dateStr };
    } catch {
      return {
        timeStr: date.toLocaleTimeString(),
        dateStr: date.toLocaleDateString(),
      };
    }
  };

  const { timeStr, dateStr } = formatLockTime(lockedTimestamp);

  // Validate entered PIN against user's PIN
  const handleVerifyPin = (fullPin: string) => {
    const expectedPin = user.pin || '1234';
    if (fullPin === expectedPin || (user.role === 'admin' && fullPin === '1986')) {
      if (settings.soundEnabled) {
        playNotificationTone();
      }
      onUnlock();
    } else {
      setErrorMessage('ভুল পিন! সঠিক ৪ সংখ্যার পিন প্রদান করুন।');
      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 600);
      setPinDigits(['', '', '', '']);
      inputRefs[0].current?.focus();
    }
  };

  const handleDigitChange = (index: number, val: string) => {
    setErrorMessage('');
    const numericChar = val.replace(/[^0-9]/g, '').slice(-1);

    const newDigits = [...pinDigits];
    newDigits[index] = numericChar;
    setPinDigits(newDigits);

    if (numericChar && index < 3) {
      inputRefs[index + 1].current?.focus();
    }

    const completedPin = newDigits.join('');
    if (completedPin.length === 4) {
      handleVerifyPin(completedPin);
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      if (!pinDigits[index] && index > 0) {
        const newDigits = [...pinDigits];
        newDigits[index - 1] = '';
        setPinDigits(newDigits);
        inputRefs[index - 1].current?.focus();
      } else {
        const newDigits = [...pinDigits];
        newDigits[index] = '';
        setPinDigits(newDigits);
      }
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pasteData = e.clipboardData.getData('text').replace(/[^0-9]/g, '').slice(0, 4);
    if (pasteData) {
      const newDigits = ['', '', '', ''];
      for (let i = 0; i < pasteData.length; i++) {
        newDigits[i] = pasteData[i];
      }
      setPinDigits(newDigits);
      if (pasteData.length === 4) {
        handleVerifyPin(pasteData);
      } else {
        inputRefs[Math.min(pasteData.length, 3)].current?.focus();
      }
    }
  };

  // Keypad button press
  const handleKeypadPress = (num: string) => {
    setErrorMessage('');
    const emptyIndex = pinDigits.findIndex((d) => d === '');
    if (emptyIndex !== -1) {
      const newDigits = [...pinDigits];
      newDigits[emptyIndex] = num;
      setPinDigits(newDigits);
      if (emptyIndex < 3) {
        inputRefs[emptyIndex + 1].current?.focus();
      }
      const completedPin = newDigits.join('');
      if (completedPin.length === 4) {
        handleVerifyPin(completedPin);
      }
    }
  };

  const handleKeypadBackspace = () => {
    setErrorMessage('');
    const lastFilledIndex = [...pinDigits].map((d, i) => (d !== '' ? i : -1)).filter((i) => i !== -1).pop();
    if (lastFilledIndex !== undefined && lastFilledIndex >= 0) {
      const newDigits = [...pinDigits];
      newDigits[lastFilledIndex] = '';
      setPinDigits(newDigits);
      inputRefs[lastFilledIndex].current?.focus();
    }
  };

  // Biometric authentication
  const handleBiometricUnlock = async () => {
    if (isAuthenticatingBio) return;
    setIsAuthenticatingBio(true);
    setErrorMessage('');
    try {
      const result = await authenticateBiometrics(user.phone);
      if (result.success) {
        if (settings.soundEnabled) {
          playNotificationTone();
        }
        onUnlock();
      } else if (result.error) {
        setErrorMessage(result.error);
      }
    } catch {
      setErrorMessage('বায়োমেট্রিক আনলক ব্যর্থ হয়েছে। পিন দিয়ে প্রবেশ করুন।');
    } finally {
      setIsAuthenticatingBio(false);
    }
  };

  return (
    <div className="w-full h-full min-h-[600px] flex flex-col justify-between p-5 bg-gradient-to-b from-slate-900 via-slate-950 to-purple-950 text-white select-none animate-fadeIn relative overflow-y-auto">
      {/* Top Security & Stamp Badge */}
      <div className="flex flex-col items-center text-center pt-2 sm:pt-4 space-y-2">
        {/* App Logo Display with dynamic key & reactive update */}
        <div className="relative inline-flex items-center justify-center">
          <div className="bg-white/15 backdrop-blur-md h-24 sm:h-28 w-32 sm:w-36 p-1.5 rounded-3xl border-2 border-white/20 shadow-xl flex items-center justify-center overflow-hidden">
            <img
              key={activeLogo}
              src={activeLogo}
              alt={settings.appName || 'M APPS'}
              className="w-full h-full object-contain drop-shadow-md select-none pointer-events-none"
              onError={() => {
                setActiveLogo('/app-logo.png');
              }}
            />
          </div>
          <div className="absolute -top-1.5 -right-2 w-7 h-7 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-600 border-2 border-slate-900 flex items-center justify-center shadow-md shadow-purple-600/40">
            <Lock className="w-3.5 h-3.5 text-white stroke-[2.5]" />
          </div>
        </div>

        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            {settings.appName || 'M APPS'} লক করা হয়েছে
          </h2>
          <p className="text-xs text-purple-200/80 font-medium mt-0.5">
            {lockReason || 'নিরাপত্তার স্বার্থে অ্যাপটি স্বয়ংক্রিয়ভাবে লক হয়েছে'}
          </p>
        </div>

        {/* Timestamp Stamp Container */}
        <div className="bg-white/10 backdrop-blur-md rounded-2xl px-4 py-2 border border-white/15 max-w-[280px] w-full text-center shadow-inner">
          <div className="flex items-center justify-center gap-1.5 text-[11px] font-bold text-amber-300">
            <Shield className="w-3.5 h-3.5 text-amber-400" />
            <span>লক হওয়ার টাইম স্ট্যাম্প</span>
          </div>
          <div className="text-xs font-mono font-black text-white mt-0.5">
            {timeStr}
          </div>
          <div className="text-[10px] text-white/60 font-medium">
            {dateStr}
          </div>
        </div>
      </div>

      {/* Center Profile & PIN Input */}
      <div className="my-auto py-4 flex flex-col items-center space-y-4">
        {/* User Card */}
        <div className="flex items-center gap-3 bg-white/5 border border-white/10 rounded-2xl px-3.5 py-2 max-w-[260px] w-full">
          <div className="w-9 h-9 rounded-full bg-purple-600 text-white font-black text-sm flex items-center justify-center shrink-0 border border-white/20">
            {user.profileImage ? (
              <img src={user.profileImage} alt={user.name} className="w-full h-full object-cover rounded-full" />
            ) : (
              user.name?.charAt(0) || 'U'
            )}
          </div>
          <div className="text-left truncate">
            <span className="text-xs font-black text-white block truncate">
              {user.name || 'সম্মানিত ইউজার'}
            </span>
            <span className="text-[11px] font-mono text-white/70 block truncate">
              {user.phone}
            </span>
          </div>
        </div>

        {/* PIN Input Instruction */}
        <div className="text-center">
          <span className="text-xs font-bold text-white/90">
            আপনার ৪ সংখ্যার গোপন পিন দিন
          </span>
        </div>

        {/* 4-Digit Input Boxes (Clean, Constrained Size for Mobile) */}
        <div
          className={`grid grid-cols-4 gap-3 max-w-[240px] w-full mx-auto transition-transform ${
            isShaking ? 'animate-shake' : ''
          }`}
          onPaste={handlePaste}
        >
          {pinDigits.map((digit, idx) => (
            <input
              key={idx}
              ref={inputRefs[idx]}
              type="password"
              inputMode="numeric"
              maxLength={1}
              value={digit}
              onChange={(e) => handleDigitChange(idx, e.target.value)}
              onKeyDown={(e) => handleKeyDown(idx, e)}
              className={`h-12 w-full text-center text-2xl font-black rounded-2xl border-2 transition-all outline-hidden shadow-inner ${
                digit
                  ? 'border-purple-400 bg-purple-950/70 text-purple-200 ring-2 ring-purple-500/40'
                  : 'border-white/20 bg-white/10 text-white focus:border-purple-400 focus:bg-white/15'
              }`}
            />
          ))}
        </div>

        {/* Error Feedback */}
        {errorMessage && (
          <div className="flex items-center gap-1.5 text-xs text-rose-400 font-bold bg-rose-950/60 border border-rose-800/60 px-3 py-1.5 rounded-xl animate-fadeIn text-center max-w-[280px]">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Biometric Quick Unlock (if supported) */}
        {bioAvailable && (
          <button
            type="button"
            onClick={handleBiometricUnlock}
            disabled={isAuthenticatingBio}
            className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 border border-purple-500/40 text-purple-200 text-xs font-bold active:scale-95 transition-all cursor-pointer shadow-xs"
          >
            <Fingerprint className="w-4 h-4 text-purple-300 animate-pulse" />
            <span>{isAuthenticatingBio ? 'যাচাই করা হচ্ছে...' : 'ফিঙ্গারপ্রিন্ট দিয়ে আনলক করুন'}</span>
          </button>
        )}
      </div>

      {/* On-screen Keypad for quick mobile touch */}
      <div className="max-w-[260px] w-full mx-auto space-y-2 pb-2">
        <div className="grid grid-cols-3 gap-2">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
            <button
              key={num}
              type="button"
              onClick={() => handleKeypadPress(num)}
              className="h-11 rounded-2xl bg-white/10 hover:bg-white/20 active:bg-purple-600 active:scale-95 text-white font-black text-lg transition-all flex items-center justify-center shadow-xs border border-white/10 cursor-pointer"
            >
              {num}
            </button>
          ))}

          {/* Bottom row: Biometric / Fingerprint, 0, Backspace */}
          <button
            type="button"
            onClick={bioAvailable ? handleBiometricUnlock : () => setPinDigits(['', '', '', ''])}
            title={bioAvailable ? 'ফিঙ্গারপ্রিন্ট' : 'পিন মুছুন'}
            className="h-11 rounded-2xl bg-white/10 hover:bg-white/20 active:scale-95 text-white/80 transition-all flex items-center justify-center border border-white/10 cursor-pointer"
          >
            {bioAvailable ? (
              <Fingerprint className="w-5 h-5 text-purple-300" />
            ) : (
              <span className="text-[11px] font-bold text-white/60">C</span>
            )}
          </button>

          <button
            type="button"
            onClick={() => handleKeypadPress('0')}
            className="h-11 rounded-2xl bg-white/10 hover:bg-white/20 active:bg-purple-600 active:scale-95 text-white font-black text-lg transition-all flex items-center justify-center shadow-xs border border-white/10 cursor-pointer"
          >
            0
          </button>

          <button
            type="button"
            onClick={handleKeypadBackspace}
            title="মুছুন"
            className="h-11 rounded-2xl bg-white/10 hover:bg-white/20 active:scale-95 text-white/80 hover:text-rose-400 transition-all flex items-center justify-center border border-white/10 cursor-pointer"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        {/* Switch Account / Logout */}
        <div className="pt-2 text-center">
          <button
            type="button"
            onClick={onLogout}
            className="inline-flex items-center gap-1.5 text-white/60 hover:text-white text-xs font-bold py-1 px-3 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>অন্য একাউন্টে লগইন করুন</span>
          </button>
        </div>
      </div>
    </div>
  );
};
