import React, { useState } from 'react';
import {
  MoreVertical,
  Eye,
  EyeOff,
  Lock,
} from 'lucide-react';
import { UserProfile, AppSettings } from '../types';
import { TakaSign } from './TakaSign';

interface HeaderProps {
  user: UserProfile;
  settings: AppSettings;
  hasTopBanner?: boolean;
  onUpdateSettings?: (settings: AppSettings) => void;
  onUpdateUser?: (updated: UserProfile) => void;
  onOpenSearch?: () => void;
  onOpenDrawer: () => void;
  onOpenAddMoney?: () => void;
  onOpenProfileEdit?: () => void;
  onRefreshData?: () => void;
  onOpenQrScanner?: () => void;
  onOpenAndroidApk?: () => void;
  onLockApp?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  settings,
  hasTopBanner = false,
  onUpdateSettings,
  onUpdateUser,
  onOpenSearch,
  onOpenDrawer,
  onOpenAddMoney,
  onOpenProfileEdit,
  onRefreshData,
  onOpenQrScanner,
  onOpenAndroidApk,
  onLockApp,
}) => {
  const [showBalance, setShowBalance] = useState(false);
  const [balanceType, setBalanceType] = useState<'main' | 'drive' | 'bank'>('main');

  const isDarkMode = settings.darkMode ?? (settings.theme === 'dark');
  const isBangla = settings.language !== 'en';

  // Synchronize status bar color dynamically with browser/WebAPK and native Android interface
  React.useEffect(() => {
    let themeColor = '#1d4ed8';
    if (isDarkMode) {
      themeColor = '#0f172a';
    } else {
      switch (settings.theme) {
        case 'purple':
          themeColor = '#4f46e5';
          break;
        case 'green':
          themeColor = '#047857';
          break;
        case 'orange':
          themeColor = '#ea580c';
          break;
        case 'red':
          themeColor = '#dc2626';
          break;
        case 'dark':
          themeColor = '#0f172a';
          break;
        case 'blue':
        default:
          themeColor = '#1d4ed8';
          break;
      }
    }
    // Update HTML meta theme-color tag
    const metaTag = document.querySelector('meta[name="theme-color"]');
    if (metaTag) {
      metaTag.setAttribute('content', themeColor);
    }
    // Update Android native status bar if running inside Android APK
    const win = window as any;
    if (win.AndroidNative && typeof win.AndroidNative.setStatusBarColor === 'function') {
      try {
        win.AndroidNative.setStatusBarColor(themeColor, false);
      } catch (e) {
        // Safe fallback
      }
    }
  }, [settings.theme, isDarkMode]);

  const getThemeGradient = () => {
    if (isDarkMode) {
      return 'bg-gradient-to-r from-[#0f172a] via-[#1e293b] to-[#334155] shadow-slate-950/40 border-b border-slate-700/50';
    }
    switch (settings.theme) {
      case 'purple':
        return 'bg-gradient-to-r from-[#6366f1] via-[#7c3aed] to-[#4f46e5] shadow-indigo-600/20';
      case 'green':
        return 'bg-gradient-to-r from-[#047857] via-[#059669] to-[#0d9488] shadow-emerald-600/20';
      case 'orange':
        return 'bg-gradient-to-r from-[#c2410c] via-[#ea580c] to-[#f97316] shadow-orange-500/20';
      case 'red':
        return 'bg-gradient-to-r from-[#b91c1c] via-[#dc2626] to-[#e11d48] shadow-rose-600/20';
      case 'dark':
        return 'bg-gradient-to-r from-[#1e293b] via-[#0f172a] to-[#334155] shadow-slate-950/40';
      case 'blue':
      default:
        return 'bg-gradient-to-r from-[#1d4ed8] via-[#2563eb] to-[#3b82f6] shadow-blue-600/20';
    }
  };

  const formatTk = (amount: number) => {
    if (!isBangla) {
      return amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
    return amount.toLocaleString('bn-BD', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const getActiveBalance = () => {
    return {
      title: isBangla ? 'কারেন্ট ব্যালেন্স' : 'Current Balance',
      amount: user.mainBalance ?? 0,
    };
  };

  const currentBal = getActiveBalance();

  return (
    <header
      className={`w-full ${getThemeGradient()} pb-3.5 px-4 sm:px-5 rounded-b-2xl text-white shadow-md select-none transition-colors duration-200`}
      style={{
        paddingTop: hasTopBanner
          ? '10px'
          : 'max(10px, calc(env(safe-area-inset-top, 0px) + 8px))',
      }}
    >
      {/* Top row: Avatar + Name & Three Dot Menu Button */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {/* Avatar circle & Profile Quick Edit */}
          <button
            id="header-profile-avatar"
            type="button"
            onClick={onOpenProfileEdit || onOpenDrawer}
            title={isBangla ? 'নাম ও ছবি পরিবর্তন করতে ক্লিক করুন' : 'Click to change name and photo'}
            className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-white text-[#3090F8] flex items-center justify-center font-black text-lg shadow-sm border-2 border-white/60 overflow-hidden relative cursor-pointer group"
          >
            {user.profileImage ? (
              <img
                src={user.profileImage}
                alt={user.name}
                className="w-full h-full object-cover rounded-full"
              />
            ) : (
              user.name ? user.name.charAt(0).toUpperCase() : 'M'
            )}
            {/* Small camera badge to visually hint that tapping edits profile picture */}
            <div className="absolute inset-0 bg-black/35 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <span className="text-white text-[10px]">📷</span>
            </div>
          </button>

          <button
            id="header-profile-name-btn"
            type="button"
            onClick={onOpenProfileEdit || onOpenDrawer}
            title={isBangla ? 'নাম ও ছবি পরিবর্তন করতে ক্লিক করুন' : 'Click to change name and photo'}
            className="text-left cursor-pointer group/name flex items-center"
          >
            <span className="text-white font-black text-base sm:text-lg tracking-tight block group-hover/name:underline decoration-white/70">
              {user.name || 'Md Miraz GP'}
            </span>
          </button>
        </div>

        {/* Action icons: Quick Lock button & Three-dot menu button */}
        <div className="flex items-center gap-2">
          {onLockApp && (
            <button
              id="header-lock-app-btn"
              type="button"
              onClick={onLockApp}
              aria-label="অ্যাপ লক করুন"
              title="এখনই অ্যাপ লক করুন (Lock Screen)"
              className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 text-white backdrop-blur-md flex items-center justify-center active:scale-95 transition-all shadow-xs cursor-pointer border border-white/30"
            >
              <Lock className="w-4 h-4" />
            </button>
          )}

          <button
            id="header-three-dots-btn"
            type="button"
            onClick={onOpenDrawer}
            aria-label={isBangla ? 'মেনু ও সেটিংস' : 'Menu & Settings'}
            title={isBangla ? 'মেনু ও সেটিংস' : 'Menu & Settings'}
            className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 text-white backdrop-blur-md flex items-center justify-center active:scale-95 transition-all shadow-xs cursor-pointer border border-white/30"
          >
            <MoreVertical className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Harmonious, Color-Integrated Balance Pill (Shifted right to align under the profile name) */}
      <div className="mt-2.5 flex items-center ml-12 sm:ml-14">
        <button
          id="header-balance-pill-btn"
          type="button"
          onClick={() => setShowBalance(!showBalance)}
          className="relative inline-flex items-center gap-2 bg-white/18 hover:bg-white/28 text-white px-3.5 sm:px-4 h-8 rounded-full font-bold text-xs sm:text-sm backdrop-blur-md border border-white/30 shadow-xs overflow-hidden group cursor-pointer select-none"
        >
          {/* Subtle round badge for Currency Symbol matching header theme */}
          {!showBalance && (
            <span className="w-5 h-5 rounded-full bg-white/95 text-blue-600 flex items-center justify-center font-black text-xs shadow-xs shrink-0">
              ৳
            </span>
          )}
          <span className="tracking-tight text-white font-bold">
            {showBalance ? (
              <span className="font-mono font-black text-white text-sm sm:text-base flex items-baseline">
                {formatTk(currentBal.amount)} <TakaSign color="text-amber-300" />
              </span>
            ) : (
              <span className="text-white/95 font-semibold">{isBangla ? 'ব্যালেন্স দেখুন' : 'Tap for Balance'}</span>
            )}
          </span>
          <div className="text-white/80 group-hover:text-white transition-colors ml-0.5">
            {showBalance ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
          </div>
        </button>
      </div>
    </header>
  );
};

