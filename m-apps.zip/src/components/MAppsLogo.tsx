import React, { useState } from 'react';

export interface MAppsLogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
  className?: string;
  customLogoUrl?: string;
  appName?: string;
  appTagline?: string;
  logoPreset?: string; // Kept for interface backward compatibility
}

export const MAppsLogo: React.FC<MAppsLogoProps> = ({
  size = 'lg',
  showSubtitle = true,
  className = '',
  customLogoUrl,
  appName = 'M APPS',
  appTagline = 'মোবাইল রিচার্জ অ্যাপ',
}) => {
  const [imageError, setImageError] = useState(false);

  // Active logo source: uploaded custom logo or default public app logo
  const logoSrc = customLogoUrl && customLogoUrl.trim().length > 0 ? customLogoUrl : '/app-logo.png';

  // Reset image error whenever logoSrc changes
  React.useEffect(() => {
    setImageError(false);
  }, [logoSrc]);

  // Responsive dimensions designed so logo is large, crisp, and beautifully fills the frame
  const sizeConfig = {
    xs: {
      card: 'h-9 min-w-[36px] max-w-[100px] p-1 rounded-lg',
      imgMaxH: 'max-h-7',
      titleSize: 'text-xs',
      subSize: 'text-[8px]',
    },
    sm: {
      card: 'h-12 min-w-[48px] max-w-[120px] p-1 rounded-xl',
      imgMaxH: 'max-h-10',
      titleSize: 'text-sm',
      subSize: 'text-[9px]',
    },
    md: {
      card: 'h-24 sm:h-28 min-w-[96px] max-w-[200px] p-1.5 rounded-2xl',
      imgMaxH: 'max-h-20 sm:max-h-24',
      titleSize: 'text-lg',
      subSize: 'text-xs',
    },
    lg: {
      card: 'h-28 sm:h-32 min-w-[120px] max-w-[240px] p-1.5 rounded-3xl',
      imgMaxH: 'max-h-24 sm:max-h-28',
      titleSize: 'text-xl',
      subSize: 'text-xs',
    },
    xl: {
      card: 'h-36 sm:h-40 min-w-[140px] max-w-[280px] p-2 rounded-3xl',
      imgMaxH: 'max-h-32 sm:max-h-36',
      titleSize: 'text-2xl',
      subSize: 'text-sm',
    },
  }[size];

  return (
    <div className={`flex flex-col items-center justify-center text-center ${className}`}>
      {/* Clean, spacious card container with natural aspect ratio support */}
      <div
        className={`${sizeConfig.card} bg-white shadow-lg shadow-emerald-600/10 border-2 border-slate-100/90 flex items-center justify-center relative transition-transform hover:scale-[1.02] duration-200 overflow-hidden`}
      >
        {/* Soft elegant backdrop */}
        <div className="absolute inset-0 bg-gradient-to-tr from-emerald-50/40 via-white to-blue-50/40 pointer-events-none" />

        {!imageError ? (
          <img
            src={logoSrc}
            alt={appName || 'App Logo'}
            className={`w-full h-full ${sizeConfig.imgMaxH} max-w-full object-contain p-0.5 drop-shadow-xs relative z-10 transition-opacity duration-200`}
            loading="eager"
            onError={() => setImageError(true)}
          />
        ) : (
          /* High-quality vector fallback if PNG fails to load */
          <div className="flex items-center justify-center gap-1 relative z-10 font-black">
            <span className="text-emerald-600 text-2xl font-black">M</span>
            <span className="text-pink-600 text-sm bg-pink-100 px-1.5 py-0.5 rounded font-black">APPS</span>
          </div>
        )}
      </div>

      {/* App Title & Subtitle */}
      {showSubtitle && (
        <div className="mt-2.5">
          <div className="flex items-center justify-center gap-1.5">
            <span className={`font-black tracking-tight bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 bg-clip-text text-transparent ${sizeConfig.titleSize}`}>
              {appName}
            </span>
          </div>
          {appTagline && (
            <p className={`text-slate-600 font-bold tracking-wide mt-0.5 ${sizeConfig.subSize}`}>
              {appTagline}
            </p>
          )}
        </div>
      )}
    </div>
  );
};
