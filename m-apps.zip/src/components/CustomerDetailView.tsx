import React, { useState, useMemo } from 'react';
import {
  ArrowLeft,
  Search,
  ShoppingCart,
  Store,
  Wallet,
  CreditCard,
  Plus,
  Edit2,
  Trash2,
  X,
  Coins,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Minus,
  ChevronDown,
  Settings2,
  MessageCircle,
  Check,
} from 'lucide-react';
import { AppSettings, CustomerAccount, CustomerTransaction, SocialCommunityLinks } from '../types';
import { generateCustomerReceiptMessage, sendWhatsAppReceipt } from '../utils/receipt';

interface CustomerDetailViewProps {
  customer: CustomerAccount;
  allCustomers?: CustomerAccount[];
  settings?: AppSettings;
  socialLinks?: SocialCommunityLinks;
  onBack: () => void;
  onAddTransaction: (customerId: string, trx: CustomerTransaction) => void;
  onUpdateCustomerTransaction: (customerId: string, trx: CustomerTransaction) => void;
  onDeleteCustomerTransaction: (customerId: string, trxId: string) => void;
  onDeleteCustomer?: (customerId: string) => void;
}

export const CustomerDetailView: React.FC<CustomerDetailViewProps> = ({
  customer,
  allCustomers = [],
  settings,
  socialLinks,
  onBack,
  onAddTransaction,
  onUpdateCustomerTransaction,
  onDeleteCustomerTransaction,
  onDeleteCustomer,
}) => {
  const [searchDate, setSearchDate] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTrx, setEditingTrx] = useState<CustomerTransaction | null>(null);

  // Quick Deposit Modal state (for collecting payment on due later)
  const [quickDepositTrx, setQuickDepositTrx] = useState<CustomerTransaction | null>(null);
  const [quickDepositAmount, setQuickDepositAmount] = useState('');

  // Pre-saved product list (shared with Shop Ledger)
  const DEFAULT_PRESET_PRODUCTS = [
    'চাল (নাজিরশাইল/মিনিকেট)',
    'সয়াবিন তেল (১ লিটার)',
    'সয়াবিন তেল (৫ লিটার)',
    'সরিষার তেল',
    'চিনি',
    'মসুর ডাল',
    'মুগ ডাল',
    'ছোলা বুট',
    'লবণ',
    'আটা / ময়দা',
    'ডিম (১ হালি)',
    'পেঁয়াজ',
    'রসুন ও আদা',
    'আলু',
    'চা পাতা',
    'গুঁড়ো দুধ',
    'সাবান / গুঁড়ো সাবান',
    'হুইল পাউডার',
    'বিস্কুট / টোস্ট',
    'নুডলস',
    'মসলাপাতি',
    'মোবাইল রিচার্জ',
    'ড্রাইভ অফার প্যাক',
  ];

  const DEFAULT_PRESET_QUANTITIES = [
    '১ কেজি',
    '২ কেজি',
    '৫ কেজি',
    '১/২ কেজি (৫০০ গ্রাম)',
    '২৫০ গ্রাম',
    '১ পিস',
    '২ পিস',
    '৪ পিস (হালি)',
    '১২ পিস (১ ডজন)',
    '১ প্যাকেট',
    '১ লিটার',
    '২ লিটার',
    '৫ লিটার',
    '১ বস্তা',
    '১ কার্টুন',
    '১ বক্স',
  ];

  const DEFAULT_PRESET_CUSTOMERS = [
    'ক্যাশ খদ্দের / নগদ কাস্টমার',
    'রহিম মিয়া (০১৭xxxxxxxx)',
    'করিম উদ্দিন (০১৮xxxxxxxx)',
    'মো: রফিকুল ইসলাম',
    'আলমগীর হোসেন',
    'বাবু মিয়া',
    'সেলিম রেজা',
  ];

  const [savedProducts, setSavedProducts] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('tally_saved_products');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return DEFAULT_PRESET_PRODUCTS;
  });

  const [savedQuantities, setSavedQuantities] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('tally_saved_quantities');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return DEFAULT_PRESET_QUANTITIES;
  });

  const [savedCustomerOptions, setSavedCustomerOptions] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('tally_saved_customers');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return DEFAULT_PRESET_CUSTOMERS;
  });

  // Combine saved customers with allCustomers prop
  const allCustomerOptions = useMemo(() => {
    const list = [...savedCustomerOptions];
    const customerPool = allCustomers.length > 0 ? allCustomers : [customer];
    customerPool.forEach((c) => {
      const label = c.name + (c.phone ? ` (${c.phone})` : '');
      if (!list.includes(label) && !list.includes(c.name)) {
        list.push(label);
      }
    });
    return list;
  }, [savedCustomerOptions, allCustomers, customer]);

  const [dropdownManageTab, setDropdownManageTab] = useState<'products' | 'quantities' | 'customers'>('products');
  const [newCustomProductInput, setNewCustomProductInput] = useState('');
  const [newCustomQuantityInput, setNewCustomQuantityInput] = useState('');
  const [newCustomCustomerInput, setNewCustomCustomerInput] = useState('');
  const [showManageProducts, setShowManageProducts] = useState(false);

  const handleAddProductToDropdown = (nameToAdd?: string) => {
    const target = (nameToAdd || newCustomProductInput || itemName || '').trim();
    if (!target) return;
    if (savedProducts.includes(target)) return;
    const updated = [target, ...savedProducts];
    setSavedProducts(updated);
    try {
      localStorage.setItem('tally_saved_products', JSON.stringify(updated));
    } catch (e) {}
    setNewCustomProductInput('');
    setItemName(target);
  };

  const handleDeleteProductFromDropdown = (nameToDelete: string) => {
    const updated = savedProducts.filter((p) => p !== nameToDelete);
    setSavedProducts(updated);
    try {
      localStorage.setItem('tally_saved_products', JSON.stringify(updated));
    } catch (e) {}
  };

  const handleAddQuantityToDropdown = (qtyToAdd?: string) => {
    const target = (qtyToAdd || newCustomQuantityInput || newCustomProductInput || quantity || '').trim();
    if (!target) return;
    if (savedQuantities.includes(target)) return;
    const updated = [target, ...savedQuantities];
    setSavedQuantities(updated);
    try {
      localStorage.setItem('tally_saved_quantities', JSON.stringify(updated));
    } catch (e) {}
    setNewCustomQuantityInput('');
    setNewCustomProductInput('');
    setQuantity(target);
  };

  const handleDeleteQuantityFromDropdown = (qtyToDelete: string) => {
    const updated = savedQuantities.filter((q) => q !== qtyToDelete);
    setSavedQuantities(updated);
    try {
      localStorage.setItem('tally_saved_quantities', JSON.stringify(updated));
    } catch (e) {}
  };

  const handleAddCustomerToDropdown = (custToAdd?: string) => {
    const target = (custToAdd || newCustomCustomerInput || customerInfo || '').trim();
    if (!target) return;
    if (savedCustomerOptions.includes(target)) return;
    const updated = [target, ...savedCustomerOptions];
    setSavedCustomerOptions(updated);
    try {
      localStorage.setItem('tally_saved_customers', JSON.stringify(updated));
    } catch (e) {}
    setNewCustomCustomerInput('');
    setCustomerInfo(target);
  };

  const handleDeleteCustomerFromDropdown = (custToDelete: string) => {
    const updated = savedCustomerOptions.filter((c) => c !== custToDelete);
    setSavedCustomerOptions(updated);
    try {
      localStorage.setItem('tally_saved_customers', JSON.stringify(updated));
    } catch (e) {}
  };

  // Form State: কেনা, বিক্রি, জমা অপশনাল এবং ইনপুট বক্সে সর্বদা '0' থাকবে
  const [itemName, setItemName] = useState('পণ্য বিক্রি / হিসাব');
  const [quantity, setQuantity] = useState('');
  const [customerInfo, setCustomerInfo] = useState(`${customer.name}${customer.phone ? ` (${customer.phone})` : ''}`);
  const [buyPrice, setBuyPrice] = useState('0');
  const [sellPrice, setSellPrice] = useState('0');
  const [depositAmount, setDepositAmount] = useState('0');
  const [profitInput, setProfitInput] = useState('');
  const [note, setNote] = useState('');
  const [sendReceiptOnSubmit, setSendReceiptOnSubmit] = useState(false);

  // Input numeric helpers to guarantee no empty/broken input boxes
  const handlePriceChange = (
    setter: React.Dispatch<React.SetStateAction<string>>,
    value: string
  ) => {
    const clean = value.replace(/[^0-9.]/g, '');
    setter(clean);
  };

  const handlePriceBlur = (
    currentValue: string,
    setter: React.Dispatch<React.SetStateAction<string>>
  ) => {
    if (!currentValue || isNaN(Number(currentValue))) {
      setter('0');
    } else {
      const num = parseFloat(currentValue);
      setter(String(num));
    }
  };

  const handleStepAmount = (
    currentValue: string,
    setter: React.Dispatch<React.SetStateAction<string>>,
    delta: number
  ) => {
    const current = parseFloat(currentValue) || 0;
    const next = Math.max(0, current + delta);
    setter(String(next));
  };

  const handleSetFullDue = () => {
    setDepositAmount('0');
  };

  const handleSetFullPaid = () => {
    setDepositAmount(sellPrice);
  };

  // Live calculation in form
  const numBuy = parseFloat(buyPrice) || 0;
  const numSell = parseFloat(sellPrice) || 0;
  const numDeposit = parseFloat(depositAmount) || 0;
  const calculatedDue = numSell > 0 ? Math.max(0, numSell - numDeposit) : 0;
  const calculatedSurplus = Math.max(0, numDeposit - numSell);
  const autoProfit = numBuy > 0 && numSell > 0 ? numSell - numBuy : 0;
  const calculatedProfit = profitInput !== '' ? parseFloat(profitInput) || 0 : autoProfit;

  const isFullyPaid = numSell > 0 && calculatedDue === 0 && numDeposit >= numSell;
  const isNoDeposit = numSell > 0 && numDeposit === 0;
  const isSurplusDeposit = numDeposit > numSell && numSell > 0;

  // Totals for this customer
  const totalBuy = (customer.transactions || []).reduce((acc, t) => acc + (Number(t.buyPrice) || 0), 0);
  const totalSell = (customer.transactions || []).reduce((acc, t) => {
    if (t.itemName && t.itemName.includes('পূর্বের বাকি') && (Number(t.buyPrice) || 0) === 0) {
      return acc;
    }
    return acc + (Number(t.sellPrice) || 0);
  }, 0);
  const allCharges = (customer.transactions || []).reduce((acc, t) => acc + (Number(t.sellPrice) || 0), 0);
  const totalDeposit = (customer.transactions || []).reduce((acc, t) => acc + (Number(t.depositAmount) || 0), 0);
  const totalDue = Math.max(0, allCharges - totalDeposit);
  const totalSurplus = Math.max(0, totalDeposit - allCharges);
  const totalProfit = (customer.transactions || []).reduce((acc, t) => {
    if (t.profit != null && t.profit !== undefined && t.profit !== 0) {
      return acc + Number(t.profit);
    }
    const buy = Number(t.buyPrice) || 0;
    const sell = Number(t.sellPrice) || 0;
    if (buy > 0 && sell > 0) {
      return acc + (sell - buy);
    }
    return acc;
  }, 0);

  const formatTk = (amount: number) => {
    if (amount < 0) {
      return `-${Math.abs(amount).toLocaleString('en-IN')} ৳`;
    }
    return `${amount.toLocaleString('en-IN')} ৳`;
  };

  const filteredTransactions = (customer.transactions || []).filter((t) => {
    if (!searchDate.trim()) return true;
    const query = searchDate.toLowerCase();
    return (
      (t.date || '').toLowerCase().includes(query) ||
      (t.time || '').toLowerCase().includes(query) ||
      (t.itemName || '').toLowerCase().includes(query) ||
      (t.note || '').toLowerCase().includes(query)
    );
  });

  const handleOpenAddModal = () => {
    setEditingTrx(null);
    setItemName('পণ্য বিক্রি / হিসাব');
    setQuantity('');
    setCustomerInfo(`${customer.name}${customer.phone ? ` (${customer.phone})` : ''}`);
    setBuyPrice('0');
    setSellPrice('0');
    setDepositAmount('0');
    setProfitInput('');
    setNote('');
    setSendReceiptOnSubmit(false);
    setShowManageProducts(false);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (trx: CustomerTransaction) => {
    setEditingTrx(trx);
    setItemName(trx.itemName || '');
    setQuantity(trx.quantity || '');
    setCustomerInfo(`${customer.name}${customer.phone ? ` (${customer.phone})` : ''}`);
    setBuyPrice(String(trx.buyPrice ?? '0'));
    setSellPrice(String(trx.sellPrice ?? '0'));
    setDepositAmount(String(trx.depositAmount ?? '0'));
    setProfitInput(trx.profit !== undefined && trx.profit !== null ? String(trx.profit) : '');
    setNote(trx.note || '');
    setSendReceiptOnSubmit(false);
    setShowManageProducts(false);
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalItemName = itemName.trim() || 'পণ্য বিক্রি / হিসাব';

    // Auto save item to savedProducts
    if (finalItemName && !savedProducts.includes(finalItemName)) {
      const updated = [finalItemName, ...savedProducts];
      setSavedProducts(updated);
      try {
        localStorage.setItem('tally_saved_products', JSON.stringify(updated));
      } catch (err) {}
    }

    const bPrice = parseFloat(buyPrice) || 0;
    const sPrice = parseFloat(sellPrice) || 0;
    const dAmount = parseFloat(depositAmount) || 0;
    const due = sPrice > 0 ? Math.max(0, sPrice - dAmount) : 0;
    const profit = calculatedProfit;

    if (editingTrx) {
      const updatedTrx: CustomerTransaction = {
        ...editingTrx,
        itemName: finalItemName,
        quantity: quantity.trim() || undefined,
        buyPrice: bPrice,
        sellPrice: sPrice,
        depositAmount: dAmount,
        dueAmount: due,
        profit: profit,
        note: note.trim() || undefined,
      };
      onUpdateCustomerTransaction(customer.id, updatedTrx);
    } else {
      const now = new Date();
      const timeStr = now.toLocaleTimeString('bn-BD', {
        hour: '2-digit',
        minute: '2-digit',
      });
      const newTrx: CustomerTransaction = {
        id: `CTX-${Date.now()}`,
        itemName: finalItemName,
        quantity: quantity.trim() || undefined,
        buyPrice: bPrice,
        sellPrice: sPrice,
        depositAmount: dAmount,
        dueAmount: due,
        profit: profit,
        date: 'আজ',
        time: timeStr,
        note: note.trim() || undefined,
        createdAtMs: Date.now(),
      };
      onAddTransaction(customer.id, newTrx);

      if (sendReceiptOnSubmit) {
        const nextSales = totalSell + sPrice;
        const nextDeposit = totalDeposit + dAmount;
        const msg = generateCustomerReceiptMessage(
          customer.name,
          nextSales,
          nextDeposit,
          settings?.adminContactNumber || '01712345678'
        );
        sendWhatsAppReceipt(customer.phone, msg);
      }
    }
    setIsModalOpen(false);
  };

  // Quick Deposit Handler
  const handleOpenQuickDeposit = (trx: CustomerTransaction) => {
    setQuickDepositTrx(trx);
    setQuickDepositAmount('');
  };

  const handleApplyQuickDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickDepositTrx) return;
    const addedAmount = parseFloat(quickDepositAmount) || 0;
    if (addedAmount <= 0) return;

    const currentDeposit = Number(quickDepositTrx.depositAmount) || 0;
    const newDeposit = currentDeposit + addedAmount;
    const currentSell = Number(quickDepositTrx.sellPrice) || 0;
    const newDue = currentSell > 0 ? Math.max(0, currentSell - newDeposit) : 0;

    const updatedTrx: CustomerTransaction = {
      ...quickDepositTrx,
      depositAmount: newDeposit,
      dueAmount: newDue,
      note: quickDepositTrx.note
        ? `${quickDepositTrx.note} | জমা: +${addedAmount}৳`
        : `জমা প্রাপ্তি: +${addedAmount}৳`,
    };

    onUpdateCustomerTransaction(customer.id, updatedTrx);
    setQuickDepositTrx(null);
    setQuickDepositAmount('');
  };

  const handleSendWhatsAppReceiptMessage = () => {
    const msg = generateCustomerReceiptMessage(
      customer.name,
      totalSell,
      totalDeposit,
      settings?.adminContactNumber || socialLinks?.adminContactNumber || '01712345678'
    );
    sendWhatsAppReceipt(customer.phone, msg);
  };

  return (
    <div className="w-full bg-[#f8fafc] pb-8 animate-fadeIn text-slate-900">
      {/* Uniform Premium Header */}
      <div
        className="bg-gradient-to-r from-[#1e1b4b] via-[#312e81] to-[#4338ca] text-white px-5 pb-5 rounded-b-[28px] shadow-md shadow-indigo-950/15"
        style={{
          paddingTop: 'max(14px, calc(env(safe-area-inset-top, 0px) + 10px))',
        }}
      >
        <div className="flex items-center justify-between mb-3">
          <button
            type="button"
            onClick={onBack}
            className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors cursor-pointer"
            title="ফিরে যান"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="text-center flex-1 pr-1">
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
              কাস্টমার হিসাব
            </h1>
            <p className="text-xs sm:text-sm text-indigo-200 mt-0.5 font-medium">
              {customer.name} {customer.phone ? `(${customer.phone})` : ''}
            </p>
          </div>

          {onDeleteCustomer ? (
            <button
              type="button"
              onClick={() => {
                if (window.confirm(`আপনি কি "${customer.name}" এর কাস্টমার হিসাব ডিলিট করতে চান?`)) {
                  onDeleteCustomer(customer.id);
                }
              }}
              className="w-9 h-9 rounded-full bg-rose-500/30 hover:bg-rose-500/50 text-white flex items-center justify-center transition-colors cursor-pointer"
              title="কাস্টমার ডিলিট করুন"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          ) : (
            <div className="w-9 h-9" />
          )}
        </div>
      </div>

      {/* 5 Unified Summary Metric Cards: কেনা, বিক্রি, লাভ, জমা, বাকি (দোকানের হিসাবের সাথে হুবহু অভিন্ন ডিজাইন) */}
      <div className="px-4 -mt-3">
        <div className="bg-white rounded-3xl p-3.5 shadow-md border border-slate-100 space-y-2.5">
          {/* Top 3 Cards: কেনা, বিক্রি, লাভ - লোগো বামে এবং টেক্সট বোল্ড */}
          <div className="grid grid-cols-3 gap-2">
            {/* মোট কেনা */}
            <div className="flex items-center justify-start gap-2 p-2 rounded-xl bg-indigo-50/90 border border-indigo-200">
              <div className="w-8 h-8 rounded-full bg-white text-indigo-700 flex items-center justify-center shadow-xs border border-indigo-200 shrink-0">
                <ShoppingCart className="w-4 h-4 stroke-[2.8]" />
              </div>
              <div className="flex flex-col min-w-0 text-left">
                <span className="text-[11px] font-black text-slate-800 leading-none">কেনা</span>
                <span className="text-xs sm:text-sm font-black text-indigo-700 tracking-tight mt-0.5">
                  {formatTk(totalBuy)}
                </span>
              </div>
            </div>

            {/* মোট বিক্রি */}
            <div className="flex items-center justify-start gap-2 p-2 rounded-xl bg-rose-50/90 border border-rose-200">
              <div className="w-8 h-8 rounded-full bg-white text-rose-600 flex items-center justify-center shadow-xs border border-rose-200 shrink-0">
                <Store className="w-4 h-4 stroke-[2.8]" />
              </div>
              <div className="flex flex-col min-w-0 text-left">
                <span className="text-[11px] font-black text-slate-800 leading-none">বিক্রি</span>
                <span className="text-xs sm:text-sm font-black text-rose-600 tracking-tight mt-0.5">
                  {formatTk(totalSell)}
                </span>
              </div>
            </div>

            {/* মোট লাভ */}
            <div className="flex items-center justify-start gap-2 p-2 rounded-xl bg-emerald-50/90 border border-emerald-300">
              <div className="w-8 h-8 rounded-full bg-white text-emerald-700 flex items-center justify-center shadow-xs border border-emerald-300 shrink-0">
                <TrendingUp className="w-4 h-4 stroke-[2.8]" />
              </div>
              <div className="flex flex-col min-w-0 text-left">
                <span className="text-[11px] font-black text-emerald-900 leading-none">লাভ</span>
                <span className="text-xs sm:text-sm font-black text-emerald-600 tracking-tight mt-0.5">
                  {totalProfit >= 0 ? `+${formatTk(totalProfit)}` : formatTk(totalProfit)}
                </span>
              </div>
            </div>
          </div>

          {/* Bottom 2 Cards: মোট জমা ও মোট বাকি */}
          <div className="grid grid-cols-2 gap-2 text-center">
            {/* মোট জমা */}
            <div className="flex items-center justify-between p-2.5 px-3 rounded-2xl bg-emerald-50/80 border border-emerald-200">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-white text-emerald-700 flex items-center justify-center shadow-sm border border-emerald-200 shrink-0">
                  <Wallet className="w-4 h-4 stroke-[2.8]" />
                </div>
                <div className="text-left">
                  <span className="text-xs font-black text-slate-800 block leading-tight">মোট জমা</span>
                  <span className="text-[10px] text-slate-500 font-bold">নগদ/ব্যাংক</span>
                </div>
              </div>
              <span className="text-sm sm:text-base font-black text-emerald-600 tracking-tight">
                {formatTk(totalDeposit)}
              </span>
            </div>

            {/* বাকি অথবা জমা আছে */}
            {totalSurplus > 0 ? (
              <div className="flex items-center justify-between p-2.5 px-3 rounded-2xl bg-emerald-50/90 border border-emerald-300">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-white text-emerald-700 flex items-center justify-center shadow-sm border border-emerald-300 shrink-0">
                    <Coins className="w-4 h-4 stroke-[2.8]" />
                  </div>
                  <div className="text-left">
                    <span className="text-xs font-black text-emerald-900 block leading-tight">জমা আছে</span>
                    <span className="text-[10px] text-emerald-700 font-bold">উদ্বৃত্ত জমা</span>
                  </div>
                </div>
                <span className="text-sm sm:text-base font-black text-emerald-600 tracking-tight">
                  +{formatTk(totalSurplus)}
                </span>
              </div>
            ) : (
              <div className="flex items-center justify-between p-2.5 px-3 rounded-2xl bg-amber-50/80 border border-amber-200">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-white text-amber-700 flex items-center justify-center shadow-sm border border-amber-200 shrink-0">
                    <CreditCard className="w-4 h-4 stroke-[2.8]" />
                  </div>
                  <div className="text-left">
                    <span className="text-xs font-black text-slate-800 block leading-tight">বাকি আছে</span>
                    <span className="text-[10px] text-slate-500 font-bold">পাওনা টাকা</span>
                  </div>
                </div>
                <span className="text-sm sm:text-base font-black text-amber-600 tracking-tight">
                  {formatTk(totalDue)}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Uniform Action Buttons: + নতুন হিসাব যোগ করুন ও WhatsApp রসিদ */}
      <div className="px-4 mt-3.5 flex items-center gap-2">
        <button
          id="btn-add-customer-transaction"
          type="button"
          onClick={handleOpenAddModal}
          className="flex-1 py-3.5 sm:py-4 bg-[#4323d4] hover:bg-[#371cb8] text-white font-black text-sm sm:text-base rounded-2xl shadow-lg shadow-indigo-600/25 flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer"
        >
          <Plus className="w-5 h-5" />
          <span>কাস্টমারের নতুন হিসাব যোগ করুন</span>
        </button>

        <button
          type="button"
          onClick={handleSendWhatsAppReceiptMessage}
          title="WhatsApp এ অফিসিয়াল রসিদ পাঠান"
          className="py-3.5 sm:py-4 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl shadow-md transition-colors flex items-center justify-center cursor-pointer gap-1.5 font-bold text-xs sm:text-sm shrink-0"
        >
          <MessageCircle className="w-4 h-4" />
          <span className="hidden sm:inline">WhatsApp</span>
          <span>রসিদ</span>
        </button>
      </div>

      {/* Date / Item Search Bar */}
      <div className="px-4 mt-4">
        <div className="bg-white rounded-2xl p-2 px-3 border border-slate-200/80 shadow-2xs flex items-center gap-2">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            value={searchDate}
            onChange={(e) => setSearchDate(e.target.value)}
            className="w-full text-xs sm:text-sm font-semibold text-slate-800 outline-none placeholder:text-slate-400"
            placeholder="তারিখ বা পণ্যের নাম অনুযায়ী খুঁজুন"
          />
          <span className="text-[11px] font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-xl shrink-0">
            {filteredTransactions.length} টি লেনদেন
          </span>
        </div>
      </div>

      {/* Transactions List Section */}
      <div className="px-4 mt-4">
        <div className="flex items-center justify-between mb-2.5">
          <h2 className="text-sm sm:text-base font-extrabold text-slate-900">
            কাস্টমারের লেনদেন বিবরণী
          </h2>
          <span className="text-xs font-semibold text-slate-500">
            মোট রেকর্ড: {filteredTransactions.length}
          </span>
        </div>

        <div className="space-y-3">
          {filteredTransactions.length === 0 ? (
            <div className="p-8 text-center bg-white rounded-3xl border border-slate-200 text-slate-400 text-xs">
              এখনও কোনো লেনদেন যোগ করা হয়নি
            </div>
          ) : (
            filteredTransactions.map((trx) => {
              const itemBuy = Number(trx.buyPrice) || 0;
              const itemSell = Number(trx.sellPrice) || 0;
              const itemDeposit = Number(trx.depositAmount) || 0;
              const itemDue = Number(trx.dueAmount) || 0;
              const itemSurplus = itemDeposit > itemSell ? itemDeposit - itemSell : 0;
              const hasBuy = itemBuy > 0;
              const hasSell = itemSell > 0;
              const hasDeposit = itemDeposit > 0;
              const hasDue = itemDue > 0;
              const hasSurplus = itemSurplus > 0;
              const hasBothPrices = itemBuy > 0 && itemSell > 0;

              const itemProfit =
                trx.profit !== undefined && trx.profit !== null && trx.profit !== 0
                  ? Number(trx.profit)
                  : hasBothPrices
                  ? itemSell - itemBuy
                  : 0;

              return (
                <div
                  key={trx.id}
                  className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs hover:shadow-xs hover:border-indigo-300 transition-all p-3 sm:p-3.5 space-y-2.5"
                >
                  {/* Top Row: Left Details with Customer Name on the left & Right Price/Profit */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div
                        onClick={() => handleOpenEditModal(trx)}
                        className="cursor-pointer"
                        title="এডিট করতে ক্লিক করুন"
                      >
                        {/* কাস্টমার নাম বাম পাশে */}
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[10px] font-black text-purple-700 bg-purple-50 border border-purple-200 px-2 py-0.5 rounded inline-flex items-center gap-1 shadow-2xs">
                            <span>👤</span>
                            <span>{customer.name}{customer.phone ? ` (${customer.phone})` : ''}</span>
                          </span>

                          <h3 className="text-sm font-black text-slate-900 leading-tight hover:text-indigo-600 transition-colors">
                            {trx.itemName}
                          </h3>
                        </div>

                        <div className="flex items-center gap-2 text-[11px] text-slate-500 font-semibold mt-1 flex-wrap">
                          {trx.quantity && (
                            <span className="bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded text-[10px] font-bold">
                              {trx.quantity}
                            </span>
                          )}
                          <span>সময়: {trx.time}</span>
                          {trx.date && <span>• তারিখ: {trx.date}</span>}
                        </div>
                      </div>
                    </div>

                    <div className="text-right shrink-0 space-y-1">
                      {hasSell ? (
                        <div>
                          <span className="text-[10px] text-slate-400 font-bold block">বিক্রয় মূল্য</span>
                          <span className="text-sm sm:text-base font-black text-rose-600 font-mono tracking-tight leading-none">
                            +{formatTk(itemSell)}
                          </span>
                        </div>
                      ) : (
                        <div>
                          <span className="text-[10px] text-slate-400 font-bold block">হিসাব মূল্য</span>
                          <span className="text-sm sm:text-base font-black text-indigo-700 font-mono tracking-tight leading-none">
                            {formatTk(itemBuy || itemDeposit)}
                          </span>
                        </div>
                      )}

                      {itemProfit !== 0 && (
                        <div>
                          <span
                            className={`text-[10px] font-black px-1.5 py-0.5 rounded-md inline-flex items-center gap-0.5 ${
                              itemProfit >= 0
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : 'bg-rose-50 text-rose-700 border border-rose-200'
                            }`}
                          >
                            <TrendingUp className="w-2.5 h-2.5" />
                            <span>{itemProfit >= 0 ? `লাভ: +${formatTk(itemProfit)}` : `ক্ষতি: ${formatTk(itemProfit)}`}</span>
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Financial Breakdown Row */}
                  {(hasBuy || hasDeposit || hasDue || hasSurplus) && (
                    <div className="pt-2 border-t border-slate-100 flex items-center gap-1.5 text-center text-xs flex-wrap">
                      {hasBuy && (
                        <div className="flex-1 min-w-[70px] p-1.5 rounded-xl bg-indigo-50/70 border border-indigo-100">
                          <span className="text-[10px] text-indigo-700 block font-bold">কেনা</span>
                          <span className="font-black text-indigo-950 font-mono truncate block">
                            {formatTk(itemBuy)}
                          </span>
                        </div>
                      )}

                      {hasDeposit && (
                        <div className="flex-1 min-w-[70px] p-1.5 rounded-xl bg-emerald-50/70 border border-emerald-100">
                          <span className="text-[10px] text-emerald-700 block font-bold">জমা</span>
                          <span className="font-black text-emerald-700 font-mono truncate block">
                            {formatTk(itemDeposit)}
                          </span>
                        </div>
                      )}

                      {hasDue && (
                        <div className="flex-1 min-w-[80px] p-1.5 rounded-xl bg-amber-50/70 border border-amber-200">
                          <span className="text-[10px] text-amber-800 block font-bold">বাকি আছে</span>
                          <span className="font-black text-amber-600 font-mono truncate block">
                            {formatTk(itemDue)}
                          </span>
                        </div>
                      )}

                      {hasSurplus && (
                        <div className="flex-1 min-w-[80px] p-1.5 rounded-xl bg-emerald-50/90 border border-emerald-300">
                          <span className="text-[10px] text-emerald-800 block font-bold">জমা আছে</span>
                          <span className="font-black text-emerald-700 font-mono truncate block">
                            +{formatTk(itemSurplus)}
                          </span>
                        </div>
                      )}

                      {/* Quick Deposit button if due */}
                      {hasDue && (
                        <button
                          type="button"
                          onClick={() => handleOpenQuickDeposit(trx)}
                          className="px-2.5 py-1.5 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700 font-black transition-all cursor-pointer shadow-2xs flex items-center gap-1 text-[11px] shrink-0 active:scale-95"
                          title="টাকা জমা নিন এবং বাকি কমান"
                        >
                          <Coins className="w-3 h-3" />
                          <span>+ জমা নিন</span>
                        </button>
                      )}
                    </div>
                  )}

                  {/* Note & Action buttons */}
                  <div className="flex items-center justify-between pt-1 text-[11px] text-slate-500 gap-2">
                    <div className="truncate">
                      {trx.note && (
                        <span className="bg-slate-50 border border-slate-200/80 px-2 py-0.5 rounded-md font-medium text-slate-700">
                          নোট: {trx.note}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleOpenEditModal(trx)}
                        className="p-1.5 rounded-lg text-indigo-600 hover:bg-indigo-50 border border-transparent hover:border-indigo-200 transition-colors cursor-pointer"
                        title="সম্পাদনা করুন"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          if (window.confirm('আপনি কি এই হিসাবটি মুছে ফেলতে চান?')) {
                            onDeleteCustomerTransaction(customer.id, trx.id);
                          }
                        }}
                        className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 border border-transparent hover:border-rose-200 transition-colors cursor-pointer"
                        title="মুছে ফেলুন"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Quick Deposit Modal */}
      {quickDepositTrx && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fadeIn"
          style={{
            paddingTop: 'max(16px, calc(env(safe-area-inset-top, 0px) + 12px))',
            paddingBottom: 'max(16px, calc(env(safe-area-inset-bottom, 0px) + 16px))',
          }}
        >
          <div className="bg-white rounded-3xl max-w-[360px] w-full p-5 shadow-2xl border border-slate-100 space-y-3.5 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <Coins className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">টাকা জমা নিন</h3>
                  <p className="text-[11px] text-slate-500 font-bold truncate max-w-[180px]">
                    {quickDepositTrx.itemName}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setQuickDepositTrx(null)}
                className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-between">
              <span className="text-xs font-bold text-amber-800">বর্তমান বাকি:</span>
              <span className="text-base font-black text-amber-700 font-mono">
                {formatTk(quickDepositTrx.dueAmount || 0)}
              </span>
            </div>

            <form onSubmit={handleApplyQuickDeposit} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  জমা টাকার পরিমাণ (৳) *
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  required
                  autoFocus
                  value={quickDepositAmount}
                  onChange={(e) => setQuickDepositAmount(e.target.value.replace(/[^0-9.]/g, ''))}
                  placeholder={`যেমন: ${quickDepositTrx.dueAmount}`}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-black text-emerald-600 text-base outline-none focus:border-emerald-600 focus:bg-white text-center font-mono shadow-2xs"
                />
              </div>

              {/* One-click full pay button */}
              <button
                type="button"
                onClick={() => setQuickDepositAmount(String(quickDepositTrx.dueAmount || 0))}
                className="w-full py-2 bg-emerald-50 text-emerald-700 border border-emerald-200 font-black rounded-xl text-xs hover:bg-emerald-100 cursor-pointer active:scale-98 transition-all"
              >
                পুরো বাকি {formatTk(quickDepositTrx.dueAmount || 0)} একবারে পরিশোধ
              </button>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-md shadow-emerald-600/25 flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-98"
              >
                <Check className="w-4 h-4" />
                <span>জমা সংরক্ষণ করুন ও বাকি কমান</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Add / Edit Transaction Modal (দোকানের হিসাবের সাথে হুবহু অভিন্ন ডিজাইন ও লজিক) */}
      {isModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
          style={{
            paddingTop: 'max(16px, calc(env(safe-area-inset-top, 0px) + 12px))',
            paddingBottom: 'max(16px, calc(env(safe-area-inset-bottom, 0px) + 16px))',
          }}
        >
          <div className="bg-white rounded-3xl max-w-[430px] w-full p-4 sm:p-5 shadow-2xl border border-slate-100 animate-fadeIn space-y-3 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-black text-slate-900 text-base">
                {editingTrx ? 'কাস্টমার হিসাব সম্পাদন করুন' : 'কাস্টমারের নতুন হিসাব যোগ করুন'}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
              {/* ডাটা এন্ট্রি ঘরগুলো: ১) প্রোডাক্ট নাম ২) পরিমাণ ৩) কাস্টমার নাম/মোবাইল নাম্বার - প্রতিটির ভিতরে ড্রপডাউন বাটন */}
              <div className="space-y-2.5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {/* বক্স ১: প্রোডাক্ট নাম (ভিতরে ড্রপডাউন) */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[11px] font-black text-slate-800">
                        প্রোডাক্ট নাম *
                      </label>
                      <span className="text-[9px] text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded font-bold border border-emerald-200">
                        ভিতরে ড্রপডাউন
                      </span>
                    </div>
                    <div className="relative flex items-center bg-white border border-slate-300 rounded-xl focus-within:border-emerald-600 focus-within:ring-1 focus-within:ring-emerald-500 shadow-2xs overflow-hidden transition-all">
                      <input
                        type="text"
                        required
                        value={itemName}
                        onChange={(e) => setItemName(e.target.value)}
                        placeholder="প্রোডাক্টের নাম লিখুন..."
                        className="flex-1 px-3 py-2 text-xs font-bold text-slate-900 outline-none bg-transparent min-w-0"
                      />
                      {/* ইনপুটের ভিতরেই ড্রপডাউন বাটন */}
                      <div className="relative border-l border-slate-200 bg-slate-50 hover:bg-emerald-50 transition-colors shrink-0">
                        <select
                          value={savedProducts.includes(itemName) ? itemName : ''}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val) setItemName(val);
                          }}
                          className="text-[11px] font-bold text-slate-700 py-2 pl-2 pr-6 bg-transparent outline-none cursor-pointer appearance-none"
                          title="তালিকা থেকে প্রোডাক্ট বাছাই করুন"
                        >
                          <option value="">▼ বাছুন</option>
                          {savedProducts.map((p) => (
                            <option key={p} value={p}>
                              {p}
                            </option>
                          ))}
                        </select>
                        <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-1.5 top-2.5 pointer-events-none" />
                      </div>
                    </div>
                  </div>

                  {/* বক্স ২: পরিমাণ (ভিতরে ড্রপডাউন) */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[11px] font-black text-slate-800">
                        পরিমাণ
                      </label>
                      <span className="text-[9px] text-blue-700 bg-blue-50 px-1.5 py-0.2 rounded font-bold border border-blue-200">
                        ভিতরে ড্রপডাউন
                      </span>
                    </div>
                    <div className="relative flex items-center bg-white border border-slate-300 rounded-xl focus-within:border-blue-600 focus-within:ring-1 focus-within:ring-blue-500 shadow-2xs overflow-hidden transition-all">
                      <input
                        type="text"
                        value={quantity}
                        onChange={(e) => setQuantity(e.target.value)}
                        placeholder="যেমন: ১ কেজি, ২ পিস..."
                        className="flex-1 px-3 py-2 text-xs font-bold text-slate-900 outline-none bg-transparent min-w-0"
                      />
                      {/* ইনপুটের ভিতরেই ড্রপডাউন বাটন */}
                      <div className="relative border-l border-slate-200 bg-slate-50 hover:bg-blue-50 transition-colors shrink-0">
                        <select
                          value={savedQuantities.includes(quantity) ? quantity : ''}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val) setQuantity(val);
                          }}
                          className="text-[11px] font-bold text-slate-700 py-2 pl-2 pr-6 bg-transparent outline-none cursor-pointer appearance-none"
                          title="তালিকা থেকে পরিমাণ বাছাই করুন"
                        >
                          <option value="">▼ বাছুন</option>
                          {savedQuantities.map((q) => (
                            <option key={q} value={q}>
                              {q}
                            </option>
                          ))}
                        </select>
                        <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-1.5 top-2.5 pointer-events-none" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* বক্স ৩: কাস্টমার নাম / মোবাইল নাম্বার (ঘরের ডান পাশে Dropdown ▼ বাটন) */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[11px] font-black text-slate-800">
                      কাস্টমার নাম / মোবাইল নাম্বার
                    </label>
                    <span className="text-[9px] text-purple-700 bg-purple-50 px-1.5 py-0.2 rounded font-bold border border-purple-200">
                      ভিতরে ড্রপডাউন
                    </span>
                  </div>
                  <div className="relative flex items-center bg-white border border-slate-300 rounded-xl focus-within:border-purple-600 focus-within:ring-1 focus-within:ring-purple-500 shadow-2xs overflow-hidden transition-all">
                    <input
                      type="text"
                      value={customerInfo}
                      onChange={(e) => setCustomerInfo(e.target.value)}
                      placeholder="কাস্টমারের নাম বা মোবাইল নাম্বার লিখুন..."
                      className="flex-1 px-3 py-2 text-xs font-bold text-slate-900 outline-none bg-transparent min-w-0"
                    />
                    {/* ইনপুটের ভিতরেই ড্রপডাউন বাটন */}
                    <div className="relative border-l border-slate-200 bg-slate-50 hover:bg-purple-50 transition-colors shrink-0">
                      <select
                        value={allCustomerOptions.includes(customerInfo) ? customerInfo : ''}
                        onChange={(e) => {
                          const val = e.target.value;
                          if (val) setCustomerInfo(val);
                        }}
                        className="text-[11px] font-bold text-slate-700 py-2 pl-2 pr-6 bg-transparent outline-none cursor-pointer appearance-none max-w-[130px] truncate"
                        title="তালিকা থেকে কাস্টমার বা মোবাইল বাছাই করুন"
                      >
                        <option value="">▼ বাছুন</option>
                        {allCustomerOptions.map((c) => (
                          <option key={c} value={c}>
                            {c}
                          </option>
                        ))}
                      </select>
                      <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-1.5 top-2.5 pointer-events-none" />
                    </div>
                  </div>
                </div>
              </div>

              {/* ড্রপডাউন বাটন পরিচালনা: নতুন নাম যুক্ত করুন ও পুরনো অপশন মুছুন */}
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-1 flex-wrap">
                  <button
                    type="button"
                    onClick={() => setShowManageProducts(!showManageProducts)}
                    className="text-[11px] font-black text-indigo-700 hover:text-indigo-900 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 px-2.5 py-1 rounded-xl cursor-pointer flex items-center gap-1 transition-all active:scale-95 shadow-2xs"
                  >
                    <Settings2 className="w-3.5 h-3.5 text-indigo-600" />
                    <span>{showManageProducts ? '▲ ড্রপডাউন পরিচালনা বন্ধ করুন' : '⚙️ ড্রপডাউনে নাম যুক্ত / পুরনো অপশন মুছুন'}</span>
                  </button>

                  <div className="flex items-center gap-1">
                    {itemName.trim() && !savedProducts.includes(itemName.trim()) && (
                      <button
                        type="button"
                        onClick={() => handleAddProductToDropdown(itemName.trim())}
                        className="text-[10px] font-black text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-2 py-1 rounded-xl cursor-pointer flex items-center gap-1 transition-all active:scale-95"
                        title="বর্তমান প্রোডাক্টটি ড্রপডাউনে সেভ করুন"
                      >
                        <Plus className="w-3 h-3 text-emerald-600" />
                        <span>+ প্রোডাক্ট</span>
                      </button>
                    )}

                    {customerInfo.trim() && !allCustomerOptions.includes(customerInfo.trim()) && (
                      <button
                        type="button"
                        onClick={() => handleAddCustomerToDropdown(customerInfo.trim())}
                        className="text-[10px] font-black text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-200 px-2 py-1 rounded-xl cursor-pointer flex items-center gap-1 transition-all active:scale-95"
                        title="বর্তমান কাস্টমার ড্রপডাউনে সেভ করুন"
                      >
                        <Plus className="w-3 h-3 text-purple-600" />
                        <span>+ কাস্টমার</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* ড্রপডাউন পরিচালনা প্যানেল */}
                {showManageProducts && (
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5 animate-fadeIn">
                    <div className="flex items-center justify-between flex-wrap gap-1">
                      <span className="text-[11px] font-black text-slate-800">
                        ড্রপডাউন লিস্ট পরিচালনা
                      </span>
                      <div className="flex items-center gap-1 bg-white p-0.5 rounded-lg border border-slate-200 text-[10px]">
                        <button
                          type="button"
                          onClick={() => setDropdownManageTab('products')}
                          className={`px-2 py-0.5 rounded-md font-bold transition-colors cursor-pointer ${
                            dropdownManageTab === 'products'
                              ? 'bg-emerald-600 text-white shadow-2xs'
                              : 'text-slate-600 hover:bg-slate-100'
                          }`}
                        >
                          প্রোডাক্ট ({savedProducts.length})
                        </button>
                        <button
                          type="button"
                          onClick={() => setDropdownManageTab('quantities')}
                          className={`px-2 py-0.5 rounded-md font-bold transition-colors cursor-pointer ${
                            dropdownManageTab === 'quantities'
                              ? 'bg-blue-600 text-white shadow-2xs'
                              : 'text-slate-600 hover:bg-slate-100'
                          }`}
                        >
                          পরিমাণ ({savedQuantities.length})
                        </button>
                        <button
                          type="button"
                          onClick={() => setDropdownManageTab('customers')}
                          className={`px-2 py-0.5 rounded-md font-bold transition-colors cursor-pointer ${
                            dropdownManageTab === 'customers'
                              ? 'bg-purple-600 text-white shadow-2xs'
                              : 'text-slate-600 hover:bg-slate-100'
                          }`}
                        >
                          কাস্টমার ({allCustomerOptions.length})
                        </button>
                      </div>
                    </div>

                    {/* নতুন নাম ড্রপডাউনে যুক্ত করার ইনপুট */}
                    <div className="flex items-center gap-1.5">
                      <input
                        type="text"
                        value={
                          dropdownManageTab === 'products'
                            ? newCustomProductInput
                            : dropdownManageTab === 'quantities'
                            ? newCustomQuantityInput
                            : newCustomCustomerInput
                        }
                        onChange={(e) => {
                          if (dropdownManageTab === 'products') setNewCustomProductInput(e.target.value);
                          else if (dropdownManageTab === 'quantities') setNewCustomQuantityInput(e.target.value);
                          else setNewCustomCustomerInput(e.target.value);
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            if (dropdownManageTab === 'products') {
                              handleAddProductToDropdown();
                            } else if (dropdownManageTab === 'quantities') {
                              handleAddQuantityToDropdown();
                            } else {
                              handleAddCustomerToDropdown();
                            }
                          }
                        }}
                        placeholder={
                          dropdownManageTab === 'products'
                            ? 'ড্রপডাউনে যুক্ত করতে প্রোডাক্টের নাম লিখুন...'
                            : dropdownManageTab === 'quantities'
                            ? 'ড্রপডাউনে যুক্ত করতে পরিমাণ লিখুন (যেমন: ৫ কেজি)...'
                            : 'ড্রপডাউনে যুক্ত করতে কাস্টমার নাম বা মোবাইল লিখুন...'
                        }
                        className="flex-1 px-3 py-1.5 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900 outline-none focus:border-indigo-600 shadow-2xs"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (dropdownManageTab === 'products') {
                            handleAddProductToDropdown();
                          } else if (dropdownManageTab === 'quantities') {
                            handleAddQuantityToDropdown();
                          } else {
                            handleAddCustomerToDropdown();
                          }
                        }}
                        className={`px-3 py-1.5 text-white rounded-xl text-xs font-black shrink-0 flex items-center gap-1 cursor-pointer active:scale-95 shadow-2xs ${
                          dropdownManageTab === 'products'
                            ? 'bg-emerald-600 hover:bg-emerald-700'
                            : dropdownManageTab === 'quantities'
                            ? 'bg-blue-600 hover:bg-blue-700'
                            : 'bg-purple-600 hover:bg-purple-700'
                        }`}
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>যুক্ত করুন</span>
                      </button>
                    </div>

                    {/* পুরনো অপশনগুলো মুছে ফেলার তালিকা */}
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 block mb-1">
                        পুরনো অপশন ড্রপডাউন থেকে মুছতে নামের পাশের (×) বাটনে চাপ দিন:
                      </span>
                      <div className="flex items-center gap-1.5 flex-wrap max-h-36 overflow-y-auto p-1.5 bg-white border border-slate-200 rounded-xl">
                        {dropdownManageTab === 'products' ? (
                          savedProducts.map((p) => (
                            <span
                              key={p}
                              className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-100 text-slate-800 rounded-lg text-[11px] font-bold border border-slate-200"
                            >
                              <span
                                className="cursor-pointer hover:text-emerald-700"
                                onClick={() => setItemName(p)}
                                title="ইনপুটে বসাতে ক্লিক করুন"
                              >
                                {p}
                              </span>
                              <button
                                type="button"
                                onClick={() => handleDeleteProductFromDropdown(p)}
                                className="w-3.5 h-3.5 rounded-full hover:bg-rose-600 hover:text-white text-slate-400 flex items-center justify-center cursor-pointer transition-colors"
                                title={`"${p}" ড্রপডাউন থেকে মুছে ফেলুন`}
                              >
                                <X className="w-2.5 h-2.5" />
                              </button>
                            </span>
                          ))
                        ) : dropdownManageTab === 'quantities' ? (
                          savedQuantities.map((q) => (
                            <span
                              key={q}
                              className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-50 text-blue-900 rounded-lg text-[11px] font-bold border border-blue-200"
                            >
                              <span
                                className="cursor-pointer hover:text-blue-700"
                                onClick={() => setQuantity(q)}
                                title="ইনপুটে বসাতে ক্লিক করুন"
                              >
                                {q}
                              </span>
                              <button
                                type="button"
                                onClick={() => handleDeleteQuantityFromDropdown(q)}
                                className="w-3.5 h-3.5 rounded-full hover:bg-rose-600 hover:text-white text-blue-400 flex items-center justify-center cursor-pointer transition-colors"
                                title={`"${q}" ড্রপডাউন থেকে মুছে ফেলুন`}
                              >
                                <X className="w-2.5 h-2.5" />
                              </button>
                            </span>
                          ))
                        ) : (
                          allCustomerOptions.map((c) => (
                            <span
                              key={c}
                              className="inline-flex items-center gap-1 px-2 py-0.5 bg-purple-50 text-purple-900 rounded-lg text-[11px] font-bold border border-purple-200"
                            >
                              <span
                                className="cursor-pointer hover:text-purple-700"
                                onClick={() => setCustomerInfo(c)}
                                title="ইনপুটে বসাতে ক্লিক করুন"
                              >
                                {c}
                              </span>
                              <button
                                type="button"
                                onClick={() => handleDeleteCustomerFromDropdown(c)}
                                className="w-3.5 h-3.5 rounded-full hover:bg-rose-600 hover:text-white text-purple-400 flex items-center justify-center cursor-pointer transition-colors"
                                title={`"${c}" ড্রপডাউন থেকে মুছে ফেলুন`}
                              >
                                <X className="w-2.5 h-2.5" />
                              </button>
                            </span>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* ৩টি অপশনাল ইনপুট: কেনা, বিক্রি ও জমা (+ - সহকারে, কোনো খালি ঘর নেই) */}
              <div className="space-y-3">
                {/* ১. কেনা (ক্রয় খরচ) - অপশনাল */}
                <div className="p-3 bg-indigo-50/50 border border-indigo-200/70 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="font-black text-indigo-950 flex items-center gap-1.5 text-xs">
                      <span>🛒 কেনা মূল্য (ক্রয় খরচ)</span>
                    </label>
                    <span className="text-[10px] font-bold text-indigo-600 bg-indigo-100/70 px-2 py-0.5 rounded-md">
                      ঐচ্ছিক (অপশনাল)
                    </span>
                  </div>

                  {/* + - Stepper Input Box */}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleStepAmount(buyPrice, setBuyPrice, -10)}
                      className="w-10 h-10 rounded-xl bg-white border border-indigo-200 text-indigo-700 hover:bg-indigo-100/80 flex items-center justify-center font-black active:scale-95 transition-all cursor-pointer shadow-2xs shrink-0"
                      title="১০ টাকা কমান"
                    >
                      <Minus className="w-4 h-4 stroke-[3]" />
                    </button>

                    <div className="relative flex-1">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 font-black text-indigo-400 text-sm pointer-events-none">
                        ৳
                      </span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={buyPrice}
                        onFocus={(e) => e.target.select()}
                        onChange={(e) => handlePriceChange(setBuyPrice, e.target.value)}
                        onBlur={() => handlePriceBlur(buyPrice, setBuyPrice)}
                        placeholder="0"
                        className="w-full py-2 pl-7 pr-3 bg-white border border-indigo-200 rounded-xl font-black text-center text-indigo-950 text-base outline-none focus:border-indigo-600 focus:ring-2 focus:ring-indigo-600/20 transition-all font-mono"
                      />
                    </div>

                    <button
                      type="button"
                      onClick={() => handleStepAmount(buyPrice, setBuyPrice, 10)}
                      className="w-10 h-10 rounded-xl bg-indigo-600 border border-indigo-700 text-white hover:bg-indigo-700 flex items-center justify-center font-black active:scale-95 transition-all cursor-pointer shadow-xs shrink-0"
                      title="১০ টাকা বাড়ান"
                    >
                      <Plus className="w-4 h-4 stroke-[3]" />
                    </button>
                  </div>

                  {/* কুইক অ্যাডজাস্ট চিপস */}
                  <div className="flex items-center justify-between gap-1 pt-0.5">
                    <div className="flex items-center gap-1 flex-wrap">
                      <button
                        type="button"
                        onClick={() => handleStepAmount(buyPrice, setBuyPrice, -50)}
                        className="px-2 py-0.5 rounded-lg bg-white border border-indigo-200 text-indigo-700 text-[10px] font-bold hover:bg-indigo-50 cursor-pointer"
                      >
                        -৫০
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStepAmount(buyPrice, setBuyPrice, 50)}
                        className="px-2 py-0.5 rounded-lg bg-white border border-indigo-200 text-indigo-700 text-[10px] font-bold hover:bg-indigo-50 cursor-pointer"
                      >
                        +৫০
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStepAmount(buyPrice, setBuyPrice, 100)}
                        className="px-2 py-0.5 rounded-lg bg-white border border-indigo-200 text-indigo-700 text-[10px] font-bold hover:bg-indigo-50 cursor-pointer"
                      >
                        +১০০
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStepAmount(buyPrice, setBuyPrice, 500)}
                        className="px-2 py-0.5 rounded-lg bg-white border border-indigo-200 text-indigo-700 text-[10px] font-bold hover:bg-indigo-50 cursor-pointer"
                      >
                        +৫০০
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={() => setBuyPrice('0')}
                      className="text-[10px] font-bold text-slate-500 hover:text-slate-700 px-1.5 py-0.5 rounded cursor-pointer"
                    >
                      ০ (খালি)
                    </button>
                  </div>
                </div>

                {/* ২. বিক্রি (বিক্রয় মূল্য) - অপশনাল */}
                <div className="p-3 bg-rose-50/50 border border-rose-200/70 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="font-black text-rose-950 flex items-center gap-1.5 text-xs">
                      <span>🛍️ বিক্রি মূল্য (বিক্রয় মূল্য)</span>
                    </label>
                    <span className="text-[10px] font-bold text-rose-600 bg-rose-100/70 px-2 py-0.5 rounded-md">
                      ঐচ্ছিক (অপশনাল)
                    </span>
                  </div>

                  {/* + - Stepper Input Box */}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleStepAmount(sellPrice, setSellPrice, -10)}
                      className="w-10 h-10 rounded-xl bg-white border border-rose-200 text-rose-700 hover:bg-rose-100/80 flex items-center justify-center font-black active:scale-95 transition-all cursor-pointer shadow-2xs shrink-0"
                      title="১০ টাকা কমান"
                    >
                      <Minus className="w-4 h-4 stroke-[3]" />
                    </button>

                    <div className="relative flex-1">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 font-black text-rose-400 text-sm pointer-events-none">
                        ৳
                      </span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={sellPrice}
                        onFocus={(e) => e.target.select()}
                        onChange={(e) => handlePriceChange(setSellPrice, e.target.value)}
                        onBlur={() => handlePriceBlur(sellPrice, setSellPrice)}
                        placeholder="0"
                        className="w-full py-2 pl-7 pr-3 bg-white border border-rose-200 rounded-xl font-black text-center text-rose-950 text-base outline-none focus:border-rose-600 focus:ring-2 focus:ring-rose-600/20 transition-all font-mono"
                      />
                    </div>

                    <button
                      type="button"
                      onClick={() => handleStepAmount(sellPrice, setSellPrice, 10)}
                      className="w-10 h-10 rounded-xl bg-rose-600 border border-rose-700 text-white hover:bg-rose-700 flex items-center justify-center font-black active:scale-95 transition-all cursor-pointer shadow-xs shrink-0"
                      title="১০ টাকা বাড়ান"
                    >
                      <Plus className="w-4 h-4 stroke-[3]" />
                    </button>
                  </div>

                  {/* কুইক অ্যাডজাস্ট চিপস */}
                  <div className="flex items-center justify-between gap-1 pt-0.5">
                    <div className="flex items-center gap-1 flex-wrap">
                      <button
                        type="button"
                        onClick={() => handleStepAmount(sellPrice, setSellPrice, -50)}
                        className="px-2 py-0.5 rounded-lg bg-white border border-rose-200 text-rose-700 text-[10px] font-bold hover:bg-rose-50 cursor-pointer"
                      >
                        -৫০
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStepAmount(sellPrice, setSellPrice, 50)}
                        className="px-2 py-0.5 rounded-lg bg-white border border-rose-200 text-rose-700 text-[10px] font-bold hover:bg-rose-50 cursor-pointer"
                      >
                        +৫০
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStepAmount(sellPrice, setSellPrice, 100)}
                        className="px-2 py-0.5 rounded-lg bg-white border border-rose-200 text-rose-700 text-[10px] font-bold hover:bg-rose-50 cursor-pointer"
                      >
                        +১০০
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStepAmount(sellPrice, setSellPrice, 500)}
                        className="px-2 py-0.5 rounded-lg bg-white border border-rose-200 text-rose-700 text-[10px] font-bold hover:bg-rose-50 cursor-pointer"
                      >
                        +৫০০
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={() => setSellPrice('0')}
                      className="text-[10px] font-bold text-slate-500 hover:text-slate-700 px-1.5 py-0.5 rounded cursor-pointer"
                    >
                      ০ (খালি)
                    </button>
                  </div>
                </div>

                {/* ৩. জমা (কাস্টমার পরিশোধ) - অপশনাল */}
                <div className="p-3 bg-emerald-50/50 border border-emerald-200/70 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="font-black text-emerald-950 flex items-center gap-1.5 text-xs">
                      <span>💵 জমা টাকা (কাস্টমার পরিশোধ)</span>
                    </label>
                    {isSurplusDeposit ? (
                      <span className="text-[10px] font-black text-emerald-700 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded-md flex items-center gap-1 animate-fadeIn">
                        <Coins className="w-2.5 h-2.5 text-emerald-600" />
                        <span>জমা আছে: +{formatTk(calculatedSurplus)}</span>
                      </span>
                    ) : isNoDeposit ? (
                      <span className="text-[10px] font-black text-amber-800 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-md flex items-center gap-1 animate-fadeIn">
                        <AlertCircle className="w-2.5 h-2.5 text-amber-600" />
                        <span>জমা নেই (বাকি: {formatTk(calculatedDue)})</span>
                      </span>
                    ) : calculatedDue > 0 ? (
                      <span className="text-[10px] font-black text-amber-800 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-md flex items-center gap-1 animate-fadeIn">
                        <AlertCircle className="w-2.5 h-2.5 text-amber-600" />
                        <span>বাকি আছে: {formatTk(calculatedDue)}</span>
                      </span>
                    ) : isFullyPaid ? (
                      <span className="text-[10px] font-black text-emerald-700 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded-md flex items-center gap-1 animate-fadeIn">
                        <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600" />
                        <span>✓ সম্পূর্ণ পরিশোধ</span>
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold text-emerald-600 bg-emerald-100/70 px-2 py-0.5 rounded-md">
                        ঐচ্ছিক (অপশনাল)
                      </span>
                    )}
                  </div>

                  {/* + - Stepper Input Box */}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleStepAmount(depositAmount, setDepositAmount, -10)}
                      className="w-10 h-10 rounded-xl bg-white border border-emerald-200 text-emerald-700 hover:bg-emerald-100/80 flex items-center justify-center font-black active:scale-95 transition-all cursor-pointer shadow-2xs shrink-0"
                      title="১০ টাকা কমান"
                    >
                      <Minus className="w-4 h-4 stroke-[3]" />
                    </button>

                    <div className="relative flex-1">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 font-black text-emerald-400 text-sm pointer-events-none">
                        ৳
                      </span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={depositAmount}
                        onFocus={(e) => e.target.select()}
                        onChange={(e) => handlePriceChange(setDepositAmount, e.target.value)}
                        onBlur={() => handlePriceBlur(depositAmount, setDepositAmount)}
                        placeholder="0"
                        className="w-full py-2 pl-7 pr-3 bg-white border border-emerald-200 rounded-xl font-black text-center text-emerald-950 text-base outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600/20 transition-all font-mono"
                      />
                    </div>

                    <button
                      type="button"
                      onClick={() => handleStepAmount(depositAmount, setDepositAmount, 10)}
                      className="w-10 h-10 rounded-xl bg-emerald-600 border border-emerald-700 text-white hover:bg-emerald-700 flex items-center justify-center font-black active:scale-95 transition-all cursor-pointer shadow-xs shrink-0"
                      title="১০ টাকা বাড়ান"
                    >
                      <Plus className="w-4 h-4 stroke-[3]" />
                    </button>
                  </div>

                  {/* কুইক অ্যাকশন বাটন: পুরো বাকি ও সম্পূর্ণ পরিশোধ */}
                  <div className="flex items-center justify-between gap-1 pt-0.5">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <button
                        type="button"
                        onClick={handleSetFullDue}
                        className="px-2.5 py-1 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-[10px] font-black hover:bg-amber-100 cursor-pointer transition-colors"
                        title="জমা ০ করে পুরো টাকা বাকি রাখুন"
                      >
                        পুরো বাকি (জমা ৳০)
                      </button>
                      <button
                        type="button"
                        onClick={handleSetFullPaid}
                        className="px-2.5 py-1 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-[10px] font-black hover:bg-emerald-100 cursor-pointer transition-colors"
                        title="বিক্রির পুরো টাকা জমায় বসিয়ে পেইড করুন"
                      >
                        ✓ সম্পূর্ণ পরিশোধ (পেইড)
                      </button>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleStepAmount(depositAmount, setDepositAmount, 50)}
                        className="px-2 py-0.5 rounded-lg bg-white border border-emerald-200 text-emerald-700 text-[10px] font-bold hover:bg-emerald-50 cursor-pointer"
                      >
                        +৫০
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStepAmount(depositAmount, setDepositAmount, 100)}
                        className="px-2 py-0.5 rounded-lg bg-white border border-emerald-200 text-emerald-700 text-[10px] font-bold hover:bg-emerald-50 cursor-pointer"
                      >
                        +১০০
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* লাভ হিসাব */}
              <div className="p-3 bg-purple-50/50 border border-purple-200/70 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-black text-purple-950 flex items-center gap-1 text-xs">
                    <TrendingUp className="w-3.5 h-3.5 text-purple-600" />
                    <span>লাভ / প্রফিট</span>
                  </label>
                  <span className="text-[10px] text-purple-700 font-bold bg-purple-100/70 px-2 py-0.5 rounded-md">
                    {numBuy > 0 && numSell > 0
                      ? `অটো হিসাব: +${formatTk(autoProfit)}`
                      : 'ম্যানুয়াল / কাস্টম'}
                  </span>
                </div>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 font-black text-purple-400 text-sm pointer-events-none">
                    ৳
                  </span>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={profitInput !== '' ? profitInput : autoProfit !== 0 ? String(autoProfit) : ''}
                    onChange={(e) => setProfitInput(e.target.value.replace(/[^0-9.-]/g, ''))}
                    placeholder={autoProfit !== 0 ? String(autoProfit) : 'লাভের পরিমাণ লিখুন (ঐচ্ছিক)'}
                    className="w-full py-2 pl-7 pr-3 bg-white border border-purple-200 rounded-xl font-black text-purple-950 text-sm outline-none focus:border-purple-600 focus:ring-2 focus:ring-purple-600/20 font-mono"
                  />
                </div>
              </div>

              {/* নোট বা মন্তব্য */}
              <div>
                <label className="text-[11px] font-black text-slate-700 block mb-1">
                  নোট বা মন্তব্য (ঐচ্ছিক)
                </label>
                <input
                  type="text"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="যেমন: কাল বাকি পরিশোধ করবে / ড্রাইভ প্যাক"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 outline-none focus:border-indigo-600 shadow-2xs"
                />
              </div>

              {!editingTrx && (
                <label className="flex items-center gap-2 p-2.5 bg-emerald-50/70 border border-emerald-200 rounded-xl cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={sendReceiptOnSubmit}
                    onChange={(e) => setSendReceiptOnSubmit(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded-md focus:ring-0 cursor-pointer"
                  />
                  <span className="text-[11px] font-bold text-emerald-950 flex items-center gap-1">
                    <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                    <span>লেনদেন সম্পন্ন হলে WhatsApp এ রসিদ পাঠান</span>
                  </span>
                </label>
              )}

              <button
                type="submit"
                className="w-full py-3.5 bg-[#4323d4] hover:bg-[#371cb8] text-white font-black text-xs sm:text-sm rounded-xl shadow-lg shadow-indigo-600/25 flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-98"
              >
                <Check className="w-4 h-4" />
                <span>{editingTrx ? 'হিসাব আপডেট করুন' : 'হিসাব সংরক্ষণ করুন'}</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
