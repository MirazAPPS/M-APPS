import React, { useState, useMemo } from 'react';
import {
  Calendar,
  Search,
  Share2,
  Store,
  User,
  Users,
  ClipboardList,
  Banknote,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  Printer,
  Download,
  CheckCircle2,
  MessageCircle,
  FileText,
  ArrowLeft,
  ChevronRight,
  TrendingUp,
  Wallet,
  Coins,
  Scale,
  Phone,
  SlidersHorizontal,
  Clock,
  Sparkles,
  ArrowUpDown,
  Eye,
  ChevronDown,
  Settings2,
  Cloud,
  FileSpreadsheet,
  ExternalLink,
} from 'lucide-react';
import { CustomerAccount, CustomerTransaction, ShopTransaction, UserProfile } from '../types';

export interface TallyHubViewProps {
  user?: UserProfile;
  shopTransactions: ShopTransaction[];
  customers?: CustomerAccount[];
  onOpenShopLedger?: () => void;
  onOpenCustomerLedger?: () => void;
  onOpenCombinedSummary?: () => void;
  onAddTransaction?: (trx: ShopTransaction) => void;
  onUpdateTransaction?: (trx: ShopTransaction) => void;
  onDeleteTransaction?: (id: string) => void;
  onAddCustomer?: (customer: CustomerAccount) => void;
  onUpdateCustomer?: (customer: CustomerAccount) => void;
  onDeleteCustomer?: (id: string) => void;
  onAddCustomerTransaction?: (customerId: string, trx: CustomerTransaction) => void;
  onUpdateCustomerTransaction?: (customerId: string, trx: CustomerTransaction) => void;
  onDeleteCustomerTransaction?: (customerId: string, trxId: string) => void;
  onOpenProfileEdit?: () => void;
  onRefreshData?: () => void;
  onBack?: () => void;
}

// Convert English digits to Bengali digits
const toBengaliDigits = (num: number | string): string => {
  return String(num).replace(/\d/g, (d) => '০১২৩৪৫৬৭৮৯'[parseInt(d, 10)]);
};

// Convert Bengali digits to English string
const normalizeDigits = (val: unknown): string => {
  if (val == null) return '';
  const str = String(val).trim();
  const bn = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return str.replace(/[০-৯]/g, (d) => String(bn.indexOf(d)));
};

// Parse number safely from either Bengali or English input
const parseBengaliOrEnglishNumber = (val: unknown): number => {
  if (val == null || val === '') return 0;
  if (typeof val === 'number') return isNaN(val) ? 0 : val;
  const normalized = normalizeDigits(val);
  const match = normalized.match(/-?\d+(\.\d+)?/);
  return match ? parseFloat(match[0]) : 0;
};

// Format currency
const formatTaka = (amount: number): string => {
  return toBengaliDigits(Math.round(amount).toLocaleString('en-IN'));
};

// Format date as ১৬/৯/২০২৬
const formatBengaliDate = (dateStr: string): string => {
  if (!dateStr) return '';
  const normalized = normalizeDigits(dateStr);
  const parts = normalized.split(/[-/]/);
  if (parts.length === 3) {
    let d = parseInt(parts[0], 10);
    let m = parseInt(parts[1], 10);
    let y = parseInt(parts[2], 10);
    if (d > 1000) {
      // YYYY-MM-DD
      y = parseInt(parts[0], 10);
      m = parseInt(parts[1], 10);
      d = parseInt(parts[2], 10);
    }
    return `${toBengaliDigits(d)}/${toBengaliDigits(m)}/${toBengaliDigits(y)}`;
  }
  return toBengaliDigits(dateStr);
};

// Calculate Bengali day of week from date string
const getBengaliDayOfWeek = (dateStr: string, timestamp?: number): string => {
  const days = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'];
  if (timestamp) {
    const dt = new Date(timestamp);
    if (!isNaN(dt.getTime())) return days[dt.getDay()];
  }
  if (dateStr) {
    const normalized = normalizeDigits(dateStr);
    const parts = normalized.split(/[-/]/);
    if (parts.length === 3) {
      let d = parseInt(parts[0], 10);
      let m = parseInt(parts[1], 10);
      let y = parseInt(parts[2], 10);
      if (d > 1000) {
        y = parseInt(parts[0], 10);
        m = parseInt(parts[1], 10);
        d = parseInt(parts[2], 10);
      }
      const dt = new Date(y, m - 1, d);
      if (!isNaN(dt.getTime())) return days[dt.getDay()];
    }
  }
  return days[new Date().getDay()];
};

// Get today's date in DD-MM-YYYY format
const getTodayDateFormatted = (): string => {
  const now = new Date();
  const d = String(now.getDate()).padStart(2, '0');
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const y = now.getFullYear();
  return `${d}-${m}-${y}`;
};

export const TallyHubView: React.FC<TallyHubViewProps> = ({
  user,
  shopTransactions = [],
  customers = [],
  onAddTransaction,
  onUpdateTransaction,
  onDeleteTransaction,
  onAddCustomer,
  onUpdateCustomer,
  onDeleteCustomer,
  onAddCustomerTransaction,
  onUpdateCustomerTransaction,
  onDeleteCustomerTransaction,
  onRefreshData,
  onOpenCombinedSummary,
  onBack,
}) => {
  // 3 Unified Accounts: 'shop' (দোকানের হিসাব), 'customer' (কাস্টমার হিসাব), 'personal' (ব্যক্তিগত হিসাব)
  const [activeCategory, setActiveCategory] = useState<'shop' | 'customer' | 'personal'>('shop');

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'this_month'>('all');
  const [customerViewMode, setCustomerViewMode] = useState<'transactions' | 'customers'>('transactions');

  // Toast Notification state
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Add / Edit Modal state for Shop and Personal transactions
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingTrx, setEditingTrx] = useState<ShopTransaction | null>(null);
  const [viewingTrx, setViewingTrx] = useState<ShopTransaction | null>(null);

  // Add Customer Modal state
  const [isAddCustomerModalOpen, setIsAddCustomerModalOpen] = useState(false);
  const [newCustomerName, setNewCustomerName] = useState('');
  const [newCustomerPhone, setNewCustomerPhone] = useState('');
  const [newCustomerDue, setNewCustomerDue] = useState('');

  // Customer Edit Modal state
  const [editingCustomer, setEditingCustomer] = useState<CustomerAccount | null>(null);
  const [isEditCustomerModalOpen, setIsEditCustomerModalOpen] = useState(false);
  const [editCustName, setEditCustName] = useState('');
  const [editCustPhone, setEditCustPhone] = useState('');

  // Customer Transaction modal state (when clicking a customer row)
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerAccount | null>(null);
  
  // Active selected customer synced with latest customers list
  const currentSelectedCustomer = useMemo(() => {
    if (!selectedCustomer) return null;
    return (customers || []).find((c) => String(c.id).trim() === String(selectedCustomer.id).trim()) || selectedCustomer;
  }, [customers, selectedCustomer]);

  // Pre-saved product list for Shop Account
  const DEFAULT_PRESET_PRODUCTS = [
    'চাল (নাজিরশাইল/মিনিকেট)',
    'সয়াবিন তেল (১ লিটার)',
    'সয়াবিন তেল (৫ লিটার)',
    'সরিষার তেল',
    'চিনি',
    'মসুর ডাল',
    'মুগ ডাল',
    'ছোলা বুট',
    'লবণ',
    'আটা / ময়দা',
    'ডিম (১ হালি)',
    'পেঁয়াজ',
    'রসুন ও আদা',
    'আলু',
    'চা পাতা',
    'গুঁড়ো দুধ',
    'সাবান / গুঁড়ো সাবান',
    'হুইল পাউডার',
    'বিস্কুট / টোস্ট',
    'নুডলস',
    'মসলাপাতি',
    'মোবাইল রিচার্জ',
    'ড্রাইভ অফার প্যাক',
  ];

  // Preset quantities for shop transactions (পরিমাণ ড্রপডাউন)
  const DEFAULT_PRESET_QUANTITIES = [
    '১ কেজি',
    '২ কেজি',
    '৫ কেজি',
    '১/২ কেজি (৫০০ গ্রাম)',
    '২৫০ গ্রাম',
    '১০০ গ্রাম',
    '১ লিটার',
    '২ লিটার',
    '৫ লিটার',
    '১ পিস / টি',
    '২ পিস',
    '৪ পিস (১ হালি)',
    '১ ডজন (১২ টি)',
    '১ প্যাকেট',
    '১ বস্তা',
    '১ কার্টুন',
    '১ খাঁচি',
    '১ বান্ডিল',
  ];

  // Preset customers for dropdown (কাস্টমার নাম / মোবাইল নাম্বার)
  const DEFAULT_PRESET_CUSTOMERS = [
    'ক্যাশ খদ্দের / নগদ কাস্টমার',
    'রহিম মিয়া (০১৭xxxxxxxx)',
    'করিম উদ্দিন (০১৮xxxxxxxx)',
    'মো: রফিকুল ইসলাম',
    'আলমগীর হোসেন',
    'বাবু মিয়া',
    'সেলিম রেজা',
  ];

  const [savedProducts, setSavedProducts] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('tally_saved_products');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.filter((p: string) => p !== 'মুদি মালামাল' && p !== 'মদি মালামাল');
        }
      }
    } catch (e) {}
    return DEFAULT_PRESET_PRODUCTS;
  });

  const [savedQuantities, setSavedQuantities] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('tally_saved_quantities');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return DEFAULT_PRESET_QUANTITIES;
  });

  const [savedCustomerOptions, setSavedCustomerOptions] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('tally_saved_customers');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return DEFAULT_PRESET_CUSTOMERS;
  });

  // Combine saved customers with customers prop
  const allCustomerOptions = useMemo(() => {
    const list = [...savedCustomerOptions];
    (customers || []).forEach((c) => {
      const label = c.name + (c.phone ? ` (${c.phone})` : '');
      if (!list.includes(label) && !list.includes(c.name)) {
        list.push(label);
      }
    });
    return list;
  }, [savedCustomerOptions, customers]);

  // Preset personal expenses for personal account dropdown (ব্যক্তিগত হিসাবের খরচের নাম ড্রপডাউন)
  const DEFAULT_PRESET_PERSONAL_EXPENSES = [
    'বাজার খরচ',
    'কাঁচা বাজার / শাকসবজি',
    'মাছ / মাংস',
    'চাল / ডাল / তেল',
    'বাড়ি ভাড়া',
    'বিদ্যুৎ বিল',
    'গ্যাস বিল',
    'পানির বিল',
    'ওয়াইফাই / ইন্টারনেট বিল',
    'মোবাইল রিচার্জ',
    'যাতায়াত / গাড়ি ভাড়া',
    'ওষুধ / চিকিৎসা খরচ',
    'বাচ্চার পড়াশোনা / স্কুল ফি',
    'নাস্তা / চা-বিস্কুট',
    'জামাকাপড় / কেনাকাটা',
    'পারিবারিক খরচ',
    'দান / সদকা / মসজিদ',
    'ব্যক্তিগত ঋণ পরিশোধ',
    'অন্যান্য খরচ',
  ];

  const [savedPersonalExpenses, setSavedPersonalExpenses] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('tally_saved_personal_expenses');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return DEFAULT_PRESET_PERSONAL_EXPENSES;
  });

  const allPersonalExpenseOptions = useMemo(() => {
    const set = new Set<string>();
    savedPersonalExpenses.forEach((item) => set.add(item));
    savedProducts.forEach((item) => set.add(item));
    return Array.from(set);
  }, [savedPersonalExpenses, savedProducts]);

  const [showManagePersonalExpenses, setShowManagePersonalExpenses] = useState(false);
  const [quickNewExpenseModal, setQuickNewExpenseModal] = useState(false);
  const [quickNewExpenseInput, setQuickNewExpenseInput] = useState('');
  const [quickNewQuantityModal, setQuickNewQuantityModal] = useState(false);
  const [quickNewQuantityInput, setQuickNewQuantityInput] = useState('');

  const handleAddPersonalExpenseToDropdown = (nameToAdd?: string) => {
    const target = (nameToAdd || quickNewExpenseInput || formData.itemName || '').trim();
    if (!target) {
      showToast('দয়া করে খরচের নাম লিখুন');
      return;
    }
    if (savedPersonalExpenses.includes(target)) {
      showToast('এই নামটি ড্রপডাউন তালিকায় ইতিমধ্যে আছে');
      setFormData((prev) => ({ ...prev, itemName: target }));
      setQuickNewExpenseModal(false);
      setQuickNewExpenseInput('');
      return;
    }
    const updated = [target, ...savedPersonalExpenses];
    setSavedPersonalExpenses(updated);
    try {
      localStorage.setItem('tally_saved_personal_expenses', JSON.stringify(updated));
    } catch (e) {}
    showToast(`✓ ড্রপডাউনে "${target}" সফলভাবে বসানো ও যুক্ত হয়েছে`);
    setQuickNewExpenseInput('');
    setFormData((prev) => ({ ...prev, itemName: target }));
    setQuickNewExpenseModal(false);
  };

  const handleDeletePersonalExpenseFromDropdown = (nameToDelete: string) => {
    const updated = savedPersonalExpenses.filter((p) => p !== nameToDelete);
    setSavedPersonalExpenses(updated);
    try {
      localStorage.setItem('tally_saved_personal_expenses', JSON.stringify(updated));
    } catch (e) {}
    showToast(`ড্রপডাউন থেকে "${nameToDelete}" মুছে ফেলা হয়েছে`);
  };

  const handleAddCustomQuantityToDropdown = (qtyToAdd?: string) => {
    const target = (qtyToAdd || quickNewQuantityInput || formData.quantity || '').trim();
    if (!target) {
      showToast('দয়া করে পরিমাণ লিখুন');
      return;
    }
    if (savedQuantities.includes(target)) {
      showToast('এই পরিমাণ ড্রপডাউন তালিকায় ইতিমধ্যে আছে');
      setFormData((prev) => ({ ...prev, quantity: target }));
      setQuickNewQuantityModal(false);
      setQuickNewQuantityInput('');
      return;
    }
    const updated = [target, ...savedQuantities];
    setSavedQuantities(updated);
    try {
      localStorage.setItem('tally_saved_quantities', JSON.stringify(updated));
    } catch (e) {}
    showToast(`✓ ড্রপডাউনে "${target}" সফলভাবে বসানো ও যুক্ত হয়েছে`);
    setQuickNewQuantityInput('');
    setFormData((prev) => ({ ...prev, quantity: target }));
    setQuickNewQuantityModal(false);
  };

  const [dropdownManageTab, setDropdownManageTab] = useState<'products' | 'quantities' | 'customers'>('products');
  const [newCustomProductInput, setNewCustomProductInput] = useState('');
  const [newCustomQuantityInput, setNewCustomQuantityInput] = useState('');
  const [newCustomCustomerInput, setNewCustomCustomerInput] = useState('');
  const [showManageProducts, setShowManageProducts] = useState(false);

  const handleAddProductToDropdown = (nameToAdd?: string) => {
    const target = (nameToAdd || newCustomProductInput || formData.itemName || '').trim();
    if (!target) {
      showToast('দয়া করে পণ্যের নাম লিখুন');
      return;
    }
    if (savedProducts.includes(target)) {
      showToast('এই নামটি ড্রপডাউন তালিকায় ইতিমধ্যে আছে');
      return;
    }
    const updated = [target, ...savedProducts];
    setSavedProducts(updated);
    try {
      localStorage.setItem('tally_saved_products', JSON.stringify(updated));
    } catch (e) {}
    showToast(`✓ ড্রপডাউনে "${target}" সফলভাবে যুক্ত হয়েছে`);
    setNewCustomProductInput('');
    if (!formData.itemName) {
      setFormData((prev) => ({ ...prev, itemName: target }));
    }
  };

  const handleDeleteProductFromDropdown = (nameToDelete: string) => {
    const updated = savedProducts.filter((p) => p !== nameToDelete);
    setSavedProducts(updated);
    try {
      localStorage.setItem('tally_saved_products', JSON.stringify(updated));
    } catch (e) {}
    showToast(`ড্রপডাউন থেকে "${nameToDelete}" মুছে ফেলা হয়েছে`);
  };

  const handleAddQuantityToDropdown = (qtyToAdd?: string) => {
    const target = (qtyToAdd || newCustomQuantityInput || newCustomProductInput || formData.quantity || '').trim();
    if (!target) {
      showToast('দয়া করে পরিমাণ লিখুন');
      return;
    }
    if (savedQuantities.includes(target)) {
      showToast('এই পরিমাণ ড্রপডাউন তালিকায় ইতিমধ্যে আছে');
      return;
    }
    const updated = [target, ...savedQuantities];
    setSavedQuantities(updated);
    try {
      localStorage.setItem('tally_saved_quantities', JSON.stringify(updated));
    } catch (e) {}
    showToast(`✓ ড্রপডাউনে "${target}" সফলভাবে যুক্ত হয়েছে`);
    setNewCustomQuantityInput('');
    setNewCustomProductInput('');
    if (!formData.quantity) {
      setFormData((prev) => ({ ...prev, quantity: target }));
    }
  };

  const handleDeleteQuantityFromDropdown = (qtyToDelete: string) => {
    const updated = savedQuantities.filter((q) => q !== qtyToDelete);
    setSavedQuantities(updated);
    try {
      localStorage.setItem('tally_saved_quantities', JSON.stringify(updated));
    } catch (e) {}
    showToast(`ড্রপডাউন থেকে "${qtyToDelete}" মুছে ফেলা হয়েছে`);
  };

  const handleAddCustomerToDropdown = (custToAdd?: string) => {
    const target = (custToAdd || newCustomCustomerInput || formData.customerInfo || '').trim();
    if (!target) {
      showToast('দয়া করে কাস্টমারের নাম বা মোবাইল লিখুন');
      return;
    }
    if (savedCustomerOptions.includes(target)) {
      showToast('এই কাস্টমারটি ড্রপডাউনে ইতিমধ্যে আছে');
      return;
    }
    const updated = [target, ...savedCustomerOptions];
    setSavedCustomerOptions(updated);
    try {
      localStorage.setItem('tally_saved_customers', JSON.stringify(updated));
    } catch (e) {}
    showToast(`✓ ড্রপডাউনে "${target}" সফলভাবে যুক্ত হয়েছে`);
    setNewCustomCustomerInput('');
    if (!formData.customerInfo) {
      setFormData((prev) => ({ ...prev, customerInfo: target }));
    }
  };

  const handleDeleteCustomerFromDropdown = (custToDelete: string) => {
    const updated = savedCustomerOptions.filter((c) => c !== custToDelete);
    setSavedCustomerOptions(updated);
    try {
      localStorage.setItem('tally_saved_customers', JSON.stringify(updated));
    } catch (e) {}
    showToast(`ড্রপডাউন থেকে "${custToDelete}" মুছে ফেলা হয়েছে`);
  };

  const handleSaveCustomProduct = () => {
    const name = formData.itemName.trim();
    if (!name) return;
    handleAddProductToDropdown(name);
  };

  // Pre-saved category list for Shop Account
  const DEFAULT_PRESET_CATEGORIES = [
    'চাল, ডাল ও তেল',
    'মসলা ও রান্নার সামগ্রী',
    'স্ন্যাক্স, বেকারি ও মিষ্টি',
    'সাবান, গুঁড়ো ও প্রসাধন',
    'পানীয় ও আইসক্রিম',
    'মোবাইল রিচার্জ ও সিম প্যাক',
    'সাধারণ মালামাল',
  ];

  const [savedCategories, setSavedCategories] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('tally_saved_categories');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const clean = parsed.filter((c: string) => c !== 'মুদি মালামাল' && c !== 'মদি মালামাল');
          if (clean.length > 0) return clean;
        }
      }
    } catch (e) {}
    return DEFAULT_PRESET_CATEGORIES;
  });

  const [customCategoryInput, setCustomCategoryInput] = useState('');
  const [showCustomCategoryInput, setShowCustomCategoryInput] = useState(false);

  const handleSaveCustomCategory = (nameToSave?: string) => {
    const cat = (nameToSave || customCategoryInput || formData.category).trim();
    if (!cat) return;
    if (!savedCategories.includes(cat)) {
      const updated = [cat, ...savedCategories];
      setSavedCategories(updated);
      try {
        localStorage.setItem('tally_saved_categories', JSON.stringify(updated));
      } catch (e) {}
    }
    setFormData((prev) => ({ ...prev, category: cat }));
    setCustomCategoryInput('');
    setShowCustomCategoryInput(false);
    showToast(`✓ "${cat}" ক্যাটাগরি সংরক্ষণ করা হয়েছে`);
  };

  // Success Confirmation Popup state ("অ্যান্টি সফল হবে ওকে বাটন ক্লিক করব")
  const [successEntryModal, setSuccessEntryModal] = useState<{
    isOpen: boolean;
    trx: ShopTransaction | null;
    isEdit?: boolean;
  }>({
    isOpen: false,
    trx: null,
    isEdit: false,
  });

  const [isCustomerDetailModalOpen, setIsCustomerDetailModalOpen] = useState(false);
  const [isAddCustTxModalOpen, setIsAddCustTxModalOpen] = useState(false);
  const [custTxItem, setCustTxItem] = useState('');
  const [custTxQuantity, setCustTxQuantity] = useState('');
  const [custTxCustomerInfo, setCustTxCustomerInfo] = useState('');
  const [custTxBuy, setCustTxBuy] = useState('');
  const [custTxSell, setCustTxSell] = useState('');
  const [custTxDeposit, setCustTxDeposit] = useState('');
  const [custTxDue, setCustTxDue] = useState('');

  // Customer Transaction Edit Modal state
  const [editingCustTx, setEditingCustTx] = useState<CustomerTransaction | null>(null);
  const [isEditCustTxModalOpen, setIsEditCustTxModalOpen] = useState(false);
  const [editCustTxItem, setEditCustTxItem] = useState('');
  const [editCustTxQuantity, setEditCustTxQuantity] = useState('');
  const [editCustTxBuy, setEditCustTxBuy] = useState('');
  const [editCustTxSell, setEditCustTxSell] = useState('');
  const [editCustTxDeposit, setEditCustTxDeposit] = useState('');
  const [editCustTxDue, setEditCustTxDue] = useState('');

  // Delete Confirmation Modal
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [deleteConfirmType, setDeleteConfirmType] = useState<'shop_trx' | 'customer' | 'cust_tx'>('shop_trx');
  const [deleteCustTxParentId, setDeleteCustTxParentId] = useState<string | null>(null);

  // Form data for Shop / Personal Transaction Add/Edit
  const [formData, setFormData] = useState({
    itemName: '',
    category: '',
    quantity: '',
    customerInfo: '',
    buyPrice: '',
    depositAmount: '',
    sellPrice: '',
    commissionTag: '',
    dueAmount: '',
    date: getTodayDateFormatted(),
    dayOfWeek: getBengaliDayOfWeek(getTodayDateFormatted()),
    note: '',
  });

  // =========================================================================
  // 1. UNIFIED SHARE & PDF MODAL STATE (১ দিন থেকে ৩১ দিন পর্যন্ত নির্বাচন)
  // =========================================================================
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [shareDaysRange, setShareDaysRange] = useState<number>(30); // 1 to 31 days
  const [isDownloadingPdf, setIsDownloadingPdf] = useState(false);
  const [cloudPromptType, setCloudPromptType] = useState<'drive' | 'sheet' | null>(null);

  // Filtered Shop Transactions
  const shopData = useMemo(() => {
    return shopTransactions.filter((t) => t.category !== 'ব্যক্তিগত' && t.category !== 'personal');
  }, [shopTransactions]);

  // Filtered Personal Transactions
  const personalData = useMemo(() => {
    return shopTransactions.filter((t) => t.category === 'ব্যক্তিগত' || t.category === 'personal');
  }, [shopTransactions]);

  // -------------------------------------------------------------------------
  // Helper to test if a record date is within the selected days limit (1 to 31)
  // -------------------------------------------------------------------------
  const isWithinDays = (dateStr: string, timestamp?: number, daysLimit: number = 30): boolean => {
    const now = Date.now();
    const maxDiffMs = daysLimit * 24 * 60 * 60 * 1000;

    let itemMs = timestamp;
    if (!itemMs || isNaN(itemMs)) {
      const norm = normalizeDigits(dateStr);
      const parts = norm.split(/[-/]/);
      if (parts.length === 3) {
        let d = parseInt(parts[0], 10);
        let m = parseInt(parts[1], 10) - 1;
        let y = parseInt(parts[2], 10);
        if (d > 1000) {
          y = parseInt(parts[0], 10);
          m = parseInt(parts[1], 10) - 1;
          d = parseInt(parts[2], 10);
        } else if (y < 100) {
          y += 2000;
        }
        const dt = new Date(y, m, d, 23, 59, 59);
        itemMs = dt.getTime();
      }
    }

    if (!itemMs || isNaN(itemMs)) return true;
    const diff = now - itemMs;
    // Allow today and within the past X days
    return diff >= -86400000 && diff <= maxDiffMs;
  };

  // Filter current active list by search query and date
  const filteredShopTransactions = useMemo(() => {
    return shopData.filter((t) => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = (t.itemName || '').toLowerCase().includes(q);
        const matchDate = (t.date || '').includes(q);
        if (!matchName && !matchDate) return false;
      }
      if (dateFilter === 'today') {
        const today = getTodayDateFormatted();
        return t.date === today || t.date === 'আজ';
      }
      return true;
    });
  }, [shopData, searchQuery, dateFilter]);

  const filteredPersonalTransactions = useMemo(() => {
    return personalData.filter((t) => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = (t.itemName || '').toLowerCase().includes(q);
        const matchDate = (t.date || '').includes(q);
        if (!matchName && !matchDate) return false;
      }
      if (dateFilter === 'today') {
        const today = getTodayDateFormatted();
        return t.date === today || t.date === 'আজ';
      }
      return true;
    });
  }, [personalData, searchQuery, dateFilter]);

  const filteredCustomers = useMemo(() => {
    return (customers || []).filter((c) => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = (c.name || '').toLowerCase().includes(q);
        const matchPhone = (c.phone || '').includes(q);
        return matchName || matchPhone;
      }
      return true;
    });
  }, [customers, searchQuery]);

  // All Customer Transactions
  const allCustomerTransactions = useMemo(() => {
    const list: ShopTransaction[] = [];
    const seenIds = new Set<string>();

    // 1. Transactions from customers
    (customers || []).forEach((c) => {
      (c.transactions || []).forEach((t) => {
        const id = t.id || `CTX-${c.id}-${t.date}-${t.itemName}`;
        seenIds.add(id);
        const s = Number(t.sellPrice) || 0;
        const d = Number(t.depositAmount) || 0;
        const du = t.dueAmount !== undefined && !isNaN(Number(t.dueAmount)) ? Number(t.dueAmount) : Math.max(0, s - d);
        list.push({
          id,
          itemName: t.itemName || 'পণ্য ক্রয় ও দেনা',
          quantity: t.quantity,
          category: 'কাস্টমার হিসাব',
          customerName: c.name,
          customerPhone: c.phone,
          linkedCustomerId: c.id,
          buyPrice: Number(t.buyPrice) || 0,
          sellPrice: s,
          depositAmount: d,
          dueAmount: du,
          profit: Number(t.profit) || Math.max(0, s - (Number(t.buyPrice) || 0)),
          date: t.date || getTodayDateFormatted(),
          time: t.time,
          note: t.note,
          createdAtMs: t.createdAtMs || Date.now(),
        });
      });
    });

    // 2. Transactions from shopData with customer info or tagged customer
    (shopData || []).forEach((t) => {
      if ((t.customerName || t.customerPhone || t.linkedCustomerId || t.category === 'কাস্টমার' || t.category === 'কাস্টমার হিসাব') && !seenIds.has(t.id)) {
        list.push(t);
      }
    });

    return list.sort((a, b) => (b.createdAtMs || 0) - (a.createdAtMs || 0));
  }, [customers, shopData]);

  const filteredCustomerTransactions = useMemo(() => {
    return allCustomerTransactions.filter((t) => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = (t.itemName || '').toLowerCase().includes(q);
        const matchCustomer = (t.customerName || '').toLowerCase().includes(q) || (t.customerPhone || '').includes(q);
        const matchNote = (t.note || '').toLowerCase().includes(q);
        if (!matchName && !matchCustomer && !matchNote) return false;
      }
      if (dateFilter === 'today') {
        const today = getTodayDateFormatted();
        return t.date === today || t.date === 'আজ';
      }
      return true;
    });
  }, [allCustomerTransactions, searchQuery, dateFilter]);

  // -------------------------------------------------------------------------
  // Top 4 Summary Totals (Identical 4-card structure for all 3 accounts)
  // -------------------------------------------------------------------------
  // 1. Shop Totals
  const shopSummary = useMemo(() => {
    let buy = 0;
    let sell = 0;
    let deposit = 0;
    let due = 0;
    let profit = 0;

    filteredShopTransactions.forEach((t) => {
      const b = Number(t.buyPrice) || 0;
      const s = Number(t.sellPrice) || 0;
      const d = Number(t.depositAmount) || 0;
      const du = Number(t.dueAmount) !== undefined && !isNaN(Number(t.dueAmount)) ? Number(t.dueAmount) : Math.max(0, s - d);
      const pr = Number(t.profit) || Math.max(0, s - b);

      buy += b;
      sell += s;
      deposit += d;
      due += du;
      profit += pr;
    });

    return { buy, sell, deposit, due, profit };
  }, [filteredShopTransactions]);

  // 2. Customer Totals (Identical structure to Shop Totals)
  const customerSummary = useMemo(() => {
    let buy = 0;
    let sell = 0;
    let deposit = 0;
    let due = 0;
    let profit = 0;

    filteredCustomerTransactions.forEach((t) => {
      const b = Number(t.buyPrice) || 0;
      const s = Number(t.sellPrice) || 0;
      const d = Number(t.depositAmount) || 0;
      const du = Number(t.dueAmount) !== undefined && !isNaN(Number(t.dueAmount)) ? Number(t.dueAmount) : Math.max(0, s - d);
      const pr = Number(t.profit) || Math.max(0, s - b);

      buy += b;
      sell += s;
      deposit += d;
      due += du;
      profit += pr;
    });

    return { buy, sell, deposit, due, profit, totalCustomers: (customers || []).length };
  }, [filteredCustomerTransactions, customers]);

  // 3. Personal Totals
  const personalSummary = useMemo(() => {
    let expense = 0;
    let deposit = 0;
    let due = 0;

    filteredPersonalTransactions.forEach((t) => {
      const exp = Number(t.buyPrice) || 0;
      const dep = Number(t.depositAmount) || 0;
      const du = Number(t.dueAmount) !== undefined && !isNaN(Number(t.dueAmount)) ? Number(t.dueAmount) : Math.max(0, exp - dep);

      expense += exp;
      deposit += dep;
      due += du;
    });

    const netRemaining = Math.max(0, deposit - expense);
    return { expense, deposit, due, netRemaining };
  }, [filteredPersonalTransactions]);

  // -------------------------------------------------------------------------
  // Transactions Filtered for the Share/PDF Modal (1 to 31 days)
  // -------------------------------------------------------------------------
  const shareFilteredItems = useMemo(() => {
    if (activeCategory === 'shop') {
      return shopData.filter((t) => isWithinDays(t.date, t.createdAtMs, shareDaysRange));
    } else if (activeCategory === 'personal') {
      return personalData.filter((t) => isWithinDays(t.date, t.createdAtMs, shareDaysRange));
    } else {
      // Customer Ledger records within range
      const list: Array<{
        customerName: string;
        customerPhone: string;
        itemName: string;
        date: string;
        sellPrice: number;
        depositAmount: number;
        dueAmount: number;
      }> = [];

      customers.forEach((cust) => {
        (cust.transactions || []).forEach((tx) => {
          if (isWithinDays(tx.date, tx.createdAtMs, shareDaysRange)) {
            list.push({
              customerName: cust.name,
              customerPhone: cust.phone,
              itemName: tx.itemName || 'পণ্য ক্রয়',
              date: tx.date,
              sellPrice: Number(tx.sellPrice) || 0,
              depositAmount: Number(tx.depositAmount) || 0,
              dueAmount: Number(tx.dueAmount) || 0,
            });
          }
        });
      });
      return list;
    }
  }, [activeCategory, shopData, personalData, customers, shareDaysRange]);

  // Share Totals for the selected 1-31 day range
  const shareRangeTotals = useMemo(() => {
    let col1 = 0; // Buy / Expense / Total Items
    let col2 = 0; // Sell / Income / Deposit
    let col3 = 0; // Due
    let col4 = 0; // Profit / Balance

    if (activeCategory === 'shop') {
      (shareFilteredItems as ShopTransaction[]).forEach((t) => {
        col1 += Number(t.buyPrice) || 0;
        col2 += Number(t.sellPrice) || 0;
        col3 += Number(t.dueAmount) || 0;
        col4 += Number(t.profit) || 0;
      });
    } else if (activeCategory === 'personal') {
      (shareFilteredItems as ShopTransaction[]).forEach((t) => {
        col1 += Number(t.buyPrice) || 0;
        col2 += Number(t.depositAmount) || 0;
        col3 += Number(t.dueAmount) || 0;
        col4 += Math.max(0, (Number(t.depositAmount) || 0) - (Number(t.buyPrice) || 0));
      });
    } else {
      // Customer
      (shareFilteredItems as any[]).forEach((t) => {
        col1 += t.sellPrice;
        col2 += t.depositAmount;
        col3 += t.dueAmount;
      });
      col4 = Math.max(0, col1 - col2);
    }

    return { col1, col2, col3, col4 };
  }, [shareFilteredItems, activeCategory]);

  // Open Add Modal
  const handleOpenAddModal = () => {
    const today = getTodayDateFormatted();
    setFormData({
      itemName: '',
      category: activeCategory === 'personal' ? 'ব্যক্তিগত' : '',
      quantity: '',
      customerInfo: '',
      buyPrice: '',
      depositAmount: '',
      sellPrice: '',
      commissionTag: '',
      dueAmount: '',
      date: today,
      dayOfWeek: getBengaliDayOfWeek(today),
      note: '',
    });
    setCustomCategoryInput('');
    setShowCustomCategoryInput(false);
    setShowManageProducts(false);
    setNewCustomProductInput('');
    setNewCustomQuantityInput('');
    setNewCustomCustomerInput('');
    setEditingTrx(null);
    setIsAddModalOpen(true);
  };

  // Open Edit Modal on row click
  const handleOpenEditModal = (trx: ShopTransaction) => {
    const isPersonal = trx.category === 'ব্যক্তিগত' || trx.category === 'personal' || activeCategory === 'personal';
    const b = trx.buyPrice !== undefined && trx.buyPrice !== null ? String(trx.buyPrice) : '';
    const s = trx.sellPrice !== undefined && trx.sellPrice !== null ? String(trx.sellPrice) : '';
    const d = trx.depositAmount !== undefined && trx.depositAmount !== null ? String(trx.depositAmount) : '';
    const dueVal = trx.dueAmount !== undefined && trx.dueAmount !== null ? String(trx.dueAmount) : '';
    const expenseVal = trx.buyPrice || trx.sellPrice || 0;

    const cleanCat = (trx.category === 'মুদি মালামাল' || trx.category === 'মদি মালামাল') ? '' : trx.category;
    const existingCust = trx.customerName
      ? (trx.customerPhone ? `${trx.customerName} (${trx.customerPhone})` : trx.customerName)
      : (trx.customerPhone || '');

    setEditingTrx(trx);
    setFormData({
      itemName: trx.itemName || '',
      category: cleanCat || (isPersonal ? 'ব্যক্তিগত' : ''),
      quantity: trx.quantity || '',
      customerInfo: existingCust,
      buyPrice: isPersonal ? String(expenseVal || '') : b,
      depositAmount: d,
      sellPrice: isPersonal ? String(expenseVal || '') : (s || b),
      commissionTag: trx.commissionTag || '',
      dueAmount: dueVal,
      date: trx.date || getTodayDateFormatted(),
      dayOfWeek: trx.dayOfWeek || getBengaliDayOfWeek(trx.date || getTodayDateFormatted()),
      note: trx.note || '',
    });
    setCustomCategoryInput('');
    setShowCustomCategoryInput(false);
    setShowManageProducts(false);
    setNewCustomProductInput('');
    setNewCustomQuantityInput('');
    setNewCustomCustomerInput('');
    setViewingTrx(null);
    setIsAddModalOpen(true);
  };

  // Save Transaction (Add or Update)
  const handleSaveTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.itemName.trim()) {
      showToast('অনুগ্রহ করে পণ্যের নাম বা বিবরণ লিখুন');
      return;
    }

    const buy = parseBengaliOrEnglishNumber(formData.buyPrice);
    const deposit = parseBengaliOrEnglishNumber(formData.depositAmount);
    
    // Check if this transaction is personal
    const isPersonal = editingTrx
      ? (editingTrx.category === 'ব্যক্তিগত' || editingTrx.category === 'personal' || activeCategory === 'personal')
      : activeCategory === 'personal';

    let sell = isPersonal ? buy : (parseBengaliOrEnglishNumber(formData.sellPrice) || buy);
    
    // Auto calculate due amount correctly
    const calculatedDue = isPersonal
      ? Math.max(0, buy - deposit)
      : (formData.dueAmount !== '' ? parseBengaliOrEnglishNumber(formData.dueAmount) : Math.max(0, sell - deposit));
    const due = calculatedDue;
    const profit = isPersonal ? 0 : Math.max(0, sell - buy);

    const chosenCategory = isPersonal
      ? 'ব্যক্তিগত'
      : (formData.category && formData.category !== 'মুদি মালামাল' && formData.category !== 'মদি মালামাল' ? formData.category.trim() : '');

    // Parse customerInfo
    let custName = '';
    let custPhone = '';
    const rawCustomerInfo = (formData.customerInfo || '').trim();
    if (rawCustomerInfo) {
      const match = rawCustomerInfo.match(/^(.*?)\s*[\(\[]?([0-9+০-৯]{8,15})[\)\]]?$/);
      if (match) {
        custName = match[1].trim() || match[2].trim();
        custPhone = match[2].trim();
      } else {
        custName = rawCustomerInfo;
      }
    }

    const matchedCustomer = customers.find((c) => 
      (custName && c.name.trim().toLowerCase() === custName.toLowerCase()) ||
      (c.phone && custPhone && c.phone.includes(custPhone)) ||
      (c.phone && rawCustomerInfo && rawCustomerInfo.includes(c.phone))
    );

    // Auto-save custom product & category to dropdown lists
    const trimmedItemName = formData.itemName.trim();
    if (!isPersonal && trimmedItemName && !savedProducts.includes(trimmedItemName)) {
      const updatedProds = [trimmedItemName, ...savedProducts];
      setSavedProducts(updatedProds);
      try {
        localStorage.setItem('tally_saved_products', JSON.stringify(updatedProds));
      } catch (err) {}
    }

    // Auto-save custom personal expense to personal dropdown list
    if (isPersonal && trimmedItemName && !savedPersonalExpenses.includes(trimmedItemName)) {
      const updatedPersonal = [trimmedItemName, ...savedPersonalExpenses];
      setSavedPersonalExpenses(updatedPersonal);
      try {
        localStorage.setItem('tally_saved_personal_expenses', JSON.stringify(updatedPersonal));
      } catch (err) {}
    }

    const trimmedQty = (formData.quantity || '').trim();
    if (trimmedQty && !savedQuantities.includes(trimmedQty)) {
      const updatedQty = [trimmedQty, ...savedQuantities];
      setSavedQuantities(updatedQty);
      try {
        localStorage.setItem('tally_saved_quantities', JSON.stringify(updatedQty));
      } catch (err) {}
    }

    // Auto-save customer to dropdown if new
    if (!isPersonal && rawCustomerInfo && !savedCustomerOptions.includes(rawCustomerInfo)) {
      const updatedCusts = [rawCustomerInfo, ...savedCustomerOptions];
      setSavedCustomerOptions(updatedCusts);
      try {
        localStorage.setItem('tally_saved_customers', JSON.stringify(updatedCusts));
      } catch (err) {}
    }

    if (!isPersonal && chosenCategory && chosenCategory !== 'মুদি মালামাল' && chosenCategory !== 'মদি মালামাল' && !savedCategories.includes(chosenCategory)) {
      const updatedCats = [chosenCategory, ...savedCategories];
      setSavedCategories(updatedCats);
      try {
        localStorage.setItem('tally_saved_categories', JSON.stringify(updatedCats));
      } catch (err) {}
    }

    if (editingTrx) {
      const targetId = String(editingTrx.id || `SHOP-${Date.now()}`).trim();
      const updated: ShopTransaction = {
        ...editingTrx,
        id: targetId,
        itemName: trimmedItemName,
        quantity: formData.quantity.trim() || undefined,
        category: chosenCategory,
        customerName: custName || (matchedCustomer ? matchedCustomer.name : undefined) || (editingTrx ? editingTrx.customerName : undefined),
        customerPhone: custPhone || (matchedCustomer ? matchedCustomer.phone : undefined) || (editingTrx ? editingTrx.customerPhone : undefined),
        linkedCustomerId: matchedCustomer ? matchedCustomer.id : (editingTrx ? editingTrx.linkedCustomerId : undefined),
        buyPrice: buy,
        sellPrice: sell,
        depositAmount: deposit,
        dueAmount: due,
        profit: profit,
        date: formData.date.trim() || getTodayDateFormatted(),
        dayOfWeek: formData.dayOfWeek.trim() || getBengaliDayOfWeek(formData.date),
        note: formData.note.trim() || undefined,
        updatedAtMs: Date.now(),
      };
      if (onUpdateTransaction) onUpdateTransaction(updated);
      setViewingTrx(null);
      setEditingTrx(null);
      setIsAddModalOpen(false);
      setSuccessEntryModal({
        isOpen: true,
        trx: updated,
        isEdit: true,
      });
      showToast('✓ হিসাব সফলভাবে এডিট ও সংরক্ষণ করা হয়েছে');
    } else {
      const newTrx: ShopTransaction = {
        id: `SHOP-${Date.now()}`,
        itemName: trimmedItemName,
        quantity: formData.quantity.trim() || undefined,
        category: chosenCategory,
        customerName: custName || (matchedCustomer ? matchedCustomer.name : undefined),
        customerPhone: custPhone || (matchedCustomer ? matchedCustomer.phone : undefined),
        linkedCustomerId: matchedCustomer ? matchedCustomer.id : undefined,
        buyPrice: buy,
        sellPrice: sell,
        depositAmount: deposit,
        dueAmount: due,
        profit: profit,
        date: formData.date.trim() || getTodayDateFormatted(),
        dayOfWeek: formData.dayOfWeek.trim() || getBengaliDayOfWeek(formData.date),
        time: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
        note: formData.note.trim() || undefined,
        createdAtMs: Date.now(),
        updatedAtMs: Date.now(),
      };
      if (onAddTransaction) onAddTransaction(newTrx);
      setEditingTrx(null);
      setIsAddModalOpen(false);
      setSuccessEntryModal({
        isOpen: true,
        trx: newTrx,
        isEdit: false,
      });
      showToast('নতুন হিসাব সফলভাবে সংরক্ষণ করা হয়েছে');
    }
  };

  // Add New Customer
  const handleSaveCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustomerName.trim()) {
      showToast('কাস্টমারের নাম লিখুন');
      return;
    }
    const dueNum = parseBengaliOrEnglishNumber(newCustomerDue);
    const newCust: CustomerAccount = {
      id: `CUST-${Date.now()}`,
      name: newCustomerName.trim(),
      phone: newCustomerPhone.trim() || '01XXXXXXXXX',
      transactions: dueNum > 0 ? [
        {
          id: `CTX-${Date.now()}`,
          itemName: 'পূর্বের বকেয়া বাকি',
          buyPrice: 0,
          sellPrice: dueNum,
          depositAmount: 0,
          dueAmount: dueNum,
          profit: 0,
          date: getTodayDateFormatted(),
          time: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
          createdAtMs: Date.now(),
        }
      ] : [],
    };
    if (onAddCustomer) onAddCustomer(newCust);
    showToast('নতুন কাস্টমার সফলভাবে যোগ হয়েছে');
    setIsAddCustomerModalOpen(false);
    setNewCustomerName('');
    setNewCustomerPhone('');
    setNewCustomerDue('');
  };

  // Open Edit Customer Modal
  const handleOpenEditCustomerModal = (cust: CustomerAccount, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setEditingCustomer(cust);
    setEditCustName(cust.name || '');
    setEditCustPhone(cust.phone || '');
    setIsEditCustomerModalOpen(true);
  };

  // Save Edited Customer
  const handleSaveEditCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCustomer) return;
    if (!editCustName.trim()) {
      showToast('কাস্টমারের নাম লিখুন');
      return;
    }
    const updatedCust: CustomerAccount = {
      ...editingCustomer,
      name: editCustName.trim(),
      phone: editCustPhone.trim() || '01XXXXXXXXX',
    };
    if (onUpdateCustomer) {
      onUpdateCustomer(updatedCust);
    }
    if (selectedCustomer && String(selectedCustomer.id).trim() === String(editingCustomer.id).trim()) {
      setSelectedCustomer(updatedCust);
    }
    showToast('কাস্টমার তথ্য সফলভাবে আপডেট হয়েছে');
    setIsEditCustomerModalOpen(false);
    setEditingCustomer(null);
  };

  // Add Transaction to Customer
  const handleSaveCustomerTx = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer) return;
    const buy = parseBengaliOrEnglishNumber(custTxBuy);
    const sell = parseBengaliOrEnglishNumber(custTxSell);
    const deposit = parseBengaliOrEnglishNumber(custTxDeposit);
    const due = custTxDue !== '' ? parseBengaliOrEnglishNumber(custTxDue) : Math.max(0, sell - deposit);
    const profit = Math.max(0, sell - buy);

    const itemTrim = custTxItem.trim() || 'পণ্য ক্রয় ও দেনা';
    if (custTxItem.trim() && !savedProducts.includes(custTxItem.trim())) {
      const updated = [custTxItem.trim(), ...savedProducts];
      setSavedProducts(updated);
      try {
        localStorage.setItem('tally_saved_products', JSON.stringify(updated));
      } catch (e) {}
    }

    const newTx: CustomerTransaction = {
      id: `CTX-${Date.now()}`,
      itemName: itemTrim,
      quantity: custTxQuantity.trim() || undefined,
      buyPrice: buy,
      sellPrice: sell,
      depositAmount: deposit,
      dueAmount: due,
      profit: profit,
      date: getTodayDateFormatted(),
      time: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
      createdAtMs: Date.now(),
    };

    if (onAddCustomerTransaction) {
      onAddCustomerTransaction(selectedCustomer.id, newTx);
    }
    setSelectedCustomer((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        transactions: [newTx, ...(prev.transactions || [])],
      };
    });
    showToast('✓ কাস্টমার লেনদেন সফলভাবে যোগ হয়েছে');
    setIsAddCustTxModalOpen(false);
    setCustTxItem('');
    setCustTxQuantity('');
    setCustTxBuy('');
    setCustTxSell('');
    setCustTxDeposit('');
    setCustTxDue('');
  };

  // Open Edit Customer Transaction Modal
  const handleOpenEditCustTxModal = (tx: CustomerTransaction, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setEditingCustTx(tx);
    setEditCustTxItem(tx.itemName || '');
    setEditCustTxQuantity(tx.quantity || '');
    setEditCustTxBuy(tx.buyPrice !== undefined && tx.buyPrice !== null ? String(tx.buyPrice) : '');
    setEditCustTxSell(tx.sellPrice !== undefined && tx.sellPrice !== null ? String(tx.sellPrice) : '');
    setEditCustTxDeposit(tx.depositAmount !== undefined && tx.depositAmount !== null ? String(tx.depositAmount) : '');
    setEditCustTxDue(tx.dueAmount !== undefined && tx.dueAmount !== null ? String(tx.dueAmount) : '');
    setIsEditCustTxModalOpen(true);
  };

  // Save Edited Customer Transaction
  const handleSaveEditCustTx = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer || !editingCustTx) return;
    const buy = parseBengaliOrEnglishNumber(editCustTxBuy);
    const sell = parseBengaliOrEnglishNumber(editCustTxSell);
    const deposit = parseBengaliOrEnglishNumber(editCustTxDeposit);
    const due = editCustTxDue !== '' ? parseBengaliOrEnglishNumber(editCustTxDue) : Math.max(0, sell - deposit);
    const profit = Math.max(0, sell - buy);

    const itemTrim = editCustTxItem.trim() || 'পণ্য ক্রয় ও দেনা';
    if (editCustTxItem.trim() && !savedProducts.includes(editCustTxItem.trim())) {
      const updated = [editCustTxItem.trim(), ...savedProducts];
      setSavedProducts(updated);
      try {
        localStorage.setItem('tally_saved_products', JSON.stringify(updated));
      } catch (e) {}
    }

    const updatedTx: CustomerTransaction = {
      ...editingCustTx,
      itemName: itemTrim,
      quantity: editCustTxQuantity.trim() || undefined,
      buyPrice: buy,
      sellPrice: sell,
      depositAmount: deposit,
      dueAmount: due,
      profit: profit,
    };

    if (onUpdateCustomerTransaction) {
      onUpdateCustomerTransaction(selectedCustomer.id, updatedTx);
    }
    setSelectedCustomer((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        transactions: (prev.transactions || []).map((t) => (String(t.id).trim() === String(updatedTx.id).trim() ? updatedTx : t)),
      };
    });
    showToast('✓ কাস্টমার লেনদেন সফলভাবে আপডেট হয়েছে');
    setIsEditCustTxModalOpen(false);
    setEditingCustTx(null);
    setEditCustTxItem('');
    setEditCustTxQuantity('');
    setEditCustTxBuy('');
    setEditCustTxSell('');
    setEditCustTxDeposit('');
    setEditCustTxDue('');
  };

  // Delete Customer Transaction
  const handleDeleteCustTx = (txId: string, parentCustomerId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setDeleteConfirmId(txId);
    setDeleteCustTxParentId(parentCustomerId);
    setDeleteConfirmType('cust_tx');
  };

  // Delete Handler
  const handleDeleteItem = () => {
    if (!deleteConfirmId) return;
    if (deleteConfirmType === 'shop_trx' && onDeleteTransaction) {
      onDeleteTransaction(deleteConfirmId);
      if (viewingTrx && String(viewingTrx.id).trim() === String(deleteConfirmId).trim()) {
        setViewingTrx(null);
      }
      if (editingTrx && String(editingTrx.id).trim() === String(deleteConfirmId).trim()) {
        setEditingTrx(null);
        setIsAddModalOpen(false);
      }
      showToast('হিসাব সফলভাবে মুছে ফেলা হয়েছে');
    } else if (deleteConfirmType === 'customer' && onDeleteCustomer) {
      onDeleteCustomer(deleteConfirmId);
      showToast('কাস্টমার অ্যাকাউন্ট মুছে ফেলা হয়েছে');
    } else if (deleteConfirmType === 'cust_tx' && deleteCustTxParentId && onDeleteCustomerTransaction) {
      onDeleteCustomerTransaction(deleteCustTxParentId, deleteConfirmId);
      setSelectedCustomer((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          transactions: (prev.transactions || []).filter((t) => String(t.id).trim() !== String(deleteConfirmId).trim()),
        };
      });
      showToast('লেনদেন মুছে ফেলা হয়েছে');
    }
    setDeleteConfirmId(null);
    setDeleteCustTxParentId(null);
  };

  // -------------------------------------------------------------------------
  // PDF GENERATION & EXPORT VIA html2pdf.js (Rock-solid offscreen rendering)
  // -------------------------------------------------------------------------
  const handleDownloadPdf = async () => {
    if (isDownloadingPdf) return;
    setIsDownloadingPdf(true);
    showToast('PDF ফাইল তৈরি হচ্ছে, অনুগ্রহ করে অপেক্ষা করুন...');

    let clone: HTMLElement | null = null;
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const html2pdfModule: any = await import('html2pdf.js');
      const html2pdf = html2pdfModule.default || html2pdfModule;

      const printRoot = document.getElementById('tally-pdf-render-root');
      if (!printRoot) throw new Error('Print root container not found');

      // Clone element off-screen for perfect A4 rendering at (0,0) with negative z-index
      clone = printRoot.cloneNode(true) as HTMLElement;
      clone.classList.remove('hidden');
      clone.classList.add('block');
      clone.style.position = 'fixed';
      clone.style.left = '0px';
      clone.style.top = '0px';
      clone.style.width = '794px';
      clone.style.maxWidth = '794px';
      clone.style.background = '#ffffff';
      clone.style.color = '#0f172a';
      clone.style.zIndex = '-9999';
      clone.style.opacity = '1';
      clone.style.pointerEvents = 'none';
      document.body.appendChild(clone);

      // Sanitize colors for html2canvas compatibility
      const all = [clone, ...Array.from(clone.querySelectorAll('*'))] as HTMLElement[];
      const colorProps = ['color', 'backgroundColor', 'borderColor', 'outlineColor'] as const;
      all.forEach((el) => {
        try {
          const comp = window.getComputedStyle(el);
          colorProps.forEach((prop) => {
            const val = comp[prop];
            if (val && typeof val === 'string' && (val.includes('oklch') || val.includes('lab'))) {
              if (prop === 'backgroundColor') el.style.backgroundColor = '#ffffff';
              else if (prop === 'color') el.style.color = '#0f172a';
              else if (prop === 'borderColor') el.style.borderColor = '#cbd5e1';
            }
          });
        } catch {}
      });

      const categoryName =
        activeCategory === 'shop'
          ? 'দোকানের_হিসাব'
          : activeCategory === 'customer'
          ? 'কাস্টমার_হিসাব'
          : 'ব্যক্তিগত_হিসাব';
      const fileName = `${categoryName}_${toBengaliDigits(shareDaysRange)}_দিনের_রিপোর্ট.pdf`;

      const opt = {
        margin: [10, 8, 10, 8] as [number, number, number, number],
        filename: fileName,
        image: { type: 'jpeg' as const, quality: 0.98 },
        html2canvas: {
          scale: 2,
          useCORS: true,
          logging: false,
          backgroundColor: '#ffffff',
          windowWidth: 794,
        },
        jsPDF: { unit: 'mm' as const, format: 'a4' as const, orientation: 'portrait' as const },
      };

      await html2pdf().set(opt).from(clone).save();
      showToast('✓ PDF ফাইল ডাউনলোড সম্পন্ন হয়েছে!');
    } catch (err) {
      console.error('PDF error:', err);
      // Clean fallback: download HTML printable report without disruptive window.print popup
      try {
        const printRoot = document.getElementById('tally-pdf-render-root');
        if (printRoot) {
          const content = printRoot.innerHTML;
          const htmlDoc = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>টালি খাতা রিপোর্ট</title><style>body{font-family:sans-serif;padding:24px;color:#0f172a;background:#fff;}table{width:100%;border-collapse:collapse;margin-top:16px;}th,td{border:1px solid #cbd5e1;padding:6px 8px;font-size:12px;}th{background:#0d2847;color:#fff;}</style></head><body>${content}</body></html>`;
          const blob = new Blob([htmlDoc], { type: 'text/html;charset=utf-8;' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `টালি_খাতা_হিসাব_${toBengaliDigits(shareDaysRange)}_দিন.html`;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
          showToast('✓ হিসাব রিপোর্ট ফাইল ডাউনলোড সম্পন্ন হয়েছে!');
        }
      } catch {
        showToast('রিপোর্ট ডাউনলোড করতে সমস্যা হয়েছে');
      }
    } finally {
      if (clone && clone.parentNode) {
        clone.parentNode.removeChild(clone);
      }
      setIsDownloadingPdf(false);
    }
  };

  // -------------------------------------------------------------------------
  // GOOGLE DRIVE EXPORT & SAVE
  // -------------------------------------------------------------------------
  const handleSaveToGoogleDrive = async () => {
    if (isDownloadingPdf) return;
    setIsDownloadingPdf(true);
    showToast('গুগল ড্রাইভের জন্য PDF প্রস্তুত হচ্ছে...');

    let clone: HTMLElement | null = null;
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const html2pdfModule: any = await import('html2pdf.js');
      const html2pdf = html2pdfModule.default || html2pdfModule;

      const printRoot = document.getElementById('tally-pdf-render-root');
      if (!printRoot) throw new Error('Print root container not found');

      clone = printRoot.cloneNode(true) as HTMLElement;
      clone.classList.remove('hidden');
      clone.classList.add('block');
      clone.style.position = 'fixed';
      clone.style.left = '0px';
      clone.style.top = '0px';
      clone.style.width = '794px';
      clone.style.maxWidth = '794px';
      clone.style.background = '#ffffff';
      clone.style.color = '#0f172a';
      clone.style.zIndex = '-9999';
      clone.style.opacity = '1';
      clone.style.pointerEvents = 'none';
      document.body.appendChild(clone);

      const categoryName =
        activeCategory === 'shop'
          ? 'দোকানের_হিসাব'
          : activeCategory === 'customer'
          ? 'কাস্টমার_হিসাব'
          : 'ব্যক্তিগত_হিসাব';
      const fileName = `${categoryName}_গুগল_ড্রাইভ_ব্যাকআপ_${toBengaliDigits(shareDaysRange)}_দিন.pdf`;

      const opt = {
        margin: [10, 8, 10, 8] as [number, number, number, number],
        filename: fileName,
        image: { type: 'jpeg' as const, quality: 0.98 },
        html2canvas: {
          scale: 2,
          useCORS: true,
          logging: false,
          backgroundColor: '#ffffff',
          windowWidth: 794,
        },
        jsPDF: { unit: 'mm' as const, format: 'a4' as const, orientation: 'portrait' as const },
      };

      await html2pdf().set(opt).from(clone).save();
      setCloudPromptType('drive');
      showToast('✓ PDF ফাইল ডাউনলোড হয়েছে! গুগল ড্রাইভে সংরক্ষণ করতে নিচের লিংকে ক্লিক করুন।');
    } catch (err) {
      console.error('Google Drive error:', err);
      showToast('গুগল ড্রাইভের ফাইল তৈরিতে সমস্যা হয়েছে');
    } finally {
      if (clone && clone.parentNode) {
        clone.parentNode.removeChild(clone);
      }
      setIsDownloadingPdf(false);
    }
  };

  // -------------------------------------------------------------------------
  // GOOGLE SHEETS EXPORT & SAVE (CSV with UTF-8 BOM)
  // -------------------------------------------------------------------------
  const handleSaveToGoogleSheet = () => {
    try {
      showToast('গুগল শীট ফাইল তৈরি হচ্ছে...');

      const categoryTitle =
        activeCategory === 'shop'
          ? 'দোকানের হিসাব বিবরণী'
          : activeCategory === 'customer'
          ? 'কাস্টমার বাকি ও জমা খাতা'
          : 'ব্যক্তিগত আয়-ব্যয় বিবরণী';

      const rows: string[][] = [];

      // 1. Title Rows
      rows.push([user?.shopName || 'ডিজিটাল টালি খাতা']);
      rows.push([categoryTitle]);
      rows.push([`সময়কাল: বিগত ${toBengaliDigits(shareDaysRange)} দিন`, `তারিখ: ${formatBengaliDate(getTodayDateFormatted())}`]);
      rows.push([]);

      // 2. Summary Row
      if (activeCategory === 'shop') {
        rows.push(['মোট ক্রয় (৳)', 'মোট বিক্রি (৳)', 'মোট বাকি (৳)', 'নিট লাভ (৳)']);
        rows.push([
          String(shareRangeTotals.col1),
          String(shareRangeTotals.col2),
          String(shareRangeTotals.col3),
          String(shareRangeTotals.col4),
        ]);
      } else if (activeCategory === 'customer') {
        rows.push(['মোট বিক্রি (৳)', 'মোট জমা (৳)', 'মোট বাকি (৳)', 'অবশিষ্ট পাওনা (৳)']);
        rows.push([
          String(shareRangeTotals.col1),
          String(shareRangeTotals.col2),
          String(shareRangeTotals.col3),
          String(shareRangeTotals.col4),
        ]);
      } else {
        rows.push(['মোট খরচ (৳)', 'নগদ জমা (৳)', 'মোট দেনা (৳)', 'অবশিষ্ট ব্যালেন্স (৳)']);
        rows.push([
          String(shareRangeTotals.col1),
          String(shareRangeTotals.col2),
          String(shareRangeTotals.col3),
          String(shareRangeTotals.col4),
        ]);
      }
      rows.push([]);

      // 3. Column Headers
      rows.push([
        'ক্রম',
        'তারিখ',
        'বিবরণ / পণ্যের নাম',
        'কাস্টমার / গ্রহীতার নাম',
        'মোবাইল নম্বর',
        activeCategory === 'shop' ? 'ক্রয়মূল্য (৳)' : activeCategory === 'customer' ? 'বিক্রয়মূল্য (৳)' : 'খরচের পরিমাণ (৳)',
        activeCategory === 'shop' ? 'বিক্রয়মূল্য (৳)' : 'জমার পরিমাণ (৳)',
        'বাকি / বকেয়া (৳)',
        'লাভ / স্থিতি (৳)',
        'মন্তব্য / নোট',
      ]);

      // 4. Data Rows
      shareFilteredItems.forEach((item: any, idx) => {
        const serial = String(idx + 1);
        const date = item.date || '';
        const name = item.itemName || '';
        const customer = item.customerName || '';
        const phone = item.customerPhone || '';
        const colBuy = String(item.buyPrice || 0);
        const colSell = String(item.sellPrice || item.depositAmount || 0);
        const colDue = String(item.dueAmount || 0);
        const colProfit = String(item.profit || 0);
        const note = item.note || '';

        rows.push([serial, date, name, customer, phone, colBuy, colSell, colDue, colProfit, note]);
      });

      // Convert rows to CSV format
      const csvContent = rows
        .map((row) =>
          row
            .map((cell) => {
              const str = (cell ?? '').toString().replace(/"/g, '""');
              return str.includes(',') || str.includes('\n') || str.includes('"') ? `"${str}"` : str;
            })
            .join(',')
        )
        .join('\r\n');

      // Add UTF-8 BOM so Bengali renders correctly in Google Sheets & Excel
      const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
      const categoryName =
        activeCategory === 'shop'
          ? 'দোকানের_হিসাব'
          : activeCategory === 'customer'
          ? 'কাস্টমার_হিসাব'
          : 'ব্যক্তিগত_হিসাব';
      const fileName = `${categoryName}_গুগল_শীট_${toBengaliDigits(shareDaysRange)}_দিন.csv`;

      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', fileName);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setCloudPromptType('sheet');
      showToast('✓ গুগল শীট ফাইল ডাউনলোড হয়েছে! গুগল শীটে খুলতে নিচের লিংকে ক্লিক করুন।');
    } catch (err) {
      console.error('Google Sheets export error:', err);
      showToast('গুগল শীট তৈরিতে সমস্যা হয়েছে');
    }
  };

  // WhatsApp Share
  const handleWhatsAppShare = () => {
    const title =
      activeCategory === 'shop'
        ? 'দোকানের হিসাব'
        : activeCategory === 'customer'
        ? 'কাস্টমার হিসাব'
        : 'ব্যক্তিগত হিসাব';
    const text = `📊 *${title} রিপোর্ট*\n📅 সময়কাল: বিগত ${toBengaliDigits(shareDaysRange)} দিন\n\n` +
      `🔹 মোট খরচ/দেনা: ৳${toBengaliDigits(shareRangeTotals.col1)}\n` +
      `🔹 মোট বিক্রি/জমা: ৳${toBengaliDigits(shareRangeTotals.col2)}\n` +
      `🔹 মোট বাকি/বকেয়া: ৳${toBengaliDigits(shareRangeTotals.col3)}\n` +
      `🔹 নিট লাভ/অবশিষ্ট: ৳${toBengaliDigits(shareRangeTotals.col4)}\n\n` +
      `মোট লেনদেন: ${toBengaliDigits(shareFilteredItems.length)} টি\n(পূর্ণাঙ্গ PDF রিপোর্ট তৈরি করা হয়েছে)`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  // Device Web Share
  const handleDeviceShare = async () => {
    const title =
      activeCategory === 'shop'
        ? 'দোকানের হিসাব'
        : activeCategory === 'customer'
        ? 'কাস্টমার হিসাব'
        : 'ব্যক্তিগত হিসাব';
    const text = `📊 ${title} (${toBengaliDigits(shareDaysRange)} দিন):\nখরচ: ৳${toBengaliDigits(shareRangeTotals.col1)}, জমা: ৳${toBengaliDigits(shareRangeTotals.col2)}, বাকি: ৳${toBengaliDigits(shareRangeTotals.col3)}`;
    if (navigator.share) {
      try {
        await navigator.share({ title, text });
      } catch {}
    } else {
      navigator.clipboard.writeText(text);
      showToast('হিসাবের বিবরণী ক্লিপবোর্ডে কপি হয়েছে');
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 pb-20 select-none">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white px-4 py-2 rounded-xl text-xs font-black shadow-lg flex items-center gap-2 border border-slate-700 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. TOP HEADER & SLIM BANNER (ছোট, পরিষ্কার ও সুন্দর; নাম বা লোগো মুক্ত)     */}
      {/* ========================================================================= */}
      <header
        className="bg-[#0d2847] text-white px-2.5 py-2 shadow-sm sticky top-0 z-30"
        style={{
          paddingTop: 'max(8px, calc(env(safe-area-inset-top, 0px) + 6px))',
        }}
      >
        <div className="flex items-center justify-between gap-1.5 max-w-lg mx-auto">
          {/* Left: Back Button */}
          {onBack ? (
            <button
              type="button"
              onClick={onBack}
              className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer shrink-0"
              title="হোমে ফিরুন"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          ) : (
            <div className="w-1" />
          )}

          {/* Center: Clean App Header Title (বাটনগুলো নিচে হিসাব যোগ করুন বাটনের উপরে স্থানান্তরিত) */}
          <div className="flex items-center justify-center gap-1.5 py-1">
            <ClipboardList className="w-4 h-4 text-emerald-400" />
            <span className="text-sm font-black text-white tracking-wide">টালি খাতা</span>
          </div>

          {/* Right: Exactly 1 Dedicated Share Button */}
          <button
            type="button"
            id="tally-single-share-btn"
            onClick={() => {
              setCloudPromptType(null);
              setIsShareModalOpen(true);
            }}
            className="h-8 px-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs flex items-center gap-1 shadow-xs transition-transform active:scale-95 cursor-pointer shrink-0"
            title={`${activeCategory === 'shop' ? 'দোকানের' : activeCategory === 'customer' ? 'কাস্টমার' : 'ব্যক্তিগত'} হিসাবের PDF ডাউনলোড, গুগল ড্রাইভ ও শীট`}
          >
            <Share2 className="w-3.5 h-3.5 stroke-[2.5]" />
            <span className="hidden sm:inline">শেয়ার</span>
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-lg mx-auto px-2.5 py-2 space-y-2.5">
        {/* ========================================================================= */}
        {/* QUICK ACCESS BANNER: ৩টি হিসাবের সার্বিক বিবরণী ও সারসংক্ষেপ পেজ            */}
        {/* ========================================================================= */}
        {onOpenCombinedSummary && (
          <div
            id="banner-open-combined-summary"
            onClick={onOpenCombinedSummary}
            className="bg-gradient-to-r from-[#0d2847] via-[#0f3460] to-[#1e3a8a] text-white rounded-xl p-2.5 shadow-xs border border-blue-400/40 flex items-center justify-between gap-2 cursor-pointer transition-all hover:brightness-110 active:scale-[0.99]"
            title="তিন হিসাবের সার্বিক পর্যালোচনা দেখুন"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-blue-500/25 border border-blue-400/50 flex items-center justify-center text-amber-300 shrink-0">
                <Scale className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-black text-white truncate">তিন হিসাবের সার্বিক বিবরণী</span>
                  <span className="text-[9px] font-black bg-emerald-500/30 text-emerald-300 px-1.5 py-0.5 rounded-full border border-emerald-400/40 shrink-0">
                    আলাদা পেজ
                  </span>
                </div>
                <p className="text-[10px] text-slate-300 truncate">
                  মোট আয়, ব্যয় ও কাস্টমারদের কাছে কত টাকা পাবেন
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1 text-[11px] font-black text-amber-300 bg-white/10 hover:bg-white/20 px-2.5 py-1 rounded-lg border border-white/20 shrink-0">
              <span>দেখুন</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        )}
        {/* ========================================================================= */}
        {/* 2. TOP 4 SUMMARY BOXES (তিনটি হিসাবের জন্যই হুবহু একই ডিজাইন)             */}
        {/* ========================================================================= */}
        <section className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
          {activeCategory === 'shop' && (
            <>
              <div className="bg-white rounded-xl p-2 border border-rose-200/80 shadow-2xs">
                <span className="text-[10px] font-bold text-slate-500 block">মোট ক্রয়/খরচ</span>
                <span className="text-sm font-black text-rose-600 font-mono">
                  {formatTaka(shopSummary.buy)} ৳
                </span>
              </div>
              <div className="bg-white rounded-xl p-2 border border-emerald-200/80 shadow-2xs">
                <span className="text-[10px] font-bold text-slate-500 block">মোট বিক্রি/জমা</span>
                <span className="text-sm font-black text-emerald-600 font-mono">
                  {formatTaka(shopSummary.sell)} ৳
                </span>
              </div>
              <div className="bg-white rounded-xl p-2 border border-amber-200/80 shadow-2xs">
                <span className="text-[10px] font-bold text-slate-500 block">কাস্টমার বাকি</span>
                <span className="text-sm font-black text-amber-600 font-mono">
                  {formatTaka(shopSummary.due)} ৳
                </span>
              </div>
              <div className="bg-white rounded-xl p-2 border border-blue-200/80 shadow-2xs">
                <span className="text-[10px] font-bold text-slate-500 block">নিট লাভ/কমিশন</span>
                <span className="text-sm font-black text-blue-600 font-mono">
                  {formatTaka(shopSummary.profit)} ৳
                </span>
              </div>
            </>
          )}

          {activeCategory === 'customer' && (
            <>
              <div className="bg-white rounded-xl p-2 border border-emerald-200/80 shadow-2xs">
                <span className="text-[10px] font-bold text-slate-500 block">মোট বিক্রি / দেনা</span>
                <span className="text-sm font-black text-emerald-700 font-mono">
                  {formatTaka(customerSummary.sell)} ৳
                </span>
              </div>
              <div className="bg-white rounded-xl p-2 border border-indigo-200/80 shadow-2xs">
                <span className="text-[10px] font-bold text-slate-500 block">মোট ক্রয়</span>
                <span className="text-sm font-black text-indigo-600 font-mono">
                  {formatTaka(customerSummary.buy)} ৳
                </span>
              </div>
              <div className="bg-white rounded-xl p-2 border border-blue-200/80 shadow-2xs">
                <span className="text-[10px] font-bold text-slate-500 block">মোট জমা প্রাপ্তি</span>
                <span className="text-sm font-black text-blue-600 font-mono">
                  {formatTaka(customerSummary.deposit)} ৳
                </span>
              </div>
              <div className="bg-white rounded-xl p-2 border border-amber-200/80 shadow-2xs">
                <span className="text-[10px] font-bold text-slate-500 block">মোট কাস্টমার বাকি</span>
                <span className="text-sm font-black text-amber-600 font-mono">
                  {formatTaka(customerSummary.due)} ৳
                </span>
              </div>
            </>
          )}

          {activeCategory === 'personal' && (
            <>
              <div className="bg-white rounded-xl p-2 border border-rose-200/80 shadow-2xs">
                <span className="text-[10px] font-bold text-slate-500 block">ব্যক্তিগত খরচ</span>
                <span className="text-sm font-black text-rose-600 font-mono">
                  {formatTaka(personalSummary.expense)} ৳
                </span>
              </div>
              <div className="bg-white rounded-xl p-2 border border-emerald-200/80 shadow-2xs">
                <span className="text-[10px] font-bold text-slate-500 block">মোট নগদ জমা</span>
                <span className="text-sm font-black text-emerald-600 font-mono">
                  {formatTaka(personalSummary.deposit)} ৳
                </span>
              </div>
              <div className="bg-white rounded-xl p-2 border border-amber-200/80 shadow-2xs">
                <span className="text-[10px] font-bold text-slate-500 block">ব্যক্তিগত বকেয়া</span>
                <span className="text-sm font-black text-amber-600 font-mono">
                  {formatTaka(personalSummary.due)} ৳
                </span>
              </div>
              <div className="bg-white rounded-xl p-2 border border-purple-200/80 shadow-2xs">
                <span className="text-[10px] font-bold text-slate-500 block">নিট অবশিষ্ট</span>
                <span className="text-sm font-black text-purple-600 font-mono">
                  {formatTaka(personalSummary.netRemaining)} ৳
                </span>
              </div>
            </>
          )}
        </section>

        {/* ========================================================================= */}
        {/* ৩টি ক্যাটাগরি বাটন: দোকানের হিসাব / কাস্টমার হিসাব / ব্যক্তিগত হিসাব       */}
        {/* (হিসাব যোগ করুন বাটনের ঠিক উপরে অবস্থিত)                                   */}
        {/* ========================================================================= */}
        <section className="bg-white rounded-2xl p-2 sm:p-2.5 border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between px-0.5">
            <span className="text-[11px] font-black text-slate-800 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              হিসাবের ক্যাটাগরি:
            </span>
            <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
              ৩টি হিসাব সারিবদ্ধভাবে
            </span>
          </div>

          {/* সারিবদ্ধভাবে ৩টি বাটন (দোকানের হিসাব, কাস্টমার হিসাব, ব্যক্তিগত হিসাব) */}
          <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
            {/* ১. দোকানের হিসাব বাটন */}
            <button
              type="button"
              id="btn-category-shop"
              onClick={() => setActiveCategory('shop')}
              className={`p-2 rounded-xl text-center transition-all cursor-pointer border flex flex-col items-center justify-center gap-1 relative ${
                activeCategory === 'shop'
                  ? 'bg-emerald-600 text-white border-emerald-700 shadow-md shadow-emerald-600/25 scale-[1.02]'
                  : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200 hover:border-emerald-300'
              }`}
            >
              <div className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center transition-colors ${
                activeCategory === 'shop' ? 'bg-white/20 text-white' : 'bg-emerald-100 text-emerald-700'
              }`}>
                <Store className="w-4 h-4" />
              </div>
              <span className="text-xs font-black leading-tight">দোকানের হিসাব</span>
              <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md font-mono ${
                activeCategory === 'shop' ? 'bg-white/20 text-white' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
              }`}>
                লাভ: {formatTaka(shopSummary.profit)} ৳
              </span>
            </button>

            {/* ২. কাস্টমার হিসাব বাটন */}
            <button
              type="button"
              id="btn-category-customer"
              onClick={() => setActiveCategory('customer')}
              className={`p-2 rounded-xl text-center transition-all cursor-pointer border flex flex-col items-center justify-center gap-1 relative ${
                activeCategory === 'customer'
                  ? 'bg-blue-600 text-white border-blue-700 shadow-md shadow-blue-600/25 scale-[1.02]'
                  : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200 hover:border-blue-300'
              }`}
            >
              <div className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center transition-colors ${
                activeCategory === 'customer' ? 'bg-white/20 text-white' : 'bg-blue-100 text-blue-700'
              }`}>
                <Users className="w-4 h-4" />
              </div>
              <span className="text-xs font-black leading-tight">কাস্টমার হিসাব</span>
              <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md font-mono ${
                activeCategory === 'customer' ? 'bg-white/20 text-white' : 'bg-blue-50 text-blue-700 border border-blue-200'
              }`}>
                বাকি: {formatTaka(customerSummary.due)} ৳
              </span>
            </button>

            {/* ৩. ব্যক্তিগত হিসাব বাটন */}
            <button
              type="button"
              id="btn-category-personal"
              onClick={() => setActiveCategory('personal')}
              className={`p-2 rounded-xl text-center transition-all cursor-pointer border flex flex-col items-center justify-center gap-1 relative ${
                activeCategory === 'personal'
                  ? 'bg-purple-600 text-white border-purple-700 shadow-md shadow-purple-600/25 scale-[1.02]'
                  : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200 hover:border-purple-300'
              }`}
            >
              <div className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center transition-colors ${
                activeCategory === 'personal' ? 'bg-white/20 text-white' : 'bg-purple-100 text-purple-700'
              }`}>
                <User className="w-4 h-4" />
              </div>
              <span className="text-xs font-black leading-tight">ব্যক্তিগত হিসাব</span>
              <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md font-mono ${
                activeCategory === 'personal' ? 'bg-white/20 text-white' : 'bg-purple-50 text-purple-700 border border-purple-200'
              }`}>
                খরচ: {formatTaka(personalSummary.expense)} ৳
              </span>
            </button>
          </div>
        </section>

        {/* ========================================================================= */}
        {/* 3. SEARCH & "হিসাব যোগ করুন" ACTION BAR                                   */}
        {/* ========================================================================= */}
        <section className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                activeCategory === 'shop'
                  ? 'দোকানের হিসাব বা পণ্য খুঁজুন...'
                  : activeCategory === 'customer'
                  ? 'কাস্টমারের নাম বা ফোন নম্বর খুঁজুন...'
                  : 'ব্যক্তিগত খরচের খাত খুঁজুন...'
              }
              className="w-full pl-8 pr-7 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800 outline-none focus:border-blue-500 shadow-2xs"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-3 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* বড় ও স্পষ্ট "হিসাব যোগ করুন" বাটন (ডান পাশের বাটন মুছে দেওয়া হয়েছে) */}
          <button
            type="button"
            id="btn-add-entry"
            onClick={handleOpenAddModal}
            className={`px-4 sm:px-5 py-2.5 text-white rounded-xl text-xs sm:text-sm font-black flex items-center gap-1.5 shadow-md transition-all active:scale-95 cursor-pointer shrink-0 ${
              activeCategory === 'shop'
                ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/25'
                : activeCategory === 'customer'
                ? 'bg-blue-600 hover:bg-blue-700 shadow-blue-600/25'
                : 'bg-purple-600 hover:bg-purple-700 shadow-purple-600/25'
            }`}
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>হিসাব যোগ করুন</span>
          </button>
        </section>

        {/* ========================================================================= */}
        {/* 4. MAIN DATA TABLE / LIST (একই ডিজাইন - ৩টি হিসাবের জন্যই হুবহু একরকম)    */}
        {/* ========================================================================= */}
        <section className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          {/* Table Header */}
          <div className="bg-[#0d2847] text-white text-[11px] font-black py-2 px-2 flex items-center justify-between">
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-emerald-400" />
              <span>
                {activeCategory === 'shop'
                  ? 'দোকানের দৈনিক লেনদেন খাতা'
                  : activeCategory === 'customer'
                  ? 'কাস্টমারদের বাকি ও জমা হিসাব'
                  : 'ব্যক্তিগত খরচের হিসাব তালিকা'}
              </span>
            </span>
            <div className="flex items-center gap-2">
              {onOpenCombinedSummary && (
                <button
                  type="button"
                  onClick={onOpenCombinedSummary}
                  className="text-[10px] text-amber-300 hover:text-amber-200 underline font-black cursor-pointer"
                >
                  সার্বিক সারসংক্ষেপ ➔
                </button>
              )}
              <span className="text-[10px] text-slate-300 font-mono">
                মোট:{' '}
                {toBengaliDigits(
                  activeCategory === 'shop'
                    ? filteredShopTransactions.length
                    : activeCategory === 'customer'
                    ? filteredCustomers.length
                    : filteredPersonalTransactions.length
                )}
              </span>
            </div>
          </div>

              {/* 4.1 SHOP LEDGER LIST */}
              {activeCategory === 'shop' && (
                <div className="divide-y divide-slate-100">
                  {filteredShopTransactions.length === 0 ? (
                    <div className="p-8 text-center text-slate-400 space-y-1">
                      <Store className="w-8 h-8 mx-auto text-slate-300" />
                      <p className="text-xs font-bold text-slate-600">কোনো হিসাব পাওয়া যায়নি</p>
                      <p className="text-[11px]">উপরের বাটন দিয়ে নতুন হিসাব যোগ করুন</p>
                    </div>
                  ) : (
                    filteredShopTransactions.map((trx, idx) => (
                      <div
                        key={trx.id || idx}
                        onClick={() => setViewingTrx(trx)}
                        className="p-2.5 sm:p-3 flex items-center justify-between hover:bg-blue-50/40 active:bg-blue-50 transition-colors group cursor-pointer"
                        title="হিসাবের বিস্তারিত দেখতে বা এডিট/ডিলিট করতে ক্লিক করুন"
                      >
                        <div className="flex-1 pr-2">
                          <div className="flex items-center gap-2 flex-wrap">
                            {trx.customerName && (
                              <span className="text-[10px] bg-purple-50 text-purple-700 border border-purple-200 px-2 py-0.5 rounded font-black inline-flex items-center gap-1 shadow-2xs">
                                <span>👤</span>
                                <span>{trx.customerName}{trx.customerPhone ? ` (${trx.customerPhone})` : ''}</span>
                              </span>
                            )}
                            <span className="font-black text-xs text-slate-900 leading-tight group-hover:text-blue-600 transition-colors">
                              {trx.itemName}
                            </span>
                            {trx.category && trx.category !== 'মুদি মালামাল' && trx.category !== 'মদি মালামাল' && trx.category !== 'দোকান' && (
                              <span className="text-[9px] bg-indigo-50 text-indigo-700 border border-indigo-200 px-1.5 py-0.5 rounded font-bold">
                                {trx.category}
                              </span>
                            )}
                            {trx.quantity && (
                              <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-bold">
                                {trx.quantity}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-500 font-bold flex-wrap">
                            <span>{formatBengaliDate(trx.date)}</span>
                            <span>•</span>
                            <span>{trx.dayOfWeek || ''}</span>
                            {trx.buyPrice > 0 && (
                              <>
                                <span>•</span>
                                <span>ক্রয়: ৳{toBengaliDigits(trx.buyPrice)}</span>
                              </>
                            )}
                            {Number(trx.depositAmount) > 0 && (
                              <>
                                <span>•</span>
                                <span className="text-blue-600">জমা: ৳{toBengaliDigits(trx.depositAmount)}</span>
                              </>
                            )}
                          </div>
                        </div>

                        <div className="text-right flex items-center gap-2 shrink-0">
                          <div>
                            <span className="text-xs font-black text-emerald-700 block font-mono">
                              +{toBengaliDigits(trx.sellPrice || trx.buyPrice)} ৳
                            </span>
                            {Number(trx.dueAmount) > 0 ? (
                              <span className="text-[10px] font-bold text-amber-600 block">
                                বাকি: {toBengaliDigits(trx.dueAmount)} ৳
                              </span>
                            ) : (
                              <span className="text-[9px] font-bold text-emerald-600 block">
                                পরিশোধিত ✓
                              </span>
                            )}
                          </div>

                          <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-blue-500 transition-colors shrink-0" />
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* 4.2 CUSTOMER LEDGER LIST */}
              {activeCategory === 'customer' && (
                <div className="divide-y divide-slate-100">
                  {filteredCustomers.length === 0 ? (
                    <div className="p-8 text-center text-slate-400 space-y-1">
                      <Users className="w-8 h-8 mx-auto text-slate-300" />
                      <p className="text-xs font-bold text-slate-600">কোনো কাস্টমার নেই</p>
                      <p className="text-[11px]">+ কাস্টমার যোগ বাটন দিয়ে হিসাব শুরু করুন</p>
                    </div>
                  ) : (
                    filteredCustomers.map((cust) => {
                      const txs = cust.transactions || [];
                      const cSell = txs.reduce((acc, t) => acc + (Number(t.sellPrice) || 0), 0);
                      const cDeposit = txs.reduce((acc, t) => acc + (Number(t.depositAmount) || 0), 0);
                      const cDue = Math.max(0, cSell - cDeposit);

                      return (
                        <div
                          key={cust.id}
                          onClick={() => {
                            setSelectedCustomer(cust);
                            setIsCustomerDetailModalOpen(true);
                          }}
                          className="p-2.5 sm:p-3 flex items-center justify-between hover:bg-slate-50 active:bg-slate-100 transition-colors cursor-pointer"
                          title="কাস্টমার খাতা দেখতে ক্লিক করুন"
                        >
                          <div className="flex-1 pr-2">
                            <div className="flex items-center gap-1.5">
                              <span className="font-black text-xs text-slate-900 leading-tight">
                                {cust.name}
                              </span>
                              {cDue > 0 && (
                                <span className="text-[9px] bg-rose-100 text-rose-800 font-black px-1.5 py-0.2 rounded-full">
                                  বকেয়া আছে
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2 mt-0.5 text-[10px] text-slate-500 font-bold">
                              <span>{cust.phone}</span>
                              <span>•</span>
                              <span>লেনদেন: {toBengaliDigits(txs.length)}টি</span>
                            </div>
                          </div>

                          <div className="text-right flex items-center gap-2 shrink-0">
                            <div>
                              <span
                                className={`text-xs font-black block font-mono ${
                                  cDue > 0 ? 'text-rose-600' : 'text-emerald-700'
                                }`}
                              >
                                {cDue > 0 ? `বাকি: ${formatTaka(cDue)} ৳` : 'পরিশোধিত ✓'}
                              </span>
                              {cDeposit > 0 && (
                                <span className="text-[10px] font-bold text-slate-500 block">
                                  জমা: {formatTaka(cDeposit)} ৳
                                </span>
                              )}
                            </div>
                            <ChevronRight className="w-4 h-4 text-slate-300" />
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              )}

              {/* 4.3 PERSONAL LEDGER LIST */}
              {activeCategory === 'personal' && (
                <div className="divide-y divide-slate-100">
                  {filteredPersonalTransactions.length === 0 ? (
                    <div className="p-8 text-center text-slate-400 space-y-1">
                      <User className="w-8 h-8 mx-auto text-slate-300" />
                      <p className="text-xs font-bold text-slate-600">কোনো ব্যক্তিগত খরচ নেই</p>
                      <p className="text-[11px]">+ হিসাব যোগ বাটন দিয়ে এন্ট্রি করুন</p>
                    </div>
                  ) : (
                    filteredPersonalTransactions.map((trx, idx) => (
                      <div
                        key={trx.id || idx}
                        onClick={() => setViewingTrx(trx)}
                        className="p-2.5 sm:p-3 flex items-center justify-between hover:bg-rose-50/40 active:bg-rose-50 transition-colors group cursor-pointer"
                        title="হিসাবের বিস্তারিত দেখতে বা এডিট/ডিলিট করতে ক্লিক করুন"
                      >
                        <div
                          className="flex-1 pr-2"
                        >
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-black text-xs text-slate-900 leading-tight group-hover:text-rose-600 transition-colors">
                              {trx.itemName}
                            </span>
                            {trx.quantity && (
                              <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded font-bold">
                                {trx.quantity}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-2 mt-0.5 text-[10px] text-slate-500 font-bold flex-wrap">
                            <span>{formatBengaliDate(trx.date)}</span>
                            <span>•</span>
                            <span>{trx.dayOfWeek || ''}</span>
                            {trx.note && (
                              <>
                                <span>•</span>
                                <span className="truncate max-w-[120px]">{trx.note}</span>
                              </>
                            )}
                          </div>
                        </div>

                        <div className="text-right flex items-center gap-2 shrink-0">
                          <div>
                            <span className="text-xs font-black text-rose-600 block font-mono">
                              -{toBengaliDigits(trx.buyPrice || trx.sellPrice)} ৳
                            </span>
                            {Number(trx.depositAmount) > 0 && (
                              <span className="text-[10px] font-bold text-emerald-600 block">
                                জমা: {toBengaliDigits(trx.depositAmount)} ৳
                              </span>
                            )}
                          </div>

                          <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-rose-500 transition-colors shrink-0" />
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
        </section>
      </main>

      {/* ========================================================================= */}
      {/* 5. UNIFIED PDF & SHARE MODAL (১ দিন থেকে ৩১ দিন পর্যন্ত সময় নির্বাচন)      */}
      {/* ========================================================================= */}
      {isShareModalOpen && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-end sm:items-center justify-center z-50 p-0 sm:p-4 animate-fadeIn">
          <div className="w-full sm:max-w-lg bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
            {/* Modal Header */}
            <div className="p-3 bg-gradient-to-r from-[#0d2847] to-[#163a66] text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Share2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-black leading-tight">
                    {activeCategory === 'shop'
                      ? '🏪 দোকানের হিসাব'
                      : activeCategory === 'customer'
                      ? '👥 কাস্টমার হিসাব'
                      : '👤 ব্যক্তিগত হিসাব'}{' '}
                    - PDF রিপোর্ট ও শেয়ার
                  </h3>
                  <p className="text-[10px] text-slate-300">
                    ১ দিন থেকে সর্বোচ্চ ৩১ দিনের হিসাব নির্বাচন ও PDF প্রস্তুত
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsShareModalOpen(false)}
                className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-3.5 space-y-3.5 overflow-y-auto">
              {/* 5.1: সময়কাল নির্বাচন (১ দিন থেকে ৩১ দিন পর্যন্ত স্লাইডার ও চিপস) */}
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/90 space-y-2.5">
                <div className="flex items-center justify-between text-xs font-black text-slate-800">
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-blue-600" />
                    <span>সময়কাল নির্বাচন করুন:</span>
                  </span>
                  <span className="bg-blue-600 text-white px-2 py-0.5 rounded-full text-[11px] font-black font-mono">
                    {toBengaliDigits(shareDaysRange)} দিন (সর্বোচ্চ ৩১ দিন)
                  </span>
                </div>

                {/* Day Slider (1 to 31) */}
                <div className="space-y-1">
                  <input
                    type="range"
                    min="1"
                    max="31"
                    value={shareDaysRange}
                    onChange={(e) => setShareDaysRange(parseInt(e.target.value, 10))}
                    className="w-full accent-blue-600 h-2 bg-slate-200 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] font-bold text-slate-400">
                    <span>১ দিন</span>
                    <span>৭ দিন</span>
                    <span>১৫ দিন</span>
                    <span>২১ দিন</span>
                    <span>৩১ দিন</span>
                  </div>
                </div>

                {/* Quick Preset Buttons */}
                <div className="grid grid-cols-4 gap-1.5 pt-1">
                  {[
                    { label: 'আজ (১ দিন)', days: 1 },
                    { label: 'গত ৭ দিন', days: 7 },
                    { label: 'গত ১৫ দিন', days: 15 },
                    { label: 'গত ৩১ দিন', days: 31 },
                  ].map((p) => (
                    <button
                      key={p.days}
                      type="button"
                      onClick={() => setShareDaysRange(p.days)}
                      className={`py-1.5 px-1 rounded-xl text-[10px] font-black transition-all cursor-pointer text-center ${
                        shareDaysRange === p.days
                          ? 'bg-blue-600 text-white shadow-2xs'
                          : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 5.2: নির্বাচিত সময়ের হিসাব সারসংক্ষেপ */}
              <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-3 space-y-2">
                <div className="flex items-center justify-between text-xs font-black text-emerald-950">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    <span>নির্বাচিত {toBengaliDigits(shareDaysRange)} দিনের মোট সারসংক্ষেপ:</span>
                  </span>
                  <span className="text-[11px] font-bold bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded-full">
                    {toBengaliDigits(shareFilteredItems.length)} টি হিসাব
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-white p-2 rounded-xl border border-emerald-100">
                    <span className="text-[10px] text-slate-500 font-bold block">
                      {activeCategory === 'shop'
                        ? 'মোট ক্রয়'
                        : activeCategory === 'customer'
                        ? 'মোট বিক্রি'
                        : 'মোট খরচ'}
                    </span>
                    <span className="font-black text-slate-900 font-mono">
                      {formatTaka(shareRangeTotals.col1)} ৳
                    </span>
                  </div>

                  <div className="bg-white p-2 rounded-xl border border-emerald-100">
                    <span className="text-[10px] text-slate-500 font-bold block">
                      {activeCategory === 'shop'
                        ? 'মোট বিক্রি'
                        : activeCategory === 'customer'
                        ? 'মোট জমা প্রাপ্তি'
                        : 'নগদ জমা'}
                    </span>
                    <span className="font-black text-emerald-700 font-mono">
                      {formatTaka(shareRangeTotals.col2)} ৳
                    </span>
                  </div>

                  <div className="bg-white p-2 rounded-xl border border-emerald-100">
                    <span className="text-[10px] text-slate-500 font-bold block">মোট বাকি</span>
                    <span className="font-black text-amber-600 font-mono">
                      {formatTaka(shareRangeTotals.col3)} ৳
                    </span>
                  </div>

                  <div className="bg-white p-2 rounded-xl border border-emerald-100">
                    <span className="text-[10px] text-slate-500 font-bold block">
                      {activeCategory === 'shop' ? 'নিট লাভ' : 'অবশিষ্ট'}
                    </span>
                    <span className="font-black text-blue-600 font-mono">
                      {formatTaka(shareRangeTotals.col4)} ৳
                    </span>
                  </div>
                </div>
              </div>

              {/* 5.3: এক্সপোর্ট ও শেয়ার অপশনস */}
              <div className="space-y-2 pt-1">
                {/* 1. PDF Download */}
                <button
                  type="button"
                  id="btn-download-pdf"
                  disabled={isDownloadingPdf}
                  onClick={handleDownloadPdf}
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-md flex items-center justify-center gap-2 transition-all active:scale-98 cursor-pointer disabled:opacity-50"
                >
                  <Download className="w-4 h-4" />
                  <span>
                    {isDownloadingPdf
                      ? 'PDF তৈরি হচ্ছে...'
                      : `ডাটা PDF ফাইল হিসেবে ডাউনলোড করুন (${toBengaliDigits(shareDaysRange)} দিন)`}
                  </span>
                </button>

                {/* 2. Google Drive & Google Sheets Options */}
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    id="btn-save-google-drive"
                    disabled={isDownloadingPdf}
                    onClick={handleSaveToGoogleDrive}
                    className="py-2.5 px-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 transition-all active:scale-98 cursor-pointer disabled:opacity-50"
                    title="গুগল ড্রাইভে আলাদাভাবে হিসাব সংগ্রহ ও সংরক্ষণ করুন"
                  >
                    <Cloud className="w-4 h-4 text-amber-300" />
                    <span>গুগল ড্রাইভ</span>
                  </button>

                  <button
                    type="button"
                    id="btn-save-google-sheet"
                    onClick={handleSaveToGoogleSheet}
                    className="py-2.5 px-2 bg-gradient-to-r from-emerald-700 to-teal-700 hover:from-emerald-800 hover:to-teal-800 text-white font-black text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 transition-all active:scale-98 cursor-pointer"
                    title="গুগল শীটে আলাদাভাবে হিসাব সংগ্রহ ও সংরক্ষণ করুন"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
                    <span>গুগল শীট</span>
                  </button>
                </div>

                {/* Cloud Guide & Direct Link Banner */}
                {cloudPromptType === 'drive' && (
                  <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-xl text-xs space-y-1.5 animate-fadeIn">
                    <div className="flex items-center gap-1.5 text-blue-950 font-bold">
                      <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                      <span>গুগল ড্রাইভের জন্য PDF ফাইল ডাউনলোড হয়েছে!</span>
                    </div>
                    <p className="text-[11px] text-blue-700 leading-relaxed">
                      ফাইলটি আপনার ডিভাইসে সেভ হয়েছে। গুগল ড্রাইভে আপলোড করে রাখতে নিচের লিংকে যান:
                    </p>
                    <a
                      href="https://drive.google.com/drive/u/0/my-drive"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-xs shadow-2xs"
                    >
                      <Cloud className="w-3.5 h-3.5 text-amber-300" />
                      <span>গুগল ড্রাইভ খুলুন</span>
                      <ExternalLink className="w-3 h-3 ml-0.5" />
                    </a>
                  </div>
                )}

                {cloudPromptType === 'sheet' && (
                  <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs space-y-1.5 animate-fadeIn">
                    <div className="flex items-center gap-1.5 text-emerald-950 font-bold">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>গুগল শীট স্প্রেডশীট (.csv) ফাইল ডাউনলোড হয়েছে!</span>
                    </div>
                    <p className="text-[11px] text-emerald-700 leading-relaxed">
                      বাংলা ফন্ট সমর্থিত ফাইলটি প্রস্তুত হয়েছে। গুগল শীট ওয়েব পেজে ওপেন করতে নিচের লিংকে যান:
                    </p>
                    <a
                      href="https://docs.google.com/spreadsheets/u/0/create"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-bold text-xs shadow-2xs"
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-200" />
                      <span>গুগল শীট খুলুন</span>
                      <ExternalLink className="w-3 h-3 ml-0.5" />
                    </a>
                  </div>
                )}

                {/* 3. Additional Sharing */}
                <div className="grid grid-cols-3 gap-2 pt-0.5">
                  <button
                    type="button"
                    onClick={handleWhatsAppShare}
                    className="py-2 bg-green-50 hover:bg-green-100 text-green-700 border border-green-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-colors cursor-pointer"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>হোয়াটসঅ্যাপ</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleDeviceShare}
                    className="py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-colors cursor-pointer"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>শেয়ার</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => window.print()}
                    className="py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-colors cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>প্রিন্ট</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. HIDDEN PDF RENDER CONTAINER (For html2pdf.js generation)                */}
      {/* ========================================================================= */}
      <div id="tally-pdf-render-root" className="hidden bg-white text-slate-900 p-8 font-sans">
        {/* Header */}
        <div style={{ textAlign: 'center', borderBottom: '2px solid #0d2847', paddingBottom: '12px', marginBottom: '16px' }}>
          <h1 style={{ fontSize: '20px', fontWeight: 'bold', color: '#0d2847', margin: 0 }}>
            {user?.shopName || 'টালি খাতা হিসাব বিবরণী'}
          </h1>
          <p style={{ fontSize: '13px', fontWeight: 'bold', color: '#475569', marginTop: '4px' }}>
            {activeCategory === 'shop'
              ? 'দোকানের হিসাব বিবরণী'
              : activeCategory === 'customer'
              ? 'কাস্টমারদের বাকি ও জমা খাতা'
              : 'ব্যক্তিগত আয়-ব্যয় বিবরণী'}{' '}
            • বিগত {toBengaliDigits(shareDaysRange)} দিনের পূর্ণাঙ্গ হিসাব
          </p>
          <p style={{ fontSize: '11px', color: '#64748b', marginTop: '2px' }}>
            তারিখ: {formatBengaliDate(getTodayDateFormatted())}
          </p>
        </div>

        {/* 4 Summary Boxes for PDF */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '10px', marginBottom: '16px' }}>
          <div style={{ padding: '8px', border: '1px solid #cbd5e1', borderRadius: '8px', textAlign: 'center', background: '#f8fafc' }}>
            <span style={{ fontSize: '10px', color: '#64748b', display: 'block', fontWeight: 'bold' }}>
              {activeCategory === 'shop' ? 'মোট ক্রয়' : activeCategory === 'customer' ? 'মোট বিক্রি' : 'মোট খরচ'}
            </span>
            <span style={{ fontSize: '14px', fontWeight: 'bold', color: '#dc2626' }}>
              ৳{formatTaka(shareRangeTotals.col1)}
            </span>
          </div>

          <div style={{ padding: '8px', border: '1px solid #cbd5e1', borderRadius: '8px', textAlign: 'center', background: '#f8fafc' }}>
            <span style={{ fontSize: '10px', color: '#64748b', display: 'block', fontWeight: 'bold' }}>
              {activeCategory === 'shop' ? 'মোট বিক্রি' : activeCategory === 'customer' ? 'জমা প্রাপ্তি' : 'নগদ জমা'}
            </span>
            <span style={{ fontSize: '14px', fontWeight: 'bold', color: '#16a34a' }}>
              ৳{formatTaka(shareRangeTotals.col2)}
            </span>
          </div>

          <div style={{ padding: '8px', border: '1px solid #cbd5e1', borderRadius: '8px', textAlign: 'center', background: '#f8fafc' }}>
            <span style={{ fontSize: '10px', color: '#64748b', display: 'block', fontWeight: 'bold' }}>
              মোট বাকি
            </span>
            <span style={{ fontSize: '14px', fontWeight: 'bold', color: '#d97706' }}>
              ৳{formatTaka(shareRangeTotals.col3)}
            </span>
          </div>

          <div style={{ padding: '8px', border: '1px solid #cbd5e1', borderRadius: '8px', textAlign: 'center', background: '#f8fafc' }}>
            <span style={{ fontSize: '10px', color: '#64748b', display: 'block', fontWeight: 'bold' }}>
              {activeCategory === 'shop' ? 'নিট লাভ' : 'অবশিষ্ট'}
            </span>
            <span style={{ fontSize: '14px', fontWeight: 'bold', color: '#2563eb' }}>
              ৳{formatTaka(shareRangeTotals.col4)}
            </span>
          </div>
        </div>

        {/* Detailed Table */}
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '11px', textAlign: 'left' }}>
          <thead>
            <tr style={{ background: '#0d2847', color: '#ffffff' }}>
              <th style={{ padding: '6px 8px', border: '1px solid #0d2847' }}>ক্রম</th>
              <th style={{ padding: '6px 8px', border: '1px solid #0d2847' }}>তারিখ</th>
              <th style={{ padding: '6px 8px', border: '1px solid #0d2847' }}>বিবরণ / নাম</th>
              <th style={{ padding: '6px 8px', border: '1px solid #0d2847', textAlign: 'right' }}>খরচ / ক্রয়</th>
              <th style={{ padding: '6px 8px', border: '1px solid #0d2847', textAlign: 'right' }}>বিক্রি / জমা</th>
              <th style={{ padding: '6px 8px', border: '1px solid #0d2847', textAlign: 'right' }}>বাকি</th>
            </tr>
          </thead>
          <tbody>
            {shareFilteredItems.map((item: any, i) => (
              <tr key={i} style={{ background: i % 2 === 0 ? '#ffffff' : '#f8fafc' }}>
                <td style={{ padding: '6px 8px', border: '1px solid #e2e8f0' }}>{toBengaliDigits(i + 1)}</td>
                <td style={{ padding: '6px 8px', border: '1px solid #e2e8f0' }}>{formatBengaliDate(item.date)}</td>
                <td style={{ padding: '6px 8px', border: '1px solid #e2e8f0', fontWeight: 'bold' }}>
                  {item.customerName ? `${item.customerName} (${item.itemName})` : item.itemName}
                </td>
                <td style={{ padding: '6px 8px', border: '1px solid #e2e8f0', textAlign: 'right' }}>
                  ৳{toBengaliDigits(item.buyPrice || 0)}
                </td>
                <td style={{ padding: '6px 8px', border: '1px solid #e2e8f0', textAlign: 'right', color: '#16a34a' }}>
                  ৳{toBengaliDigits(item.sellPrice || item.depositAmount || 0)}
                </td>
                <td style={{ padding: '6px 8px', border: '1px solid #e2e8f0', textAlign: 'right', color: '#d97706' }}>
                  ৳{toBengaliDigits(item.dueAmount || 0)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Footer */}
        <div style={{ marginTop: '24px', paddingTop: '12px', borderTop: '1px solid #cbd5e1', display: 'flex', justifyContent: 'space-between', fontSize: '10px', color: '#64748b' }}>
          <span>প্রস্তুতকারী: ডিজিটাল টালি খাতা সিস্টেম</span>
          <span>স্বাক্ষর: ............................................</span>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 7. MODALS (View Details, Add/Edit Transaction, Add Customer, Customer Detail) */}
      {/* ========================================================================= */}

      {/* 7.0 VIEW TRANSACTION DETAIL MODAL (Opens when clicking any shop or personal transaction row) */}
      {viewingTrx && (() => {
        const isPersonal = viewingTrx.category === 'ব্যক্তিগত';
        const buy = Number(viewingTrx.buyPrice) || 0;
        const sell = Number(viewingTrx.sellPrice) || (isPersonal ? buy : 0);
        const deposit = Number(viewingTrx.depositAmount) || 0;
        const due = viewingTrx.dueAmount !== undefined && !isNaN(Number(viewingTrx.dueAmount))
          ? Number(viewingTrx.dueAmount)
          : Math.max(0, (isPersonal ? buy : sell) - deposit);
        const profit = Number(viewingTrx.profit) || (isPersonal ? 0 : Math.max(0, sell - buy));

        return (
          <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-end sm:items-center justify-center z-50 p-0 sm:p-4 animate-fadeIn">
            <div className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
              {/* Modal Header */}
              <div className="p-3.5 bg-gradient-to-r from-[#0d2847] to-[#163a66] text-white flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center text-white">
                    {isPersonal ? <User className="w-4 h-4 text-amber-300" /> : <Store className="w-4 h-4 text-emerald-300" />}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h3 className="text-xs font-black">
                        {isPersonal ? 'ব্যক্তিগত হিসাব বিবরণ' : 'দোকানের হিসাব বিবরণ'}
                      </h3>
                      <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-full ${isPersonal ? 'bg-amber-400/20 text-amber-200' : 'bg-emerald-400/20 text-emerald-200'}`}>
                        {isPersonal ? 'ব্যক্তিগত' : 'দোকান'}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-300">
                      তারিখ: {formatBengaliDate(viewingTrx.date)} {viewingTrx.time ? `• ${viewingTrx.time}` : ''}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleOpenEditModal(viewingTrx)}
                    className="px-2.5 py-1 rounded-xl bg-blue-500 hover:bg-blue-600 active:scale-95 text-white font-bold text-xs flex items-center gap-1 shadow-xs transition-all cursor-pointer"
                    title="এই হিসাবটি এডিট করুন"
                  >
                    <Edit2 className="w-3 h-3" />
                    <span>এডিট</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setViewingTrx(null)}
                    className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white cursor-pointer transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Modal Body */}
              <div className="p-4 space-y-3.5 overflow-y-auto">
                {/* Item Details Banner */}
                <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[10px] text-slate-500 font-bold block mb-0.5">হিসাবের বিবরণ / নাম</span>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {viewingTrx.customerName && (
                          <span className="text-xs bg-purple-50 text-purple-700 px-2 py-0.5 rounded-lg font-bold border border-purple-200 shrink-0">
                            👤 {viewingTrx.customerName}{viewingTrx.customerPhone ? ` (${viewingTrx.customerPhone})` : ''}
                          </span>
                        )}
                        <h4 className="text-sm font-black text-slate-900 leading-tight">
                          {viewingTrx.itemName}
                        </h4>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 flex-wrap justify-end">
                      {viewingTrx.quantity && (
                        <span className="text-xs bg-white text-slate-700 px-2.5 py-1 rounded-xl font-bold border border-slate-200 shrink-0">
                          পরিমাণ: {viewingTrx.quantity}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mt-2 pt-2 border-t border-slate-200/70 text-[11px] text-slate-600 font-bold flex-wrap">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-blue-600" />
                      {formatBengaliDate(viewingTrx.date)}
                    </span>
                    <span>•</span>
                    <span>{viewingTrx.dayOfWeek || getBengaliDayOfWeek(viewingTrx.date)}</span>
                    {viewingTrx.time && (
                      <>
                        <span>•</span>
                        <span className="flex items-center gap-1 text-slate-400">
                          <Clock className="w-3.5 h-3.5" />
                          {viewingTrx.time}
                        </span>
                      </>
                    )}
                  </div>
                </div>

                {/* Financial Summary Grid */}
                <div className="grid grid-cols-2 gap-2">
                  {isPersonal ? (
                    <>
                      <div className="p-3 bg-rose-50/70 border border-rose-100 rounded-2xl text-center">
                        <span className="text-[10px] text-rose-600 font-bold block">মোট খরচ</span>
                        <span className="text-base font-black text-rose-700 font-mono">
                          ৳{toBengaliDigits(buy || sell)}
                        </span>
                      </div>
                      <div className="p-3 bg-emerald-50/70 border border-emerald-100 rounded-2xl text-center">
                        <span className="text-[10px] text-emerald-600 font-bold block">পরিশোধ / জমা</span>
                        <span className="text-base font-black text-emerald-700 font-mono">
                          ৳{toBengaliDigits(deposit)}
                        </span>
                      </div>
                      {due > 0 && (
                        <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-center col-span-2">
                          <span className="text-[10px] text-amber-700 font-bold block">বকেয়া / বাকি</span>
                          <span className="text-sm font-black text-amber-600 font-mono">
                            ৳{toBengaliDigits(due)}
                          </span>
                        </div>
                      )}
                    </>
                  ) : (
                    <>
                      <div className="p-2.5 bg-slate-50 border border-slate-200/80 rounded-xl text-center">
                        <span className="text-[10px] text-slate-500 font-bold block">ক্রয়মূল্য / খরচ</span>
                        <span className="text-sm font-black text-slate-700 font-mono">
                          ৳{toBengaliDigits(buy)}
                        </span>
                      </div>
                      <div className="p-2.5 bg-emerald-50/70 border border-emerald-100 rounded-xl text-center">
                        <span className="text-[10px] text-emerald-600 font-bold block">বিক্রিমূল্য</span>
                        <span className="text-sm font-black text-emerald-700 font-mono">
                          ৳{toBengaliDigits(sell)}
                        </span>
                      </div>
                      <div className="p-2.5 bg-blue-50/70 border border-blue-100 rounded-xl text-center">
                        <span className="text-[10px] text-blue-600 font-bold block">নগদ জমা</span>
                        <span className="text-sm font-black text-blue-700 font-mono">
                          ৳{toBengaliDigits(deposit)}
                        </span>
                      </div>
                      <div className="p-2.5 bg-amber-50/70 border border-amber-200 rounded-xl text-center">
                        <span className="text-[10px] text-amber-700 font-bold block">কাস্টমার বাকি</span>
                        <span className={`text-sm font-black font-mono ${due > 0 ? 'text-amber-600' : 'text-slate-400'}`}>
                          {due > 0 ? `৳${toBengaliDigits(due)}` : '০ ৳ (পরিশোধিত)'}
                        </span>
                      </div>
                      {profit > 0 && (
                        <div className="p-2 bg-emerald-100/60 border border-emerald-200 rounded-xl text-center col-span-2">
                          <span className="text-[10px] text-emerald-800 font-bold block">মুনাফা / লাভ</span>
                          <span className="text-xs font-black text-emerald-700 font-mono">
                            +৳{toBengaliDigits(profit)}
                          </span>
                        </div>
                      )}
                    </>
                  )}
                </div>

                {/* Optional Note */}
                {viewingTrx.note && (
                  <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs text-slate-700">
                    <span className="font-bold text-slate-500 block text-[10px] mb-0.5">নোট / মন্তব্য:</span>
                    <p className="font-medium">{viewingTrx.note}</p>
                  </div>
                )}

                {/* Primary Action Buttons: EDIT & DELETE */}
                <div className="pt-2 space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => handleOpenEditModal(viewingTrx)}
                      className="py-3 px-3 bg-blue-600 hover:bg-blue-700 active:scale-98 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 shadow-md shadow-blue-600/20 transition-all cursor-pointer"
                      title="এই হিসাবটি এডিট বা পরিবর্তন করুন"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                      <span>এডিট করুন</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const idToDelete = viewingTrx.id;
                        setViewingTrx(null);
                        setDeleteConfirmId(idToDelete);
                        setDeleteConfirmType(isPersonal ? 'personal' : 'shop_trx');
                      }}
                      className="py-3 px-3 bg-rose-600 hover:bg-rose-700 active:scale-98 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 shadow-md shadow-rose-600/20 transition-all cursor-pointer"
                      title="এই হিসাবটি ডিলিট করুন"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-white" />
                      <span>ডিলিট করুন</span>
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => setViewingTrx(null)}
                    className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 active:scale-98 text-slate-600 font-bold text-xs rounded-xl cursor-pointer transition-colors"
                  >
                    বন্ধ করুন
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* 7.1 ADD / EDIT SHOP & PERSONAL TRANSACTION MODAL */}
      {isAddModalOpen && (() => {
        const isModalPersonal = editingTrx
          ? (editingTrx.category === 'ব্যক্তিগত' || editingTrx.category === 'personal')
          : activeCategory === 'personal';
        return (
          <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-end sm:items-center justify-center z-50 p-0 sm:p-4 animate-fadeIn">
            <div className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
              <div className="p-3 bg-[#0d2847] text-white flex items-center justify-between">
                <h3 className="text-xs font-black">
                  {editingTrx
                    ? (isModalPersonal ? 'ব্যক্তিগত খরচ সম্পাদনা করুন' : 'দোকানের হিসাব সম্পাদনা করুন')
                    : isModalPersonal
                    ? 'ব্যক্তিগত খরচ যোগ'
                    : 'দোকানের হিসাব যোগ'}
                </h3>
                <button
                  type="button"
                  onClick={() => {
                    setEditingTrx(null);
                    setIsAddModalOpen(false);
                  }}
                  className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveTransaction} className="p-4 space-y-3 max-h-[85vh] overflow-y-auto">
                {/* 1. PRODUCT / PURPOSE NAME */}
                {isModalPersonal ? (
                  <div className="space-y-2.5">
                    {/* নাম বাম পাশে থাকবে, পরিমাণ ডান পাশে থাকবে (ডগডাউন বাটনের ভিতরে নাম বসানোর সুবিধাসহ) */}
                    <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
                      {/* ১. খরচের নাম (বাম পাশে) */}
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[11px] font-black text-slate-800">
                            খরচের নাম *
                          </label>
                          <span className="text-[9px] text-purple-700 bg-purple-50 px-1.5 py-0.2 rounded font-bold border border-purple-200">
                            ড্রপডাউন
                          </span>
                        </div>
                        <div className="relative flex items-center bg-white border border-slate-300 rounded-xl focus-within:border-purple-600 focus-within:ring-1 focus-within:ring-purple-500 shadow-2xs overflow-hidden transition-all">
                          <input
                            type="text"
                            required
                            value={formData.itemName}
                            onChange={(e) => setFormData({ ...formData, itemName: e.target.value })}
                            placeholder="খরচের নাম লিখুন..."
                            className="flex-1 px-2.5 sm:px-3 py-2 text-xs font-bold text-slate-900 outline-none bg-transparent min-w-0"
                          />
                          {/* ড্রপডাউন বাটন - ভিতরে নাম বসানোর সুবিধাসহ */}
                          <div className="relative border-l border-slate-200 bg-slate-50 hover:bg-purple-50 transition-colors shrink-0 flex items-center">
                            <select
                              value={allPersonalExpenseOptions.includes(formData.itemName) ? formData.itemName : ''}
                              onChange={(e) => {
                                const val = e.target.value;
                                if (val === '__ADD_NEW_EXPENSE__') {
                                  setQuickNewExpenseModal(true);
                                } else if (val) {
                                  setFormData((prev) => ({ ...prev, itemName: val }));
                                }
                              }}
                              className="text-[11px] font-bold text-slate-700 py-2 pl-2 pr-6 bg-transparent outline-none cursor-pointer appearance-none max-w-[85px] sm:max-w-[110px] truncate"
                              title="ড্রপডাউন বাটন থেকে খরচের নাম বাছুন বা নতুন নাম বসান"
                            >
                              <option value="">▼ বাছুন</option>
                              <option value="__ADD_NEW_EXPENSE__" className="text-purple-700 font-bold bg-purple-50">
                                ➕ নতুন নাম বসান...
                              </option>
                              {allPersonalExpenseOptions.map((p) => (
                                <option key={p} value={p}>
                                  {p}
                                </option>
                              ))}
                            </select>
                            <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-1.5 top-2.5 pointer-events-none" />
                          </div>
                        </div>
                      </div>

                      {/* ২. পরিমাণ (ডান পাশে) */}
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[11px] font-black text-slate-800">
                            পরিমাণ
                          </label>
                          <span className="text-[9px] text-blue-700 bg-blue-50 px-1.5 py-0.2 rounded font-bold border border-blue-200">
                            ড্রপডাউন
                          </span>
                        </div>
                        <div className="relative flex items-center bg-white border border-slate-300 rounded-xl focus-within:border-blue-600 focus-within:ring-1 focus-within:ring-blue-500 shadow-2xs overflow-hidden transition-all">
                          <input
                            type="text"
                            value={formData.quantity || ''}
                            onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                            placeholder="যেমন: ১ কেজি..."
                            className="flex-1 px-2.5 sm:px-3 py-2 text-xs font-bold text-slate-900 outline-none bg-transparent min-w-0"
                          />
                          {/* ড্রপডাউন বাটন - ভিতরে পরিমাণ বসানোর সুবিধাসহ */}
                          <div className="relative border-l border-slate-200 bg-slate-50 hover:bg-blue-50 transition-colors shrink-0 flex items-center">
                            <select
                              value={savedQuantities.includes(formData.quantity || '') ? formData.quantity : ''}
                              onChange={(e) => {
                                const val = e.target.value;
                                if (val === '__ADD_NEW_QTY__') {
                                  setQuickNewQuantityModal(true);
                                } else if (val) {
                                  setFormData((prev) => ({ ...prev, quantity: val }));
                                }
                              }}
                              className="text-[11px] font-bold text-slate-700 py-2 pl-2 pr-6 bg-transparent outline-none cursor-pointer appearance-none max-w-[85px] sm:max-w-[110px] truncate"
                              title="ড্রপডাউন বাটন থেকে পরিমাণ বাছুন বা নতুন পরিমাণ বসান"
                            >
                              <option value="">▼ বাছুন</option>
                              <option value="__ADD_NEW_QTY__" className="text-blue-700 font-bold bg-blue-50">
                                ➕ নতুন পরিমাণ বসান...
                              </option>
                              {savedQuantities.map((q) => (
                                <option key={q} value={q}>
                                  {q}
                                </option>
                              ))}
                            </select>
                            <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-1.5 top-2.5 pointer-events-none" />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* ড্রপডাউনে দ্রুত নাম সেভ বা পরিচালনা বাটন */}
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between gap-1 flex-wrap">
                        <button
                          type="button"
                          onClick={() => setShowManagePersonalExpenses(!showManagePersonalExpenses)}
                          className="text-[10px] font-black text-purple-700 hover:text-purple-900 bg-purple-50 hover:bg-purple-100 border border-purple-200 px-2 py-1 rounded-xl cursor-pointer flex items-center gap-1 transition-all active:scale-95"
                        >
                          <Settings2 className="w-3 h-3 text-purple-600" />
                          <span>{showManagePersonalExpenses ? '▲ পরিচালনা বন্ধ' : '⚙️ ড্রপডাউন খরচের তালিকা পরিচালনা ও ডিলিট'}</span>
                        </button>

                        <div className="flex items-center gap-1 flex-wrap">
                          {formData.itemName?.trim() && !allPersonalExpenseOptions.includes(formData.itemName.trim()) && (
                            <button
                              type="button"
                              onClick={() => handleAddPersonalExpenseToDropdown(formData.itemName.trim())}
                              className="text-[10px] font-black text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-200 px-2 py-1 rounded-xl cursor-pointer flex items-center gap-1 transition-all active:scale-95 shadow-2xs"
                              title="বর্তমান খরচের নামটি ড্রপডাউনে সেভ করুন"
                            >
                              <Plus className="w-3 h-3 text-purple-600" />
                              <span>+ খরচের নাম সেভ</span>
                            </button>
                          )}

                          {formData.quantity?.trim() && !savedQuantities.includes(formData.quantity.trim()) && (
                            <button
                              type="button"
                              onClick={() => handleAddCustomQuantityToDropdown(formData.quantity.trim())}
                              className="text-[10px] font-black text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 px-2 py-1 rounded-xl cursor-pointer flex items-center gap-1 transition-all active:scale-95 shadow-2xs"
                              title="বর্তমান পরিমাণটি ড্রপডাউনে সেভ করুন"
                            >
                              <Plus className="w-3 h-3 text-blue-600" />
                              <span>+ পরিমাণ সেভ</span>
                            </button>
                          )}
                        </div>
                      </div>

                      {/* ড্রপডাউন খরচের নাম পরিচালনা প্যানেল */}
                      {showManagePersonalExpenses && (
                        <div className="p-2.5 bg-purple-50/60 border border-purple-200 rounded-2xl space-y-2 animate-fadeIn">
                          <div className="flex items-center justify-between">
                            <span className="text-[11px] font-black text-purple-900">
                              ড্রপডাউন খরচের তালিকা ({savedPersonalExpenses.length})
                            </span>
                            <span className="text-[9px] text-slate-500">
                              (নামে চাপ দিলে ইনপুটে বসবে, × চাপলে ড্রপডাউন থেকে মুছবে)
                            </span>
                          </div>

                          <div className="flex items-center gap-1.5">
                            <input
                              type="text"
                              value={quickNewExpenseInput}
                              onChange={(e) => setQuickNewExpenseInput(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  handleAddPersonalExpenseToDropdown();
                                }
                              }}
                              placeholder="ড্রপডাউনে নতুন নাম বসান..."
                              className="flex-1 px-2.5 py-1.5 bg-white border border-purple-200 rounded-xl text-xs font-bold text-slate-900 outline-none focus:border-purple-600 shadow-2xs"
                            />
                            <button
                              type="button"
                              onClick={() => handleAddPersonalExpenseToDropdown()}
                              className="px-2.5 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-black shrink-0 flex items-center gap-1 cursor-pointer active:scale-95 shadow-2xs"
                            >
                              <Plus className="w-3.5 h-3.5" />
                              <span>যোগ করুন</span>
                            </button>
                          </div>

                          <div className="flex items-center gap-1.5 flex-wrap max-h-32 overflow-y-auto p-1.5 bg-white border border-purple-100 rounded-xl">
                            {savedPersonalExpenses.map((exp) => (
                              <span
                                key={exp}
                                className="inline-flex items-center gap-1 px-2 py-0.5 bg-purple-50 text-purple-900 rounded-lg text-[11px] font-bold border border-purple-200"
                              >
                                <span
                                  className="cursor-pointer hover:text-purple-700"
                                  onClick={() => setFormData((prev) => ({ ...prev, itemName: exp }))}
                                  title="ইনপুটে বসাতে ক্লিক করুন"
                                >
                                  {exp}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => handleDeletePersonalExpenseFromDropdown(exp)}
                                  className="w-3.5 h-3.5 rounded-full hover:bg-rose-600 hover:text-white text-purple-400 flex items-center justify-center cursor-pointer transition-colors"
                                  title={`"${exp}" ড্রপডাউন থেকে মুছে ফেলুন`}
                                >
                                  <X className="w-2.5 h-2.5" />
                                </button>
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <>
                    {/* ডাটা এন্ট্রি ঘরগুলো: ১) প্রোডাক্ট নাম ২) পরিমাণ ৩) কাস্টমার নাম/মোবাইল নাম্বার - প্রতিটির ভিতরে ড্রপডাউন বাটন */}
                    <div className="space-y-2.5">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {/* বক্স ১: প্রোডাক্ট নাম (ভিতরে ড্রপডাউন) */}
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="text-[11px] font-black text-slate-800">
                              প্রোডাক্ট নাম *
                            </label>
                            <span className="text-[9px] text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded font-bold border border-emerald-200">
                              ভিতরে ড্রপডাউন
                            </span>
                          </div>
                          <div className="relative flex items-center bg-white border border-slate-300 rounded-xl focus-within:border-emerald-600 focus-within:ring-1 focus-within:ring-emerald-500 shadow-2xs overflow-hidden transition-all">
                            <input
                              type="text"
                              required
                              value={formData.itemName}
                              onChange={(e) => setFormData({ ...formData, itemName: e.target.value })}
                              placeholder="প্রোডাক্টের নাম লিখুন..."
                              className="flex-1 px-3 py-2 text-xs font-bold text-slate-900 outline-none bg-transparent min-w-0"
                            />
                            {/* ইনপুটের ভিতরেই ড্রপডাউন বাটন */}
                            <div className="relative border-l border-slate-200 bg-slate-50 hover:bg-emerald-50 transition-colors shrink-0">
                              <select
                                value={savedProducts.includes(formData.itemName) ? formData.itemName : ''}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  if (val === '__ADD_NEW_PROD__') {
                                    setShowManageProducts(true);
                                    setDropdownManageTab('products');
                                  } else if (val) {
                                    setFormData((prev) => ({ ...prev, itemName: val }));
                                  }
                                }}
                                className="text-[11px] font-bold text-slate-700 py-2 pl-2 pr-6 bg-transparent outline-none cursor-pointer appearance-none max-w-[110px] truncate"
                                title="তালিকা থেকে প্রোডাক্ট বাছাই করুন বা নতুন নাম বসান"
                              >
                                <option value="">▼ বাছুন</option>
                                <option value="__ADD_NEW_PROD__" className="text-emerald-700 font-bold bg-emerald-50">
                                  ➕ নতুন প্রোডাক্ট বসান...
                                </option>
                                {savedProducts.map((p) => (
                                  <option key={p} value={p}>
                                    {p}
                                  </option>
                                ))}
                              </select>
                              <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-1.5 top-2.5 pointer-events-none" />
                            </div>
                          </div>
                        </div>

                        {/* বক্স ২: পরিমাণ (ভিতরে ড্রপডাউন) */}
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="text-[11px] font-black text-slate-800">
                              পরিমাণ
                            </label>
                            <span className="text-[9px] text-blue-700 bg-blue-50 px-1.5 py-0.2 rounded font-bold border border-blue-200">
                              ভিতরে ড্রপডাউন
                            </span>
                          </div>
                          <div className="relative flex items-center bg-white border border-slate-300 rounded-xl focus-within:border-blue-600 focus-within:ring-1 focus-within:ring-blue-500 shadow-2xs overflow-hidden transition-all">
                            <input
                              type="text"
                              value={formData.quantity || ''}
                              onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                              placeholder="যেমন: ১ কেজি, ২ পিস..."
                              className="flex-1 px-3 py-2 text-xs font-bold text-slate-900 outline-none bg-transparent min-w-0"
                            />
                            {/* ইনপুটের ভিতরেই ড্রপডাউন বাটন */}
                            <div className="relative border-l border-slate-200 bg-slate-50 hover:bg-blue-50 transition-colors shrink-0">
                              <select
                                value={savedQuantities.includes(formData.quantity || '') ? formData.quantity : ''}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  if (val === '__ADD_NEW_QTY__') {
                                    setShowManageProducts(true);
                                    setDropdownManageTab('quantities');
                                  } else if (val) {
                                    setFormData((prev) => ({ ...prev, quantity: val }));
                                  }
                                }}
                                className="text-[11px] font-bold text-slate-700 py-2 pl-2 pr-6 bg-transparent outline-none cursor-pointer appearance-none max-w-[110px] truncate"
                                title="তালিকা থেকে পরিমাণ বাছাই করুন বা নতুন পরিমাণ বসান"
                              >
                                <option value="">▼ বাছুন</option>
                                <option value="__ADD_NEW_QTY__" className="text-blue-700 font-bold bg-blue-50">
                                  ➕ নতুন পরিমাণ বসান...
                                </option>
                                {savedQuantities.map((q) => (
                                  <option key={q} value={q}>
                                    {q}
                                  </option>
                                ))}
                              </select>
                              <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-1.5 top-2.5 pointer-events-none" />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* বক্স ৩: কাস্টমার নাম / মোবাইল নাম্বার (ঘরের ডান পাশে Dropdown ▼ বাটন) */}
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[11px] font-black text-slate-800">
                            কাস্টমার নাম / মোবাইল নাম্বার
                          </label>
                          <span className="text-[9px] text-purple-700 bg-purple-50 px-1.5 py-0.2 rounded font-bold border border-purple-200">
                            ভিতরে ড্রপডাউন
                          </span>
                        </div>
                        <div className="relative flex items-center bg-white border border-slate-300 rounded-xl focus-within:border-purple-600 focus-within:ring-1 focus-within:ring-purple-500 shadow-2xs overflow-hidden transition-all">
                          <input
                            type="text"
                            value={formData.customerInfo || ''}
                            onChange={(e) => setFormData({ ...formData, customerInfo: e.target.value })}
                            placeholder="কাস্টমারের নাম বা মোবাইল লিখুন..."
                            className="flex-1 px-3 py-2 text-xs font-bold text-slate-900 outline-none bg-transparent min-w-0"
                          />
                          {/* ইনপুটের ভিতরেই ড্রপডাউন বাটন */}
                          <div className="relative border-l border-slate-200 bg-slate-50 hover:bg-purple-50 transition-colors shrink-0">
                            <select
                              value={allCustomerOptions.includes(formData.customerInfo || '') ? formData.customerInfo : ''}
                              onChange={(e) => {
                                const val = e.target.value;
                                if (val === '__ADD_NEW_CUST__') {
                                  setShowManageProducts(true);
                                  setDropdownManageTab('customers');
                                } else if (val) {
                                  setFormData((prev) => ({ ...prev, customerInfo: val }));
                                }
                              }}
                              className="text-[11px] font-bold text-slate-700 py-2 pl-2 pr-6 bg-transparent outline-none cursor-pointer appearance-none max-w-[130px] truncate"
                              title="তালিকা থেকে কাস্টমার বা মোবাইল বাছাই করুন বা নতুন বসান"
                            >
                              <option value="">▼ বাছুন</option>
                              <option value="__ADD_NEW_CUST__" className="text-purple-700 font-bold bg-purple-50">
                                ➕ নতুন কাস্টমার বসান...
                              </option>
                              {allCustomerOptions.map((c) => (
                                <option key={c} value={c}>
                                  {c}
                                </option>
                              ))}
                            </select>
                            <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-1.5 top-2.5 pointer-events-none" />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* ড্রপডাউন বাটন পরিচালনা: নতুন নাম যুক্ত করুন ও পুরনো অপশন মুছুন */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between gap-1 flex-wrap">
                        <button
                          type="button"
                          onClick={() => setShowManageProducts(!showManageProducts)}
                          className="text-[11px] font-black text-indigo-700 hover:text-indigo-900 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 px-2.5 py-1 rounded-xl cursor-pointer flex items-center gap-1 transition-all active:scale-95 shadow-2xs"
                        >
                          <Settings2 className="w-3.5 h-3.5 text-indigo-600" />
                          <span>{showManageProducts ? '▲ ড্রপডাউন পরিচালনা বন্ধ করুন' : '⚙️ ড্রপডাউনে নাম যুক্ত / পুরনো অপশন মুছুন'}</span>
                        </button>

                        <div className="flex items-center gap-1">
                          {formData.itemName.trim() && !savedProducts.includes(formData.itemName.trim()) && (
                            <button
                              type="button"
                              onClick={() => handleAddProductToDropdown(formData.itemName.trim())}
                              className="text-[10px] font-black text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-2 py-1 rounded-xl cursor-pointer flex items-center gap-1 transition-all active:scale-95"
                              title="বর্তমান প্রোডাক্টটি ড্রপডাউনে সেভ করুন"
                            >
                              <Plus className="w-3 h-3 text-emerald-600" />
                              <span>+ প্রোডাক্ট</span>
                            </button>
                          )}

                          {formData.customerInfo?.trim() && !allCustomerOptions.includes(formData.customerInfo.trim()) && (
                            <button
                              type="button"
                              onClick={() => handleAddCustomerToDropdown(formData.customerInfo.trim())}
                              className="text-[10px] font-black text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-200 px-2 py-1 rounded-xl cursor-pointer flex items-center gap-1 transition-all active:scale-95"
                              title="বর্তমান কাস্টমার ড্রপডাউনে সেভ করুন"
                            >
                              <Plus className="w-3 h-3 text-purple-600" />
                              <span>+ কাস্টমার</span>
                            </button>
                          )}
                        </div>
                      </div>

                      {/* ড্রপডাউন পরিচালনা প্যানেল */}
                      {showManageProducts && (
                        <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5 animate-fadeIn">
                          <div className="flex items-center justify-between flex-wrap gap-1">
                            <span className="text-[11px] font-black text-slate-800">
                              ড্রপডাউন লিস্ট পরিচালনা
                            </span>
                            <div className="flex items-center gap-1 bg-white p-0.5 rounded-lg border border-slate-200 text-[10px]">
                              <button
                                type="button"
                                onClick={() => setDropdownManageTab('products')}
                                className={`px-2 py-0.5 rounded-md font-bold transition-colors cursor-pointer ${
                                  dropdownManageTab === 'products'
                                    ? 'bg-emerald-600 text-white shadow-2xs'
                                    : 'text-slate-600 hover:bg-slate-100'
                                }`}
                              >
                                প্রোডাক্ট ({savedProducts.length})
                              </button>
                              <button
                                type="button"
                                onClick={() => setDropdownManageTab('quantities')}
                                className={`px-2 py-0.5 rounded-md font-bold transition-colors cursor-pointer ${
                                  dropdownManageTab === 'quantities'
                                    ? 'bg-blue-600 text-white shadow-2xs'
                                    : 'text-slate-600 hover:bg-slate-100'
                                }`}
                              >
                                পরিমাণ ({savedQuantities.length})
                              </button>
                              <button
                                type="button"
                                onClick={() => setDropdownManageTab('customers')}
                                className={`px-2 py-0.5 rounded-md font-bold transition-colors cursor-pointer ${
                                  dropdownManageTab === 'customers'
                                    ? 'bg-purple-600 text-white shadow-2xs'
                                    : 'text-slate-600 hover:bg-slate-100'
                                }`}
                              >
                                কাস্টমার ({allCustomerOptions.length})
                              </button>
                            </div>
                          </div>

                          {/* নতুন নাম ড্রপডাউনে যুক্ত করার ইনপুট */}
                          <div className="flex items-center gap-1.5">
                            <input
                              type="text"
                              value={
                                dropdownManageTab === 'products'
                                  ? newCustomProductInput
                                  : dropdownManageTab === 'quantities'
                                  ? newCustomQuantityInput
                                  : newCustomCustomerInput
                              }
                              onChange={(e) => {
                                if (dropdownManageTab === 'products') setNewCustomProductInput(e.target.value);
                                else if (dropdownManageTab === 'quantities') setNewCustomQuantityInput(e.target.value);
                                else setNewCustomCustomerInput(e.target.value);
                              }}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  if (dropdownManageTab === 'products') {
                                    handleAddProductToDropdown();
                                  } else if (dropdownManageTab === 'quantities') {
                                    handleAddQuantityToDropdown();
                                  } else {
                                    handleAddCustomerToDropdown();
                                  }
                                }
                              }}
                              placeholder={
                                dropdownManageTab === 'products'
                                  ? 'ড্রপডাউনে যুক্ত করতে প্রোডাক্টের নাম লিখুন...'
                                  : dropdownManageTab === 'quantities'
                                  ? 'ড্রপডাউনে যুক্ত করতে পরিমাণ লিখুন (যেমন: ৫ কেজি)...'
                                  : 'ড্রপডাউনে যুক্ত করতে কাস্টমার নাম বা মোবাইল লিখুন...'
                              }
                              className="flex-1 px-3 py-1.5 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900 outline-none focus:border-indigo-600 shadow-2xs"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                if (dropdownManageTab === 'products') {
                                  handleAddProductToDropdown();
                                } else if (dropdownManageTab === 'quantities') {
                                  handleAddQuantityToDropdown();
                                } else {
                                  handleAddCustomerToDropdown();
                                }
                              }}
                              className={`px-3 py-1.5 text-white rounded-xl text-xs font-black shrink-0 flex items-center gap-1 cursor-pointer active:scale-95 shadow-2xs ${
                                dropdownManageTab === 'products'
                                  ? 'bg-emerald-600 hover:bg-emerald-700'
                                  : dropdownManageTab === 'quantities'
                                  ? 'bg-blue-600 hover:bg-blue-700'
                                  : 'bg-purple-600 hover:bg-purple-700'
                              }`}
                            >
                              <Plus className="w-3.5 h-3.5" />
                              <span>যুক্ত করুন</span>
                            </button>
                          </div>

                          {/* পুরনো অপশনগুলো মুছে ফেলার তালিকা */}
                          <div>
                            <span className="text-[10px] font-bold text-slate-500 block mb-1">
                              পুরনো অপশন ড্রপডাউন থেকে মুছতে নামের পাশের (×) বাটনে চাপ দিন:
                            </span>
                            <div className="flex items-center gap-1.5 flex-wrap max-h-36 overflow-y-auto p-1.5 bg-white border border-slate-200 rounded-xl">
                              {dropdownManageTab === 'products' ? (
                                savedProducts.map((p) => (
                                  <span
                                    key={p}
                                    className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-100 text-slate-800 rounded-lg text-[11px] font-bold border border-slate-200"
                                  >
                                    <span
                                      className="cursor-pointer hover:text-emerald-700"
                                      onClick={() => setFormData((prev) => ({ ...prev, itemName: p }))}
                                      title="ইনপুটে বসাতে ক্লিক করুন"
                                    >
                                      {p}
                                    </span>
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteProductFromDropdown(p)}
                                      className="w-3.5 h-3.5 rounded-full hover:bg-rose-600 hover:text-white text-slate-400 flex items-center justify-center cursor-pointer transition-colors"
                                      title={`"${p}" ড্রপডাউন থেকে মুছে ফেলুন`}
                                    >
                                      <X className="w-2.5 h-2.5" />
                                    </button>
                                  </span>
                                ))
                              ) : dropdownManageTab === 'quantities' ? (
                                savedQuantities.map((q) => (
                                  <span
                                    key={q}
                                    className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-50 text-blue-900 rounded-lg text-[11px] font-bold border border-blue-200"
                                  >
                                    <span
                                      className="cursor-pointer hover:text-blue-700"
                                      onClick={() => setFormData((prev) => ({ ...prev, quantity: q }))}
                                      title="ইনপুটে বসাতে ক্লিক করুন"
                                    >
                                      {q}
                                    </span>
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteQuantityFromDropdown(q)}
                                      className="w-3.5 h-3.5 rounded-full hover:bg-rose-600 hover:text-white text-blue-400 flex items-center justify-center cursor-pointer transition-colors"
                                      title={`"${q}" ড্রপডাউন থেকে মুছে ফেলুন`}
                                    >
                                      <X className="w-2.5 h-2.5" />
                                    </button>
                                  </span>
                                ))
                              ) : (
                                allCustomerOptions.map((c) => (
                                  <span
                                    key={c}
                                    className="inline-flex items-center gap-1 px-2 py-0.5 bg-purple-50 text-purple-900 rounded-lg text-[11px] font-bold border border-purple-200"
                                  >
                                    <span
                                      className="cursor-pointer hover:text-purple-700"
                                      onClick={() => setFormData((prev) => ({ ...prev, customerInfo: c }))}
                                      title="ইনপুটে বসাতে ক্লিক করুন"
                                    >
                                      {c}
                                    </span>
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteCustomerFromDropdown(c)}
                                      className="w-3.5 h-3.5 rounded-full hover:bg-rose-600 hover:text-white text-purple-400 flex items-center justify-center cursor-pointer transition-colors"
                                      title={`"${c}" ড্রপডাউন থেকে মুছে ফেলুন`}
                                    >
                                      <X className="w-2.5 h-2.5" />
                                    </button>
                                  </span>
                                ))
                              )}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </>
                )}

                {/* 2. SPECIFIC FINANCIAL OPTIONS PER ACCOUNT TYPE */}
                {isModalPersonal ? (
                  <>
                    {/* PERSONAL: খরচ + জমা */}
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[11px] font-bold text-rose-700 block mb-1">
                          খরচ (৳) *
                        </label>
                        <input
                          type="number"
                          value={formData.buyPrice}
                          onChange={(e) => {
                            const val = e.target.value;
                            const exp = parseFloat(val) || 0;
                            const dep = parseFloat(formData.depositAmount) || 0;
                            setFormData({
                              ...formData,
                              buyPrice: val,
                              dueAmount: String(Math.max(0, exp - dep)),
                            });
                          }}
                          placeholder="0"
                          className="w-full px-3 py-2 bg-rose-50/50 border border-rose-200 rounded-xl text-xs font-bold font-mono text-rose-900 outline-none focus:border-rose-400 shadow-2xs"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] font-bold text-emerald-700 block mb-1">
                          জমা / প্রাপ্তি (৳)
                        </label>
                        <input
                          type="number"
                          value={formData.depositAmount}
                          onChange={(e) => {
                            const val = e.target.value;
                            const dep = parseFloat(val) || 0;
                            const exp = parseFloat(formData.buyPrice) || 0;
                            setFormData({
                              ...formData,
                              depositAmount: val,
                              dueAmount: String(Math.max(0, exp - dep)),
                            });
                          }}
                          placeholder="0"
                          className="w-full px-3 py-2 bg-emerald-50/50 border border-emerald-200 rounded-xl text-xs font-bold font-mono text-emerald-900 outline-none focus:border-emerald-400 shadow-2xs"
                        />
                      </div>
                    </div>

                    {/* Automatic Live Summary for Personal */}
                    {(() => {
                      const exp = parseFloat(formData.buyPrice) || 0;
                      const dep = parseFloat(formData.depositAmount) || 0;
                      const due = Math.max(0, exp - dep);
                      const surplus = Math.max(0, dep - exp);
                      return (
                        <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs font-bold">
                          <span className="text-slate-600">
                            বকেয়া দেনা: <span className="font-mono text-rose-600 font-black">{toBengaliDigits(due)} ৳</span>
                          </span>
                          <span className="text-slate-600">
                            উদ্বৃত্ত জমা: <span className="font-mono text-emerald-600 font-black">{toBengaliDigits(surplus)} ৳</span>
                          </span>
                        </div>
                      );
                    })()}
                  </>
                ) : (
                  <>
                    {/* SHOP: কেনা + বিক্রি + বাকি */}
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[11px] font-bold text-slate-700 block mb-1">
                          কেনা দাম / ক্রয়মূল্য (৳)
                        </label>
                        <input
                          type="number"
                          value={formData.buyPrice}
                          onChange={(e) => setFormData({ ...formData, buyPrice: e.target.value })}
                          placeholder="0"
                          className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono text-slate-900 outline-none focus:border-blue-500 shadow-2xs"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] font-bold text-emerald-700 block mb-1">
                          বিক্রি দাম / বিক্রিমূল্য (৳) *
                        </label>
                        <input
                          type="number"
                          required
                          value={formData.sellPrice}
                          onChange={(e) => {
                            const val = e.target.value;
                            const sNum = parseFloat(val) || 0;
                            const dNum = parseFloat(formData.depositAmount) || 0;
                            setFormData({
                              ...formData,
                              sellPrice: val,
                              dueAmount: String(Math.max(0, sNum - dNum)),
                            });
                          }}
                          placeholder="0"
                          className="w-full px-3 py-2 bg-emerald-50/50 border border-emerald-200 rounded-xl text-xs font-bold font-mono text-emerald-900 outline-none focus:border-emerald-500 shadow-2xs"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[11px] font-bold text-slate-700">নগদ জমা / ক্যাশ (৳)</label>
                          <button
                            type="button"
                            onClick={() => {
                              setFormData({
                                ...formData,
                                depositAmount: formData.sellPrice,
                                dueAmount: '0',
                              });
                            }}
                            className="text-[10px] text-blue-600 hover:underline font-bold"
                          >
                            পুরো ক্যাশ
                          </button>
                        </div>
                        <input
                          type="number"
                          value={formData.depositAmount}
                          onChange={(e) => {
                            const val = e.target.value;
                            const dNum = parseFloat(val) || 0;
                            const sNum = parseFloat(formData.sellPrice) || 0;
                            setFormData({
                              ...formData,
                              depositAmount: val,
                              dueAmount: String(Math.max(0, sNum - dNum)),
                            });
                          }}
                          placeholder="0"
                          className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono text-slate-900 outline-none focus:border-blue-500 shadow-2xs"
                        />
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[11px] font-bold text-amber-700">কাস্টমার বাকি (৳)</label>
                          <button
                            type="button"
                            onClick={() => {
                              setFormData({
                                ...formData,
                                depositAmount: '0',
                                dueAmount: formData.sellPrice,
                              });
                            }}
                            className="text-[10px] text-amber-600 hover:underline font-bold"
                          >
                            পুরো বাকি
                          </button>
                        </div>
                        <input
                          type="number"
                          value={formData.dueAmount}
                          onChange={(e) => {
                            const val = e.target.value;
                            const dueNum = parseFloat(val) || 0;
                            const sNum = parseFloat(formData.sellPrice) || 0;
                            setFormData({
                              ...formData,
                              dueAmount: val,
                              depositAmount: String(Math.max(0, sNum - dueNum)),
                            });
                          }}
                          placeholder="স্বয়ংক্রিয় হিসাব"
                          className="w-full px-3 py-2 bg-amber-50/60 border border-amber-200 rounded-xl text-xs font-bold font-mono text-amber-900 outline-none focus:border-amber-400 shadow-2xs"
                        />
                      </div>
                    </div>

                    {/* Automatic Live Summary for Shop */}
                    {(() => {
                      const b = parseFloat(formData.buyPrice) || 0;
                      const s = parseFloat(formData.sellPrice) || 0;
                      const d = parseFloat(formData.depositAmount) || 0;
                      const due = formData.dueAmount !== '' ? (parseFloat(formData.dueAmount) || 0) : Math.max(0, s - d);
                      const profit = Math.max(0, s - b);
                      return (
                        <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs font-bold">
                          <span className="text-slate-600">
                            বাকি: <span className="font-mono text-amber-700 font-black">{toBengaliDigits(due)} ৳</span>
                          </span>
                          <span className="text-slate-600">
                            নিট লাভ: <span className="font-mono text-emerald-700 font-black">+{toBengaliDigits(profit)} ৳</span>
                          </span>
                        </div>
                      );
                    })()}
                  </>
                )}

                {/* 3. DATE FIELD */}
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">তারিখ</label>
                  <input
                    type="text"
                    value={formData.date}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        date: e.target.value,
                        dayOfWeek: getBengaliDayOfWeek(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 outline-none shadow-2xs"
                  />
                </div>

                {/* 4. ACTIONS (Save / Update / Delete) */}
                {editingTrx ? (
                  <div className="flex items-center gap-2 pt-1">
                    <button
                      type="submit"
                      className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-98 text-white font-black text-xs rounded-xl shadow-md cursor-pointer transition-all flex items-center justify-center gap-1.5"
                    >
                      <Check className="w-4 h-4" />
                      <span>পরিবর্তন সংরক্ষণ করুন</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const idToDelete = editingTrx.id;
                        setEditingTrx(null);
                        setIsAddModalOpen(false);
                        setDeleteConfirmId(idToDelete);
                        setDeleteConfirmType('shop_trx');
                      }}
                      className="py-2.5 px-3 bg-rose-50 hover:bg-rose-100 active:scale-98 text-rose-700 border border-rose-200 font-black text-xs rounded-xl cursor-pointer transition-all flex items-center justify-center gap-1"
                      title="এই হিসাবটি ডিলিট করুন"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>ডিলিট</span>
                    </button>
                  </div>
                ) : (
                  <button
                    type="submit"
                    className={`w-full py-2.5 active:scale-98 text-white font-black text-xs rounded-xl shadow-md cursor-pointer transition-all flex items-center justify-center gap-1.5 ${
                      isModalPersonal
                        ? 'bg-purple-600 hover:bg-purple-700'
                        : 'bg-emerald-600 hover:bg-emerald-700'
                    }`}
                  >
                    <Plus className="w-4 h-4" />
                    <span>হিসাব সংরক্ষণ করুন</span>
                  </button>
                )}
              </form>
            </div>
          </div>
        );
      })()}

      {/* 7.1.1 SUCCESS CONFIRMATION MODAL ("অ্যান্টি সফল হবে ওকে বাটন ক্লিক করব") */}
      {successEntryModal.isOpen && successEntryModal.trx && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fadeIn">
          <div className="w-full max-w-sm bg-white rounded-3xl shadow-2xl border border-emerald-200 overflow-hidden text-center p-6 space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-10 h-10 animate-bounce" />
            </div>

            <div>
              <span className="text-[11px] font-black uppercase tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200 inline-block">
                {successEntryModal.isEdit ? 'হিসাব পরিবর্তন সফল' : 'নতুন হিসাব এন্ট্রি সফল'}
              </span>
              <h3 className="text-base font-black text-slate-900 mt-2">
                {successEntryModal.isEdit ? 'সফলভাবে এডিট ও সংরক্ষিত হয়েছে!' : 'হিসাব সফলভাবে সংরক্ষণ হয়েছে!'}
              </h3>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                আপনার টালি খাতায় ডাটাটি নির্ভুলভাবে সংরক্ষিত হয়েছে
              </p>
            </div>

            {/* Transaction Brief Card */}
            <div className="bg-slate-50 rounded-2xl p-3.5 border border-slate-200 text-left space-y-2">
              <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                <div className="flex items-center gap-1.5 flex-wrap">
                  {successEntryModal.trx.customerName && (
                    <span className="text-[10px] font-bold bg-purple-50 text-purple-700 px-2 py-0.5 rounded-md border border-purple-200">
                      👤 {successEntryModal.trx.customerName}{successEntryModal.trx.customerPhone ? ` (${successEntryModal.trx.customerPhone})` : ''}
                    </span>
                  )}
                  <span className="text-xs font-black text-slate-900">
                    {successEntryModal.trx.itemName}
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  {successEntryModal.trx.category && successEntryModal.trx.category !== 'মুদি মালামাল' && successEntryModal.trx.category !== 'মদি মালামাল' && successEntryModal.trx.category !== 'দোকান' && (
                    <span className="text-[10px] font-bold bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-md border border-indigo-200">
                      {successEntryModal.trx.category}
                    </span>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs font-bold pt-1">
                <div>
                  <span className="text-[10px] text-slate-500 block">কেনা দাম</span>
                  <span className="font-mono text-slate-800">৳{toBengaliDigits(successEntryModal.trx.buyPrice)}</span>
                </div>
                <div>
                  <span className="text-[10px] text-emerald-700 block">বিক্রি দাম</span>
                  <span className="font-mono text-emerald-700">৳{toBengaliDigits(successEntryModal.trx.sellPrice)}</span>
                </div>
                <div>
                  <span className="text-[10px] text-blue-700 block">নগদ জমা</span>
                  <span className="font-mono text-blue-700">৳{toBengaliDigits(successEntryModal.trx.depositAmount)}</span>
                </div>
                <div>
                  <span className="text-[10px] text-amber-700 block">বাকি</span>
                  <span className="font-mono text-amber-700">৳{toBengaliDigits(successEntryModal.trx.dueAmount)}</span>
                </div>
              </div>

              {Number(successEntryModal.trx.profit) > 0 && (
                <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-xs">
                  <span className="text-slate-600 font-bold">মোট লাভ:</span>
                  <span className="font-mono font-black text-emerald-600">+৳{toBengaliDigits(successEntryModal.trx.profit)}</span>
                </div>
              )}
            </div>

            {/* OK BUTTON ("ওকে বাটন ক্লিক করব") */}
            <button
              type="button"
              id="btn-entry-success-ok"
              onClick={() => setSuccessEntryModal({ isOpen: false, trx: null, isEdit: false })}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-black text-sm rounded-2xl shadow-lg shadow-emerald-600/30 cursor-pointer transition-all flex items-center justify-center gap-2"
            >
              <Check className="w-5 h-5" />
              <span>ঠিক আছে (OK)</span>
            </button>
          </div>
        </div>
      )}
      {isAddCustomerModalOpen && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-end sm:items-center justify-center z-50 p-0 sm:p-4 animate-fadeIn">
          <div className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-3 bg-blue-600 text-white flex items-center justify-between">
              <h3 className="text-xs font-black">নতুন কাস্টমার খাতা খুলুন</h3>
              <button
                type="button"
                onClick={() => setIsAddCustomerModalOpen(false)}
                className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveCustomer} className="p-4 space-y-3">
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">কাস্টমারের নাম *</label>
                <input
                  type="text"
                  required
                  value={newCustomerName}
                  onChange={(e) => setNewCustomerName(e.target.value)}
                  placeholder="যেমন: রহিম স্টোর / করিম ভাই"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">মোবাইল নম্বর</label>
                <input
                  type="text"
                  value={newCustomerPhone}
                  onChange={(e) => setNewCustomerPhone(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono text-slate-900 outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">পূর্বের বাকি (যদি থাকে ৳)</label>
                <input
                  type="number"
                  value={newCustomerDue}
                  onChange={(e) => setNewCustomerDue(e.target.value)}
                  placeholder="0"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono text-slate-900 outline-none focus:border-blue-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl shadow-md cursor-pointer transition-all active:scale-98"
              >
                কাস্টমার খাতা তৈরি করুন
              </button>
            </form>
          </div>
        </div>
      )}

      {/* 7.2.1 EDIT CUSTOMER MODAL */}
      {isEditCustomerModalOpen && editingCustomer && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-end sm:items-center justify-center z-50 p-0 sm:p-4 animate-fadeIn">
          <div className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-3 bg-[#0d2847] text-white flex items-center justify-between">
              <h3 className="text-xs font-black">কাস্টমার তথ্য সম্পাদনা করুন</h3>
              <button
                type="button"
                onClick={() => {
                  setIsEditCustomerModalOpen(false);
                  setEditingCustomer(null);
                }}
                className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEditCustomer} className="p-4 space-y-3">
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">কাস্টমারের নাম *</label>
                <input
                  type="text"
                  required
                  value={editCustName}
                  onChange={(e) => setEditCustName(e.target.value)}
                  placeholder="যেমন: রহিম স্টোর / করিম ভাই"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">মোবাইল নম্বর</label>
                <input
                  type="text"
                  value={editCustPhone}
                  onChange={(e) => setEditCustPhone(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono text-slate-900 outline-none focus:border-blue-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl shadow-md cursor-pointer transition-all active:scale-98"
              >
                পরিবর্তন সংরক্ষণ করুন
              </button>
            </form>
          </div>
        </div>
      )}

      {/* 7.3 CUSTOMER TRANSACTION DETAIL MODAL */}
      {isCustomerDetailModalOpen && (currentSelectedCustomer || selectedCustomer) && (() => {
        const cust = currentSelectedCustomer || selectedCustomer!;
        return (
          <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-end sm:items-center justify-center z-50 p-0 sm:p-4 animate-fadeIn">
            <div className="w-full sm:max-w-lg bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
              <div className="p-3 bg-[#0d2847] text-white flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-black">{cust.name}</h3>
                  <span className="text-[10px] text-slate-300 font-mono">{cust.phone}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={(e) => handleOpenEditCustomerModal(cust, e)}
                    className="px-2 py-1 bg-white/10 hover:bg-white/20 rounded-lg text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                    title="কাস্টমার তথ্য পরিবর্তন"
                  >
                    <Edit2 className="w-3 h-3" />
                    <span>এডিট</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsCustomerDetailModalOpen(false)}
                    className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="p-3.5 space-y-3 overflow-y-auto">
                <div className="flex items-center justify-between bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  <span className="text-xs font-bold text-slate-700">বাকি ও লেনদেন তালিকা</span>
                  <button
                    type="button"
                    onClick={() => {
                      setCustTxItem('');
                      setCustTxSell('');
                      setCustTxDeposit('');
                      setIsAddCustTxModalOpen(true);
                    }}
                    className="px-2.5 py-1 bg-emerald-600 text-white rounded-lg text-[11px] font-black flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                    <span>লেনদেন যোগ</span>
                  </button>
                </div>

                <div className="divide-y divide-slate-100 max-h-[50vh] overflow-y-auto">
                  {(cust.transactions || []).length === 0 ? (
                    <p className="text-xs text-center text-slate-400 py-6">কোনো পূর্বের লেনদেন নেই</p>
                  ) : (
                    (cust.transactions || []).map((tx) => (
                      <div
                        key={tx.id}
                        onClick={(e) => handleOpenEditCustTxModal(tx, e)}
                        className="py-2.5 px-2 flex items-center justify-between text-xs hover:bg-blue-50/40 rounded-xl transition-colors cursor-pointer group"
                        title="এই লেনদেনটি এডিট বা ডিলিট করতে ক্লিক করুন"
                      >
                        <div className="flex-1 pr-2">
                          <span className="font-bold text-slate-900 block leading-tight">{tx.itemName}</span>
                          <span className="text-[10px] text-slate-400 font-bold">{formatBengaliDate(tx.date)} {tx.time ? `• ${tx.time}` : ''}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <div className="text-right mr-1">
                            <span className="font-bold text-rose-600 block">দেনা: ৳{toBengaliDigits(tx.sellPrice)}</span>
                            <span className="text-[10px] text-emerald-600 font-bold">জমা: ৳{toBengaliDigits(tx.depositAmount)}</span>
                          </div>
                          <button
                            type="button"
                            onClick={(e) => handleOpenEditCustTxModal(tx, e)}
                            className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                            title="লেনদেন সম্পাদনা করুন"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={(e) => handleDeleteCustTx(tx.id, cust.id, e)}
                            className="p-1.5 text-slate-300 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                            title="মুছুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* 7.4 ADD CUSTOMER TRANSACTION MODAL */}
      {isAddCustTxModalOpen && (currentSelectedCustomer || selectedCustomer) && (() => {
        const cust = currentSelectedCustomer || selectedCustomer!;
        return (
          <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-xs flex items-end sm:items-center justify-center z-50 p-0 sm:p-4 animate-fadeIn">
            <div className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl p-4 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <h3 className="text-xs font-black text-slate-900">
                  {cust.name}-এর হিসাবে লেনদেন যোগ
                </h3>
                <button
                  type="button"
                  onClick={() => setIsAddCustTxModalOpen(false)}
                  className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center cursor-pointer"
                >
                  <X className="w-3.5 h-3.5 text-slate-500" />
                </button>
              </div>

              <form onSubmit={handleSaveCustomerTx} className="space-y-3">
                {/* ডাটা এন্ট্রি ঘরগুলো: ১) প্রোডাক্ট নাম ২) পরিমাণ ৩) কাস্টমার নাম/মোবাইল নাম্বার - প্রতিটির ভিতরে ড্রপডাউন */}
                <div className="space-y-2.5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {/* বক্স ১: প্রোডাক্ট নাম (ভিতরে ড্রপডাউন) */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-[11px] font-black text-slate-800">
                          প্রোডাক্ট নাম *
                        </label>
                        <span className="text-[9px] text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded font-bold border border-emerald-200">
                          ভিতরে ড্রপডাউন
                        </span>
                      </div>
                      <div className="relative flex items-center bg-white border border-slate-300 rounded-xl focus-within:border-emerald-600 focus-within:ring-1 focus-within:ring-emerald-500 shadow-2xs overflow-hidden transition-all">
                        <input
                          type="text"
                          required
                          value={custTxItem}
                          onChange={(e) => setCustTxItem(e.target.value)}
                          placeholder="প্রোডাক্ট নাম..."
                          className="flex-1 px-3 py-2 text-xs font-bold text-slate-900 outline-none bg-transparent min-w-0"
                        />
                        <div className="relative border-l border-slate-200 bg-slate-50 hover:bg-emerald-50 transition-colors shrink-0">
                          <select
                            value={savedProducts.includes(custTxItem) ? custTxItem : ''}
                            onChange={(e) => {
                              const val = e.target.value;
                              if (val) setCustTxItem(val);
                            }}
                            className="text-[11px] font-bold text-slate-700 py-2 pl-2 pr-6 bg-transparent outline-none cursor-pointer appearance-none"
                            title="তালিকা থেকে বাছুন"
                          >
                            <option value="">▼ বাছুন</option>
                            {savedProducts.map((p) => (
                              <option key={p} value={p}>
                                {p}
                              </option>
                            ))}
                          </select>
                          <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-1.5 top-2.5 pointer-events-none" />
                        </div>
                      </div>
                    </div>

                    {/* বক্স ২: পরিমাণ (ভিতরে ড্রপডাউন) */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-[11px] font-black text-slate-800">
                          পরিমাণ
                        </label>
                        <span className="text-[9px] text-blue-700 bg-blue-50 px-1.5 py-0.2 rounded font-bold border border-blue-200">
                          ভিতরে ড্রপডাউন
                        </span>
                      </div>
                      <div className="relative flex items-center bg-white border border-slate-300 rounded-xl focus-within:border-blue-600 focus-within:ring-1 focus-within:ring-blue-500 shadow-2xs overflow-hidden transition-all">
                        <input
                          type="text"
                          value={custTxQuantity}
                          onChange={(e) => setCustTxQuantity(e.target.value)}
                          placeholder="যেমন: ১ কেজি, ২ পিস..."
                          className="flex-1 px-3 py-2 text-xs font-bold text-slate-900 outline-none bg-transparent min-w-0"
                        />
                        <div className="relative border-l border-slate-200 bg-slate-50 hover:bg-blue-50 transition-colors shrink-0">
                          <select
                            value={DEFAULT_PRESET_QUANTITIES.includes(custTxQuantity) ? custTxQuantity : ''}
                            onChange={(e) => {
                              const val = e.target.value;
                              if (val) setCustTxQuantity(val);
                            }}
                            className="text-[11px] font-bold text-slate-700 py-2 pl-2 pr-6 bg-transparent outline-none cursor-pointer appearance-none"
                            title="পরিমাণ বাছুন"
                          >
                            <option value="">▼ বাছুন</option>
                            {DEFAULT_PRESET_QUANTITIES.map((q) => (
                              <option key={q} value={q}>
                                {q}
                              </option>
                            ))}
                          </select>
                          <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-1.5 top-2.5 pointer-events-none" />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* বক্স ৩: কাস্টমার নাম / মোবাইল নাম্বার (ঘরের ডান পাশে Dropdown ▼ বাটন) */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[11px] font-black text-slate-800">
                        কাস্টমার নাম / মোবাইল নাম্বার
                      </label>
                      <span className="text-[9px] text-purple-700 bg-purple-50 px-1.5 py-0.2 rounded font-bold border border-purple-200">
                        ভিতরে ড্রপডাউন
                      </span>
                    </div>
                    <div className="relative flex items-center bg-white border border-slate-300 rounded-xl focus-within:border-purple-600 focus-within:ring-1 focus-within:ring-purple-500 shadow-2xs overflow-hidden transition-all">
                      <input
                        type="text"
                        value={custTxCustomerInfo || (cust ? `${cust.name}${cust.phone ? ` (${cust.phone})` : ''}` : '')}
                        onChange={(e) => setCustTxCustomerInfo(e.target.value)}
                        placeholder="কাস্টমারের নাম বা মোবাইল লিখুন..."
                        className="flex-1 px-3 py-2 text-xs font-bold text-slate-900 outline-none bg-transparent min-w-0"
                      />
                      <div className="relative border-l border-slate-200 bg-slate-50 hover:bg-purple-50 transition-colors shrink-0">
                        <select
                          value={allCustomerOptions.includes(custTxCustomerInfo) ? custTxCustomerInfo : ''}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val) setCustTxCustomerInfo(val);
                          }}
                          className="text-[11px] font-bold text-slate-700 py-2 pl-2 pr-6 bg-transparent outline-none cursor-pointer appearance-none max-w-[130px] truncate"
                          title="তালিকা থেকে কাস্টমার বাছাই করুন"
                        >
                          <option value="">▼ বাছুন</option>
                          {allCustomerOptions.map((c) => (
                            <option key={c} value={c}>
                              {c}
                            </option>
                          ))}
                        </select>
                        <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-1.5 top-2.5 pointer-events-none" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[11px] font-bold text-slate-700 block mb-1">কেনা দাম (৳)</label>
                    <input
                      type="number"
                      value={custTxBuy}
                      onChange={(e) => setCustTxBuy(e.target.value)}
                      placeholder="0"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono text-slate-900 outline-none focus:border-blue-500 shadow-2xs"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-emerald-700 block mb-1">বিক্রি দাম / দেনা (৳) *</label>
                    <input
                      type="number"
                      required
                      value={custTxSell}
                      onChange={(e) => {
                        const val = e.target.value;
                        const sNum = parseFloat(val) || 0;
                        const dNum = parseFloat(custTxDeposit) || 0;
                        setCustTxSell(val);
                        setCustTxDue(String(Math.max(0, sNum - dNum)));
                      }}
                      placeholder="0"
                      className="w-full px-3 py-2 bg-emerald-50/50 border border-emerald-200 rounded-xl text-xs font-bold font-mono text-emerald-900 outline-none focus:border-emerald-500 shadow-2xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[11px] font-bold text-slate-700">নগদ জমা (৳)</label>
                      <button
                        type="button"
                        onClick={() => {
                          setCustTxDeposit(custTxSell);
                          setCustTxDue('0');
                        }}
                        className="text-[10px] text-blue-600 hover:underline font-bold"
                      >
                        পুরো পরিশোধ
                      </button>
                    </div>
                    <input
                      type="number"
                      value={custTxDeposit}
                      onChange={(e) => {
                        const val = e.target.value;
                        const dNum = parseFloat(val) || 0;
                        const sNum = parseFloat(custTxSell) || 0;
                        setCustTxDeposit(val);
                        setCustTxDue(String(Math.max(0, sNum - dNum)));
                      }}
                      placeholder="0"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono text-slate-900 outline-none focus:border-blue-500 shadow-2xs"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[11px] font-bold text-amber-700">বাকি (৳)</label>
                      <button
                        type="button"
                        onClick={() => {
                          setCustTxDeposit('0');
                          setCustTxDue(custTxSell);
                        }}
                        className="text-[10px] text-amber-600 hover:underline font-bold"
                      >
                        পুরো বাকি
                      </button>
                    </div>
                    <input
                      type="number"
                      value={custTxDue}
                      onChange={(e) => {
                        const val = e.target.value;
                        const dueNum = parseFloat(val) || 0;
                        const sNum = parseFloat(custTxSell) || 0;
                        setCustTxDue(val);
                        setCustTxDeposit(String(Math.max(0, sNum - dueNum)));
                      }}
                      placeholder="স্বয়ংক্রিয় হিসাব"
                      className="w-full px-3 py-2 bg-amber-50/60 border border-amber-200 rounded-xl text-xs font-bold font-mono text-amber-900 outline-none focus:border-amber-400 shadow-2xs"
                    />
                  </div>
                </div>

                {/* Automatic Live Summary for Customer Tx */}
                {(() => {
                  const b = parseFloat(custTxBuy) || 0;
                  const s = parseFloat(custTxSell) || 0;
                  const d = parseFloat(custTxDeposit) || 0;
                  const due = custTxDue !== '' ? (parseFloat(custTxDue) || 0) : Math.max(0, s - d);
                  const profit = Math.max(0, s - b);
                  return (
                    <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs font-bold">
                      <span className="text-slate-600">
                        বাকি: <span className="font-mono text-amber-700 font-black">{toBengaliDigits(due)} ৳</span>
                      </span>
                      {b > 0 && (
                        <span className="text-slate-600">
                          লাভ: <span className="font-mono text-emerald-700 font-black">+{toBengaliDigits(profit)} ৳</span>
                        </span>
                      )}
                    </div>
                  );
                })()}

                <button
                  type="submit"
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-black text-xs rounded-xl shadow-md cursor-pointer transition-all flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>লেনদেন সংরক্ষণ করুন</span>
                </button>
              </form>
            </div>
          </div>
        );
      })()}

      {/* 7.4.1 EDIT CUSTOMER TRANSACTION MODAL */}
      {isEditCustTxModalOpen && editingCustTx && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-xs flex items-end sm:items-center justify-center z-50 p-0 sm:p-4 animate-fadeIn">
          <div className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl p-4 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-xs font-black text-slate-900">
                কাস্টমার লেনদেন সম্পাদনা করুন
              </h3>
              <button
                type="button"
                onClick={() => {
                  setIsEditCustTxModalOpen(false);
                  setEditingCustTx(null);
                }}
                className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center cursor-pointer"
              >
                <X className="w-3.5 h-3.5 text-slate-500" />
              </button>
            </div>

            <form onSubmit={handleSaveEditCustTx} className="space-y-3">
              {/* শুধু দুটি বক্স: ১) প্রোডাক্ট নাম (ভিতরে ড্রপডাউন) ২) পরিমাণ (ভিতরে ড্রপডাউন) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {/* বক্স ১: প্রোডাক্ট নাম (ভিতরে ড্রপডাউন) */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[11px] font-black text-slate-800">
                      প্রোডাক্ট নাম *
                    </label>
                    <span className="text-[9px] text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded font-bold border border-emerald-200">
                      ভিতরে ড্রপডাউন
                    </span>
                  </div>
                  <div className="relative flex items-center bg-white border border-slate-300 rounded-xl focus-within:border-emerald-600 focus-within:ring-1 focus-within:ring-emerald-500 shadow-2xs overflow-hidden transition-all">
                    <input
                      type="text"
                      required
                      value={editCustTxItem}
                      onChange={(e) => setEditCustTxItem(e.target.value)}
                      placeholder="প্রোডাক্ট নাম..."
                      className="flex-1 px-3 py-2 text-xs font-bold text-slate-900 outline-none bg-transparent min-w-0"
                    />
                    <div className="relative border-l border-slate-200 bg-slate-50 hover:bg-emerald-50 transition-colors shrink-0">
                      <select
                        value={savedProducts.includes(editCustTxItem) ? editCustTxItem : ''}
                        onChange={(e) => {
                          const val = e.target.value;
                          if (val) setEditCustTxItem(val);
                        }}
                        className="text-[11px] font-bold text-slate-700 py-2 pl-2 pr-6 bg-transparent outline-none cursor-pointer appearance-none"
                        title="তালিকা থেকে বাছুন"
                      >
                        <option value="">▼ বাছুন</option>
                        {savedProducts.map((p) => (
                          <option key={p} value={p}>
                            {p}
                          </option>
                        ))}
                      </select>
                      <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-1.5 top-2.5 pointer-events-none" />
                    </div>
                  </div>
                </div>

                {/* বক্স ২: পরিমাণ (ভিতরে ড্রপডাউন) */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[11px] font-black text-slate-800">
                      পরিমাণ
                    </label>
                    <span className="text-[9px] text-blue-700 bg-blue-50 px-1.5 py-0.2 rounded font-bold border border-blue-200">
                      ভিতরে ড্রপডাউন
                    </span>
                  </div>
                  <div className="relative flex items-center bg-white border border-slate-300 rounded-xl focus-within:border-blue-600 focus-within:ring-1 focus-within:ring-blue-500 shadow-2xs overflow-hidden transition-all">
                    <input
                      type="text"
                      value={editCustTxQuantity}
                      onChange={(e) => setEditCustTxQuantity(e.target.value)}
                      placeholder="যেমন: ১ কেজি, ২ পিস..."
                      className="flex-1 px-3 py-2 text-xs font-bold text-slate-900 outline-none bg-transparent min-w-0"
                    />
                    <div className="relative border-l border-slate-200 bg-slate-50 hover:bg-blue-50 transition-colors shrink-0">
                      <select
                        value={DEFAULT_PRESET_QUANTITIES.includes(editCustTxQuantity) ? editCustTxQuantity : ''}
                        onChange={(e) => {
                          const val = e.target.value;
                          if (val) setEditCustTxQuantity(val);
                        }}
                        className="text-[11px] font-bold text-slate-700 py-2 pl-2 pr-6 bg-transparent outline-none cursor-pointer appearance-none"
                        title="পরিমাণ বাছুন"
                      >
                        <option value="">▼ বাছুন</option>
                        {DEFAULT_PRESET_QUANTITIES.map((q) => (
                          <option key={q} value={q}>
                            {q}
                          </option>
                        ))}
                      </select>
                      <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-1.5 top-2.5 pointer-events-none" />
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">কেনা দাম (৳)</label>
                  <input
                    type="number"
                    value={editCustTxBuy}
                    onChange={(e) => setEditCustTxBuy(e.target.value)}
                    placeholder="0"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono text-slate-900 outline-none focus:border-blue-500 shadow-2xs"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-emerald-700 block mb-1">বিক্রি দাম / দেনা (৳) *</label>
                  <input
                    type="number"
                    required
                    value={editCustTxSell}
                    onChange={(e) => {
                      const val = e.target.value;
                      const sNum = parseFloat(val) || 0;
                      const dNum = parseFloat(editCustTxDeposit) || 0;
                      setEditCustTxSell(val);
                      setEditCustTxDue(String(Math.max(0, sNum - dNum)));
                    }}
                    placeholder="0"
                    className="w-full px-3 py-2 bg-emerald-50/50 border border-emerald-200 rounded-xl text-xs font-bold font-mono text-emerald-900 outline-none focus:border-emerald-500 shadow-2xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[11px] font-bold text-slate-700">নগদ জমা (৳)</label>
                    <button
                      type="button"
                      onClick={() => {
                        setEditCustTxDeposit(editCustTxSell);
                        setEditCustTxDue('0');
                      }}
                      className="text-[10px] text-blue-600 hover:underline font-bold"
                    >
                      পুরো পরিশোধ
                    </button>
                  </div>
                  <input
                    type="number"
                    value={editCustTxDeposit}
                    onChange={(e) => {
                      const val = e.target.value;
                      const dNum = parseFloat(val) || 0;
                      const sNum = parseFloat(editCustTxSell) || 0;
                      setEditCustTxDeposit(val);
                      setEditCustTxDue(String(Math.max(0, sNum - dNum)));
                    }}
                    placeholder="0"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono text-slate-900 outline-none focus:border-blue-500 shadow-2xs"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[11px] font-bold text-amber-700">বাকি (৳)</label>
                    <button
                      type="button"
                      onClick={() => {
                        setEditCustTxDeposit('0');
                        setEditCustTxDue(editCustTxSell);
                      }}
                      className="text-[10px] text-amber-600 hover:underline font-bold"
                    >
                      পুরো বাকি
                    </button>
                  </div>
                  <input
                    type="number"
                    value={editCustTxDue}
                    onChange={(e) => {
                      const val = e.target.value;
                      const dueNum = parseFloat(val) || 0;
                      const sNum = parseFloat(editCustTxSell) || 0;
                      setEditCustTxDue(val);
                      setEditCustTxDeposit(String(Math.max(0, sNum - dueNum)));
                    }}
                    placeholder="স্বয়ংক্রিয় হিসাব"
                    className="w-full px-3 py-2 bg-amber-50/60 border border-amber-200 rounded-xl text-xs font-bold font-mono text-amber-900 outline-none focus:border-amber-400 shadow-2xs"
                  />
                </div>
              </div>

              {/* Automatic Live Summary for Customer Edit Tx */}
              {(() => {
                const b = parseFloat(editCustTxBuy) || 0;
                const s = parseFloat(editCustTxSell) || 0;
                const d = parseFloat(editCustTxDeposit) || 0;
                const due = editCustTxDue !== '' ? (parseFloat(editCustTxDue) || 0) : Math.max(0, s - d);
                const profit = Math.max(0, s - b);
                return (
                  <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs font-bold">
                    <span className="text-slate-600">
                      বাকি: <span className="font-mono text-amber-700 font-black">{toBengaliDigits(due)} ৳</span>
                    </span>
                    {b > 0 && (
                      <span className="text-slate-600">
                        লাভ: <span className="font-mono text-emerald-700 font-black">+{toBengaliDigits(profit)} ৳</span>
                      </span>
                    )}
                  </div>
                );
              })()}

              <div className="flex items-center gap-2 pt-1">
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-98 text-white font-black text-xs rounded-xl shadow-md cursor-pointer transition-all flex items-center justify-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>পরিবর্তন সংরক্ষণ করুন</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (editingCustTx && (currentSelectedCustomer || selectedCustomer)) {
                      handleDeleteCustTx(editingCustTx.id, (currentSelectedCustomer || selectedCustomer)!.id);
                      setIsEditCustTxModalOpen(false);
                      setEditingCustTx(null);
                    }
                  }}
                  className="py-2.5 px-3 bg-rose-50 hover:bg-rose-100 active:scale-98 text-rose-700 border border-rose-200 font-black text-xs rounded-xl cursor-pointer transition-all flex items-center justify-center gap-1"
                  title="এই লেনদেনটি ডিলিট করুন"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>ডিলিট</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* QUICK ADD NEW EXPENSE NAME DIRECTLY FROM DROPDOWN */}
      {quickNewExpenseModal && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fadeIn">
          <div className="w-full max-w-xs bg-white rounded-2xl p-4 shadow-xl border border-purple-200 space-y-3">
            <div className="flex items-center justify-between pb-1 border-b border-purple-100">
              <h4 className="text-xs font-black text-purple-900 flex items-center gap-1.5">
                <Plus className="w-4 h-4 text-purple-600" />
                <span>ড্রপডাউনে নতুন খরচের নাম বসান</span>
              </h4>
              <button
                type="button"
                onClick={() => {
                  setQuickNewExpenseModal(false);
                  setQuickNewExpenseInput('');
                }}
                className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="text-[11px] text-slate-500 font-medium">
              যে নামটি লিখবেন তা ড্রপডাউন তালিকায় যুক্ত হবে এবং সরাসরি খরচের ঘরে বসে যাবে।
            </p>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleAddPersonalExpenseToDropdown();
              }}
              className="space-y-3"
            >
              <input
                type="text"
                autoFocus
                required
                value={quickNewExpenseInput}
                onChange={(e) => setQuickNewExpenseInput(e.target.value)}
                placeholder="যেমন: ইন্টারনেট বিল, নাস্তা..."
                className="w-full px-3 py-2 bg-purple-50/40 border border-purple-200 rounded-xl text-xs font-bold text-slate-900 outline-none focus:border-purple-600 shadow-2xs"
              />
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setQuickNewExpenseModal(false);
                    setQuickNewExpenseInput('');
                  }}
                  className="flex-1 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold cursor-pointer hover:bg-slate-200 transition-colors"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold cursor-pointer transition-colors shadow-md shadow-purple-600/20"
                >
                  ✓ ড্রপডাউনে বসান
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* QUICK ADD NEW QUANTITY DIRECTLY FROM DROPDOWN */}
      {quickNewQuantityModal && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fadeIn">
          <div className="w-full max-w-xs bg-white rounded-2xl p-4 shadow-xl border border-blue-200 space-y-3">
            <div className="flex items-center justify-between pb-1 border-b border-blue-100">
              <h4 className="text-xs font-black text-blue-900 flex items-center gap-1.5">
                <Plus className="w-4 h-4 text-blue-600" />
                <span>ড্রপডাউনে নতুন পরিমাণ বসান</span>
              </h4>
              <button
                type="button"
                onClick={() => {
                  setQuickNewQuantityModal(false);
                  setQuickNewQuantityInput('');
                }}
                className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="text-[11px] text-slate-500 font-medium">
              যে পরিমাণটি লিখবেন তা ড্রপডাউন তালিকায় যুক্ত হবে এবং সরাসরি পরিমাণের ঘরে বসে যাবে।
            </p>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleAddCustomQuantityToDropdown();
              }}
              className="space-y-3"
            >
              <input
                type="text"
                autoFocus
                required
                value={quickNewQuantityInput}
                onChange={(e) => setQuickNewQuantityInput(e.target.value)}
                placeholder="যেমন: ৩ কেজি, ৫ পিস, ১ বস্তা..."
                className="w-full px-3 py-2 bg-blue-50/40 border border-blue-200 rounded-xl text-xs font-bold text-slate-900 outline-none focus:border-blue-600 shadow-2xs"
              />
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setQuickNewQuantityModal(false);
                    setQuickNewQuantityInput('');
                  }}
                  className="flex-1 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold cursor-pointer hover:bg-slate-200 transition-colors"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold cursor-pointer transition-colors shadow-md shadow-blue-600/20"
                >
                  ✓ ড্রপডাউনে বসান
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 7.5 DELETE CONFIRMATION MODAL */}
      {deleteConfirmId && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fadeIn">
          <div className="w-full max-w-xs bg-white rounded-2xl p-4 shadow-xl border border-slate-200 space-y-3 text-center">
            <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-600 mx-auto flex items-center justify-center">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-black text-slate-900">আপনি কি নিশ্চিত?</h4>
              <p className="text-[11px] text-slate-500 mt-0.5">এই হিসাবটি স্থায়ীভাবে মুছে ফেলা হবে।</p>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setDeleteConfirmId(null);
                  setDeleteCustTxParentId(null);
                }}
                className="flex-1 py-1.5 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
              >
                না
              </button>
              <button
                type="button"
                onClick={handleDeleteItem}
                className="flex-1 py-1.5 bg-rose-600 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                হ্যাঁ, মুছুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
