import React, { useState, useRef } from 'react';
import {
  Upload,
  CheckCircle,
  RefreshCw,
  Trash2,
  X,
  Smartphone,
  Info,
} from 'lucide-react';
import { AppSettings } from '../types';
import { MAppsLogo } from './MAppsLogo';
import { syncAppIconAndManifest } from '../utils/appIconSync';

interface AppLogoModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (updated: AppSettings) => void;
  onShowToast?: (msg: string) => void;
}

export const AppLogoModal: React.FC<AppLogoModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onShowToast,
}) => {
  const [appName, setAppName] = useState(settings.appName || 'M APPS');
  const [appTagline, setAppTagline] = useState(settings.appTagline || 'মোবাইল রিচার্জ অ্যাপ');
  const [appLogoUrl, setAppLogoUrl] = useState(settings.appLogoUrl || '/app-logo.png');
  const [isSaving, setIsSaving] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  // Handle PNG Upload
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      if (onShowToast) onShowToast('অনুগ্রহ করে একটি ছবি ফাইল আপলোড করুন');
      return;
    }

    try {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const img = new Image();
        img.onload = async () => {
          const canvas = document.createElement('canvas');
          const maxDim = 512;
          let width = img.naturalWidth || img.width;
          let height = img.naturalHeight || img.height;

          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = 'high';
            ctx.drawImage(img, 0, 0, width, height);
            const isPng = file.type === 'image/png';
            const base64Data = canvas.toDataURL(isPng ? 'image/png' : 'image/jpeg', 0.9);
            
            // Try saving to backend `/api/save-logo`
            let finalUrl = base64Data;
            try {
              const resp = await fetch('/api/save-logo', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ imageBase64: base64Data }),
              });
              if (resp.ok) {
                const resJson = await resp.json();
                if (resJson && resJson.success && resJson.url) {
                  finalUrl = resJson.url;
                }
              }
            } catch {}

            setAppLogoUrl(finalUrl);
            if (onShowToast) onShowToast('লোগো প্রস্তুত হয়েছে! "সংরক্ষণ" বাটনে চাপুন।');
          }
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    } catch {
      if (onShowToast) onShowToast('ছবি প্রসেসিংয়ে সমস্যা হয়েছে');
    }
  };

  // Save changes
  const handleSave = async () => {
    setIsSaving(true);
    try {
      const effectiveLogo = appLogoUrl.trim() || '/app-logo.png';
      const cleanName = appName.trim() || 'M APPS';
      const cleanTagline = appTagline.trim() || 'মোবাইল রিচার্জ অ্যাপ';

      try {
        await syncAppIconAndManifest(effectiveLogo, cleanName, cleanTagline);
      } catch {}

      const updated: AppSettings = {
        ...settings,
        appName: cleanName,
        appTagline: cleanTagline,
        appLogoUrl: effectiveLogo,
        logoPreset: 'custom',
      };
      
      try {
        localStorage.setItem('telecom_app_settings', JSON.stringify(updated));
        window.dispatchEvent(new Event('storage'));
        window.dispatchEvent(new Event('mapps-logo-updated'));
      } catch {}

      onUpdateSettings(updated);
      if (onShowToast) onShowToast('✓ লোগো ও ব্র্যান্ডিং সফলভাবে আপডেট হয়েছে!');
      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-md w-full p-5 shadow-2xl border border-slate-100 relative max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Upload className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-sm text-slate-900">PNG লোগো সেটিংস</h3>
              <p className="text-[10px] text-slate-500 font-medium">
                লক স্ক্রিন, লগইন ও Android ফোনের জন্য লোগো
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Preview Box */}
        <div className="my-4 p-4 bg-slate-900 rounded-2xl text-center">
          <span className="text-[10px] font-bold text-emerald-400 block mb-2">
            লাইভ প্রিভিউ (সঠিক অনুপাতে অক্ষত প্রদর্শিত)
          </span>
          <div className="flex justify-center">
            <div className="h-12 sm:h-14 min-w-[60px] max-w-[150px] px-3 py-1.5 bg-white rounded-2xl flex items-center justify-center shadow-lg">
              <img
                src={appLogoUrl || '/app-logo.png'}
                alt="App Logo"
                className="w-auto h-auto max-h-9 sm:max-h-10 max-w-full object-contain"
              />
            </div>
          </div>
          <span className="text-white text-xs font-black block mt-2">{appName}</span>
          <span className="text-slate-400 text-[10px]">{appTagline}</span>
        </div>

        {/* Upload Button */}
        <div className="space-y-3">
          <input
            type="file"
            ref={fileInputRef}
            accept="image/png, image/jpeg, image/webp"
            onChange={handleFileUpload}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="w-full py-2.5 px-4 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-xl text-indigo-700 text-xs font-black flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            <Upload className="w-4 h-4" />
            <span>নতুন PNG লোগো আপলোড করুন</span>
          </button>

          <div>
            <label className="block text-slate-700 text-xs font-bold mb-1">
              অ্যাপের নাম
            </label>
            <input
              type="text"
              value={appName}
              onChange={(e) => setAppName(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
            />
          </div>

          <div>
            <label className="block text-slate-700 text-xs font-bold mb-1">
              ট্যাগলাইন
            </label>
            <input
              type="text"
              value={appTagline}
              onChange={(e) => setAppTagline(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex gap-2">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
          >
            বাতিল
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving}
            className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
          >
            {isSaving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
            <span>সেভ ও আইকন সেট</span>
          </button>
        </div>
      </div>
    </div>
  );
};
