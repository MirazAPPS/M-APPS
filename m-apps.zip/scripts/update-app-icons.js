import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

export async function processLogoAndGenerateIcons(inputBufferOrPath) {
  let imageBuffer;
  if (typeof inputBufferOrPath === 'string') {
    if (inputBufferOrPath.startsWith('data:image')) {
      const base64Data = inputBufferOrPath.replace(/^data:image\/\w+;base64,/, '');
      imageBuffer = Buffer.from(base64Data, 'base64');
    } else {
      imageBuffer = fs.readFileSync(path.resolve(inputBufferOrPath));
    }
  } else {
    imageBuffer = inputBufferOrPath;
  }

  // 1. Save master app-logo.png
  await sharp(imageBuffer)
    .png({ quality: 100 })
    .toFile(path.resolve('public/app-logo.png'));
  console.log('Updated public/app-logo.png');

  // 2. Generate PWA 512x512
  await sharp(imageBuffer)
    .resize(512, 512, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
    .png()
    .toFile(path.resolve('public/icon-512.png'));
  console.log('Updated public/icon-512.png');

  // 3. Generate PWA 192x192
  await sharp(imageBuffer)
    .resize(192, 192, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
    .png()
    .toFile(path.resolve('public/icon-192.png'));
  console.log('Updated public/icon-192.png');

  // 4. Generate Apple Touch Icon 180x180
  await sharp(imageBuffer)
    .resize(180, 180, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
    .png()
    .toFile(path.resolve('public/apple-touch-icon.png'));
  console.log('Updated public/apple-touch-icon.png');

  // 5. Generate Favicon 32x32
  await sharp(imageBuffer)
    .resize(32, 32, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
    .png()
    .toFile(path.resolve('public/favicon-32x32.png'));
  console.log('Updated public/favicon-32x32.png');

  // 6. Generate 512x512 Maskable Icon with 15% safe padding for Android home screen
  const maskableInner = Math.round(512 * 0.75); // 384px safe area
  const innerBuffer = await sharp(imageBuffer)
    .resize(maskableInner, maskableInner, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
    .png()
    .toBuffer();

  await sharp({
    create: {
      width: 512,
      height: 512,
      channels: 4,
      background: { r: 255, g: 255, b: 255, alpha: 1 }, // White background for clean Android icon squircle/circle
    },
  })
    .composite([{ input: innerBuffer, gravity: 'center' }])
    .png()
    .toFile(path.resolve('public/icon-maskable-512.png'));
  console.log('Updated public/icon-maskable-512.png');

  // 7. Update Android Native Project Mipmap Icons
  const androidMipmaps = [
    { dir: 'android/app/src/main/res/mipmap-mdpi', size: 48 },
    { dir: 'android/app/src/main/res/mipmap-hdpi', size: 72 },
    { dir: 'android/app/src/main/res/mipmap-xhdpi', size: 96 },
    { dir: 'android/app/src/main/res/mipmap-xxhdpi', size: 144 },
    { dir: 'android/app/src/main/res/mipmap-xxxhdpi', size: 192 },
  ];

  for (const item of androidMipmaps) {
    const fullDir = path.resolve(item.dir);
    if (fs.existsSync(fullDir)) {
      // Standard launcher icon
      await sharp(imageBuffer)
        .resize(item.size, item.size, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
        .png()
        .toFile(path.join(fullDir, 'ic_launcher.png'));

      // Round launcher icon
      await sharp(imageBuffer)
        .resize(item.size, item.size, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
        .png()
        .toFile(path.join(fullDir, 'ic_launcher_round.png'));
      console.log(`Updated Android mipmap icon in ${item.dir} (${item.size}x${item.size})`);
    }
  }

  return true;
}

// If executed directly from command line
if (process.argv[1] && process.argv[1].endsWith('update-app-icons.js')) {
  const target = process.argv[2] || 'public/app-logo.png';
  processLogoAndGenerateIcons(target)
    .then(() => {
      console.log('All icons generated successfully!');
      process.exit(0);
    })
    .catch((err) => {
      console.error('Error generating icons:', err);
      process.exit(1);
    });
}
